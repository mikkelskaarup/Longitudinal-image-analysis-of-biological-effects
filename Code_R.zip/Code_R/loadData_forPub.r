library(R.matlab)

dose1 <- readMat("Path-To-Data/dose1.mat") # The number refers to the patient in question
dose2 <- readMat("Path-To-Data/dose2.mat")
dose3 <- readMat("Path-To-Data/dose3.mat")
dose4 <- readMat("Path-To-Data/dose4.mat")
dose5 <- readMat("Path-To-Data/dose5.mat")
dose6 <- readMat("Path-To-Data/dose6.mat")

LET1 <- readMat("Path-To-Data/LET1.mat") # LET values for each voxels
LET2 <- readMat("Path-To-Data/LET2.mat")
LET3 <- readMat("Path-To-Data/LET3.mat")
LET4 <- readMat("Path-To-Data/LET4.mat")
LET5 <- readMat("Path-To-Data/LET5.mat")
LET5$dLETtot[is.nan(LET5$dLETtot)] <- 0 # An error in the saving of the LET values for the 5th patient required us to replace NaN with zeros. This did not influence the LET distribution as it was voxels outside the patient that caused trouble
LET6 <- readMat("Path-To-Data/LET6.mat")

mask1 <- readMat("Path-To-Data/mask1.mat") # Mask containing the brain contour
mask2 <- readMat("Path-To-Data/mask2.mat")
mask3 <- readMat("Path-To-Data/mask3.mat")
mask4 <- readMat("Path-To-Data/mask4.mat")
mask5 <- readMat("Path-To-Data/mask5.mat")
mask6 <- readMat("Path-To-Data/mask6.mat")

FABase1 <- readMat("Path-To-Data/FABase1.mat") # FA baseline scan
FABase2 <- readMat("Path-To-Data/FABase2.mat")
FABase3 <- readMat("Path-To-Data/FABase3.mat")
FABase4 <- readMat("Path-To-Data/FABase4.mat")
FABase5 <- readMat("Path-To-Data/FABase5.mat")
FABase6 <- readMat("Path-To-Data/FABase6.mat")

T1Base1 <- readMat("Path-To-Data/T1Base1.mat") # T1 baseline scan
T1Base2 <- readMat("Path-To-Data/T1Base2.mat")
T1Base3 <- readMat("Path-To-Data/T1Base3.mat")
T1Base4 <- readMat("Path-To-Data/T1Base4.mat")
T1Base5 <- readMat("Path-To-Data/T1Base5.mat")
T1Base6 <- readMat("Path-To-Data/T1Base6.mat")

T2Base1 <- readMat("Path-To-Data/T2Base1.mat") # T2 baseline scan
T2Base2 <- readMat("Path-To-Data/T2Base2.mat")
T2Base3 <- readMat("Path-To-Data/T2Base3.mat")
T2Base4 <- readMat("Path-To-Data/T2Base4.mat")
T2Base5 <- readMat("Path-To-Data/T2Base5.mat")
T2Base6 <- readMat("Path-To-Data/T2Base6.mat")

FAFU12 <- readMat("Path-To-Data/FAFU1-2.mat") # FA follow-up scan. The first number refers to the patient, the second to the FU session for that patient
FAFU13 <- readMat("Path-To-Data/FAFU1-3.mat")
FAFU14 <- readMat("Path-To-Data/FAFU1-4.mat")
FAFU21 <- readMat("Path-To-Data/FAFU2-1.mat")
FAFU22 <- readMat("Path-To-Data/FAFU2-2.mat")
FAFU23 <- readMat("Path-To-Data/FAFU2-3.mat")
FAFU24 <- readMat("Path-To-Data/FAFU2-4.mat")
FAFU31 <- readMat("Path-To-Data/FAFU3-1.mat")
FAFU32 <- readMat("Path-To-Data/FAFU3-2.mat")
FAFU33 <- readMat("Path-To-Data/FAFU3-3.mat")
FAFU41 <- readMat("Path-To-Data/FAFU4-1.mat")
FAFU42 <- readMat("Path-To-Data/FAFU4-2.mat")
FAFU51 <- readMat("Path-To-Data/FAFU5-1.mat")
FAFU52 <- readMat("Path-To-Data/FAFU5-2.mat")
FAFU61 <- readMat("Path-To-Data/FAFU6-1.mat")
FAFU62 <- readMat("Path-To-Data/FAFU6-2.mat")

T1FU12 <- readMat("Path-To-Data/T1FU1-2.mat") # T1 follow-up scan
T1FU13 <- readMat("Path-To-Data/T1FU1-3.mat")
T1FU14 <- readMat("Path-To-Data/T1FU1-4.mat")
T1FU21 <- readMat("Path-To-Data/T1FU2-1.mat")
T1FU22 <- readMat("Path-To-Data/T1FU2-2.mat")
T1FU23 <- readMat("Path-To-Data/T1FU2-3.mat")
T1FU24 <- readMat("Path-To-Data/T1FU2-4.mat")
T1FU31 <- readMat("Path-To-Data/T1FU3-1.mat")
T1FU32 <- readMat("Path-To-Data/T1FU3-2.mat")
T1FU33 <- readMat("Path-To-Data/T1FU3-3.mat")
T1FU41 <- readMat("Path-To-Data/T1FU4-1.mat")
T1FU42 <- readMat("Path-To-Data/T1FU4-2.mat")
T1FU51 <- readMat("Path-To-Data/T1FU5-1.mat")
T1FU52 <- readMat("Path-To-Data/T1FU5-2.mat")
T1FU61 <- readMat("Path-To-Data/T1FU6-1.mat")
T1FU62 <- readMat("Path-To-Data/T1FU6-2.mat")

T2FU12 <- readMat("Path-To-Data/T2FU1-2.mat") # T2 follow-up scan
T2FU13 <- readMat("Path-To-Data/T2FU1-3.mat")
T2FU14 <- readMat("Path-To-Data/T2FU1-4.mat")
T2FU21 <- readMat("Path-To-Data/T2FU2-1.mat")
T2FU22 <- readMat("Path-To-Data/T2FU2-2.mat")
T2FU23 <- readMat("Path-To-Data/T2FU2-3.mat")
T2FU24 <- readMat("Path-To-Data/T2FU2-4.mat")
T2FU31 <- readMat("Path-To-Data/T2FU3-1.mat")
T2FU32 <- readMat("Path-To-Data/T2FU3-2.mat")
T2FU33 <- readMat("Path-To-Data/T2FU3-3.mat")
T2FU41 <- readMat("Path-To-Data/T2FU4-1.mat")
T2FU42 <- readMat("Path-To-Data/T2FU4-2.mat")
T2FU51 <- readMat("Path-To-Data/T2FU5-1.mat")
T2FU52 <- readMat("Path-To-Data/T2FU5-2.mat")
T2FU61 <- readMat("Path-To-Data/T2FU6-1.mat")
T2FU62 <- readMat("Path-To-Data/T2FU6-2.mat")