function [] = DIKUview(varargin)
% IDEVIEW Opens GUI for viewing images

%%%  Initialization tasks
% Create default colormaps
% Generate Dosemap & Petmap
petmap = [0 0 0;0.0150829562917352 0 0.0371040739119053;0.0301659125834703 0 0.0742081478238106;0.0452488698065281 0 0.111312218010426;0.0603318251669407 0 0.148416295647621;0.0754147842526436 0 0.185520365834236;0.0904977396130562 0 0.222624436020851;0.105580694973469 0 0.259728521108627;0.120663650333881 0 0.296832591295242;0.135746613144875 0 0.333936661481857;0.150829568505287 0 0.371040731668472;0.165912523865700 0 0.408144801855087;0.180995479226112 0 0.445248872041702;0.196078434586525 0 0.482352942228317;0.171568632125855 0 0.547058820724487;0.147058829665184 0 0.611764729022980;0.122549019753933 0 0.676470577716827;0.0980392172932625 0 0.741176486015320;0.0735294148325920 0 0.805882334709168;0.0490196086466312 0 0.870588243007660;0.0245098043233156 0 0.935294091701508;0 0 1;0 0.0750000029802322 1;0 0.150000005960464 1;0 0.225000008940697 1;0 0.300000011920929 1;0 0.375000000000000 1;0 0.450000017881393 1;0 0.525000035762787 1;0 0.600000023841858 1;0 0.620000004768372 0.920000016689301;0 0.640000045299530 0.839999973773956;0 0.660000026226044 0.759999990463257;0 0.680000007152557 0.680000007152557;0 0.700000047683716 0.600000023841858;0 0.720000028610230 0.519999980926514;0 0.740000009536743 0.439999997615814;0 0.759999990463257 0.360000014305115;0 0.780000030994415 0.280000001192093;0 0.800000011920929 0.200000002980232;0.125000000000000 0.824999988079071 0.174999997019768;0.250000000000000 0.850000023841858 0.150000005960464;0.375000000000000 0.875000000000000 0.125000000000000;0.500000000000000 0.899999976158142 0.100000001490116;0.625000000000000 0.925000011920929 0.0750000029802322;0.750000000000000 0.949999988079071 0.0500000007450581;0.875000000000000 0.975000023841858 0.0250000003725290;1 1 0;1 1 0;0.989803910255432 0.933333337306976 0;0.979607820510864 0.866666674613953 0;0.969411790370941 0.800000011920929 0;0.959215700626373 0.733333349227905 0;0.949019610881805 0.666666686534882 0;0.938823521137238 0.600000023841858 0;0.928627431392670 0.533333361148834 0;0.918431401252747 0.466666668653488 0;0.908235311508179 0.400000005960465 0;0.898039221763611 0.333333343267441 0;0.887843132019043 0.266666680574417 0;0.877647042274475 0.200000002980232 0;0.867451012134552 0.133333340287209 0;0.857254922389984 0.0666666701436043 0;0.847058832645416 0 0];
dosemap = [0 0 0;0 0 0.1429;0 0 0.2857;0 0 0.4286;0 0 0.5714;0 0 0.7143;0 0 0.8571;0 0 1.0000;0   0.0625    1.0000;0    0.1250    1.0000;0    0.1875    1.0000; 0    0.2500    1.0000;0    0.3125    1.0000;0    0.3750    1.0000; 0    0.4375    1.0000; 0    0.5000    1.0000; 0    0.5625    1.0000;0    0.6250    1.0000;0    0.6875    1.0000;0    0.7500    1.0000;0    0.8125    1.0000;0    0.8750    1.0000;0    0.9375    1.0000;0    1.0000    1.0000;0.0625    1.0000    0.9375;0.1250    1.0000    0.8750;0.1875    1.0000    0.8125;0.2500    1.0000    0.7500;0.3125    1.0000    0.6875;0.3750    1.0000    0.6250;0.4375    1.0000    0.5625;0.5000    1.0000    0.5000; 0.5625    1.0000    0.4375;0.6250    1.0000    0.3750;0.6875    1.0000    0.3125; 0.7500    1.0000    0.2500; 0.8125    1.0000    0.1875;0.8750    1.0000    0.1250;0.9375    1.0000    0.0625;1.0000    1.0000         0;1.0000    0.9375         0; 1.0000    0.8750         0; 1.0000    0.8125         0; 1.0000    0.7500         0;1.0000    0.6875         0; 1.0000    0.6250         0; 1.0000    0.5625         0; 1.0000    0.5000         0;1.0000    0.4375         0;1.0000    0.3750         0;1.0000    0.3125         0;1.0000    0.2500         0;1.0000    0.1875         0; 1.0000    0.1250         0; 1.0000    0.0625         0;1.0000         0         0;0.9375         0         0;0.8750         0         0;0.8125         0         0;0.7500         0         0;0.6875         0         0;0.6250         0         0;0.5625 0 0;0.5000 0 0];
defaultCMaps = {'MR','PET','CT','Dose','Jet','Default'};
a = .20:.05:0.95;
uit_adj(:,:,1) = repmat(a,16,1)';
uit_adj(:,:,2) = repmat(a,16,1);
uit_adj(:,:,3) = repmat(flip(a,2),16,1);

% Initialize loaded scans
S.loadedScans = getLoadedScans;

% Change here if images should be fused (FUSED=1)
FUSED = 0;


%%% Create main figure
S.main.fh = figure('Units','Pixels',...
    'Position',[100 100 850 600],...
    'Menu','none',...
    'Numbertitle','off',...
    'Name','DIKUview',...
    'Resize','on',...
    'Visible','off');

% Toolbar
% tb = uitoolbar(S.main.fh);
% S.main.tb.uit_adj = uitoggletool(tb,'CData',uit_adj,...
%     'TooltipString','Adjust Image',...
%     'OnCallback',@adjImg_show,'OffCallback',@adjImg_close);

if ~isempty(varargin)
    firstScan = find(strcmp(varargin{1},S.loadedScans));
else
    firstScan = 1;
end

if length(varargin)>1
    secondScan = find(strcmp(varargin{2},S.loadedScans));
else
    secondScan = length(S.loadedScans);
end
% Create Panel for holding layer properties
ap = uipanel('Parent',S.main.fh,'FontSize',12,...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Units','Pixels',...
    'Position',[5 5 200 150]);

% Create SubPanel for holding current scan
subp1 = uipanel('Parent',ap,'FontSize',12,...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Units','Normalized',...
    'Position',[0 0.66 1 0.33]);
uicontrol('Parent',subp1,'Style','text',...
    'Units','Normalized',...
    'Position',[0 0.5 1 0.5],...
    'FontSize',11,...
    'String','Top layer');
S.pp(1) = uicontrol('Parent',subp1,'style','pop',...
    'Unit','Normalized',...
    'Position',[0 0 1 0.5],...
    'BackgroundColor',get(S.main.fh,'color'),...
    'FontSize',12,...
    'String',S.loadedScans,...
    'Value',firstScan,...
    'Callback',{@pp_Callback_toplayer});

% Create SubPanel for holding current scan
subp2 = uipanel('Parent',ap,'FontSize',12,...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Units','Normalized',...
    'Position',[0 0.33 1 0.33]);
uicontrol('Parent',subp2,'Style','text',...
    'Units','Normalized',...
    'Position',[0 0.5 1 0.5],...
    'FontSize',11,...
    'String','Bottom layer');
S.pp(2) = uicontrol('Parent',subp2,'style','pop',...
    'Unit','Normalized',...
    'Position',[0 0 1 0.5],...
    'BackgroundColor',get(S.main.fh,'color'),...
    'FontSize',12,...
    'String',S.loadedScans,...
    'Value',secondScan,...
    'Callback',{@pp_Callback_bottomlayer});


% Create SubPanel for holding current colormap
subp3 = uipanel('Parent',ap,'FontSize',12,...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Units','Normalized',...
    'Position',[0 0 1 0.33]);
uicontrol('Parent',subp3,'Style','text',...
    'Units','Normalized',...
    'Position',[0 0.5 1 0.5],...
    'FontSize',11,...
    'String','Colormap');
S.cm = uicontrol('Parent',subp3,'style','pop',...
    'Unit','Normalized',...
    'Position',[0 0 1 0.5],...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Tag','Colormap',...
    'FontSize',12,...
    'String',defaultCMaps,...
    'Value',1,...
    'Callback',{@cm_Callback});

% Create Panel for holding buttons (same position as previous panel)
bp = uipanel(S.main.fh,'FontSize',12,...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Units','Pixels',...
    'Position',[ap.Position(1) ap.Position(2)+ap.Position(4) ap.Position(3) 300]);

S.main.ls = uicontrol('Parent',bp,'Style','Pushbutton',...
    'String','Load Scan',...
    'Units','Normalized',...
    'Position',[0 0 1 0.2],...
    'Callback',@ls_Callback);

S.main.flip = uicontrol('Parent',bp,'Style','Togglebutton',...
    'String','Flip layer',...
    'Units','Normalized',...
    'Position',[0 0.2 1 0.2],...
    'Callback',@flip_Callback);

S.main.fuse = uicontrol('Parent',bp,'Style','Togglebutton',...
    'String','Fuse layers',...
    'Units','Normalized',...
    'Position',[0 0.4 1 0.2],...
    'Value',FUSED,...
    'Callback',@fuse_Callback);

align([S.main.ls S.main.flip],'Center', 'Distribute')

% Panel for holding first dimension plot
plotpanel(1) = uipanel('Parent',S.main.fh,'FontSize',12,...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Units','Pixels',...
    'Position',[bp.Position(3)+bp.Position(1) ap.Position(2) S.main.fh.Position(3)/2 S.main.fh.Position(4)]);
plotpanel(1).Units = 'Normalized';
plotpanel(1).Position(3) = 0.45;
S.ax(3) = axes('Parent',plotpanel(1) ,...
    'Units','Normalized',...
    'Tag','Ax1',...
    'position',[0 0.1 1 0.9],...
    'Xlim',[0 1],...
    'YLim',[0 1],...
    'Units','normalized');
S.sl(3) = uicontrol('Parent',plotpanel(1) ,...
    'Style','Slide',...
    'Unit','Normalized',...
    'Position',[0.1 0 0.7 0.1],...
    'Min',1,'Max',2,...
    'SliderStep',[1/2 10/2],...
    'value',1.5,...
    'CallBack',{@ThirdPlotAction});
S.tx(3) = uicontrol('Parent',plotpanel(1) ,...
    'Style','Text',...
    'Unit','Normalized',...
    'Position',[0.8 0 0.2 0.1],...
    'FontSize',11,...
    'String','X= ');

% Panel for holding third dimension plot
plotpanel(3)  = uipanel('Parent',S.main.fh,'FontSize',12,...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Units','Normalized',...
    'Position',[plotpanel(1).Position(1)+plotpanel(1).Position(3) 0 0.25 0.5]);
S.ax(1) = axes('Parent',plotpanel(3) ,...
    'Units','Normalized',...
    'Tag','Ax3',...
    'position',[0 0.1 1 0.9],...
    'Xlim',[0 1],...
    'YLim',[0 1],...
    'Units','normalized');
S.sl(1) = uicontrol('Parent',plotpanel(3) ,...
    'Style','Slide',...
    'Unit','Normalized',...
    'Position',[0.1 0 0.7 0.1],...
    'Min',1,'Max',2,...
    'SliderStep',[1/2 10/2],...
    'value',1.5,...
    'CallBack',{@FirstPlotAction});
S.tx(1) = uicontrol('Parent',plotpanel(3) ,...
    'Style','Text',...
    'Unit','Normalized',...
    'Position',[0.8 0 0.2 0.1],...
    'FontSize',11,...
    'String','Z= ');

% Panel for holding second dimension plot
plotpanel(2)  = uipanel('Parent',S.main.fh,'FontSize',12,...
    'BackgroundColor',get(S.main.fh,'color'),...
    'Units','Normalized',...
    'Position',[plotpanel(1).Position(1)+plotpanel(1).Position(3) plotpanel(3).Position(2)+plotpanel(3).Position(4) 0.25 0.5]);
S.ax(2) = axes('Parent',plotpanel(2) ,...
    'Units','Normalized',...
    'Tag','Ax2',...
    'position',[0 0.1 1 0.9],...
    'Xlim',[0 1],...
    'YLim',[0 1],...
    'Units','normalized');
S.sl(2) = uicontrol('Parent',plotpanel(2) ,...
    'Style','Slide',...
    'Unit','Normalized',...
    'Position',[0.1 0 0.7 0.1],...
    'Min',1,'Max',2,...
    'SliderStep',[1/2 10/2],...
    'value',1.5,...
    'CallBack',{@SecondPlotAction});
S.tx(2) = uicontrol('Parent',plotpanel(2) ,...
    'Style','Text',...
    'Unit','Normalized',...
    'Position',[0.8 0 0.2 0.1],...
    'FontSize',11,...
    'String','Y= ');




if ~strcmp(S.pp(1).String, ' ') % Populate axis if scan is loaded
    I = evalin('base',S.pp(1).String{S.pp(1).Value});
    noCol = size(I,1);
    S.sl(1).Max = noCol;
    S.sl(1).SliderStep = [1/noCol 10/noCol];
    S.sl(1).Value = ceil(noCol/2);
    noRow = size(I,2);
    S.sl(2).Max = noRow;
    S.sl(2).SliderStep = [1/noRow 10/noRow];
    S.sl(2).Value = ceil(noRow/2);
    noSlc = size(I,3);
    S.sl(3).Max = noSlc;
    S.sl(3).SliderStep = [1/noSlc 10/noSlc];
    S.sl(3).Value = ceil(noSlc/2);
    %---------- Transversal View
    ThirdPlotAction
    %---------- Sagital View
    SecondPlotAction
    %---------- Coronal View
    FirstPlotAction
    % Change colormap to selection
    cm_Callback
    
else % Make the GUI visible anyway.
    S.main.fh.Visible = 'on';
end

% Move the GUI to the center of the screen.
%movegui(S.main.fh,'center')

%%%  Callbacks for IDEVIEW
% Callback for dropdown in axis windows
    function [] = pp_Callback_toplayer(varargin)
        if strcmp(S.pp(1).String{S.pp(1).Value}, ' ')
            return
        end
        Itmp = evalin('base',S.pp(1).String{S.pp(1).Value});
        noCol = size(Itmp,1);
        S.sl(1).Max = noCol;
        S.sl(1).SliderStep = [1/noCol 10/noCol];
        S.sl(1).Value = ceil(noCol/2);
        noRow = size(Itmp,2);
        S.sl(2).Max = noRow;
        S.sl(2).SliderStep = [1/noRow 10/noRow];
        S.sl(2).Value = ceil(noRow/2);
        noSlc = size(Itmp,3);
        S.sl(3).Max = noSlc;
        S.sl(3).SliderStep = [1/noSlc 10/noSlc];
        S.sl(3).Value = ceil(noSlc/2);

        %---------- Transversal View
        ThirdPlotAction
        %---------- Sagital View
        SecondPlotAction
        %---------- Coronal View
        FirstPlotAction
        
    end

% Callback for dropdown in axis windows
    function [] = pp_Callback_bottomlayer(varargin)
        if strcmp(S.pp(2).String{S.pp(2).Value}, ' ')
            return
        end
        S.main.flip.Value = 1;
        %---------- Transversal View
        ThirdPlotAction
        %---------- Sagital View
        SecondPlotAction
        %---------- Coronal View
        FirstPlotAction
        
    end

% Callback for colormap dropdown
    function [] = cm_Callback(varargin)
        % Resolve colormap
        cm = findobj(gcf,'Tag','Colormap');
        switch cm.String{cm.Value}
            case 'MR'
                cmap = 'gray';
            case 'PET'
                cmap = petmap;
            case 'CT'
                cmap = 'bone';
            case 'Dose'
                cmap = dosemap;
            case 'Jet'
                cmap = 'jet';
            case 'Default'
                cmap = 'default';
        end
        colormap(S.main.fh,cmap)
    end

% Callback for flip layer
    function [] = flip_Callback(varargin)
        %---------- Transversal View
        ThirdPlotAction
        %---------- Sagital View
        SecondPlotAction
        %---------- Coronal View
        FirstPlotAction
    end

% Callback for fuse layers
    function [] = fuse_Callback(varargin)
        %---------- Transversal View
        ThirdPlotAction
        %---------- Sagital View
        SecondPlotAction
        %---------- Coronal View
        FirstPlotAction
    end
% Callback for load scan push button
    function [] = ls_Callback(varargin)
        loadDicomFiles;
        loaded = getLoadedScans;
        if strcmp(S.loadedScans{1},' ')
            S.loadedScans = loaded;
        else
            S.loadedScans = [S.loadedScans;loaded(~ismember(loaded,S.loadedScans))];
        end
        if ~isempty(loaded) && isfield(S,'pp')
            [S.pp.String] = deal(S.loadedScans);
        end
    end

%%%  Utility functions for MYGUI
% --- Update First Axis Plot.
    function FirstPlotAction(varargin)
        if S.main.flip.Value == 1
            layer = 2;
        else
            layer = 1;
        end
        if strcmp(S.pp(layer).String{S.pp(layer).Value}, ' ')
            return
        end
        %Cursor = getappdata(hMainGui,'Cursor');
        % ax = get(get(findobj('tag','buttongroup_axes'),'SelectedObject'),'string');
        % if strcmpi(ax,'scaled'), ax = 'square'; end
        % if strcmpi(ax,'true'), ax = 'image'; end
%         xlim = S.ax(1).XLim;
%         ylim = S.ax(1).YLim;
        
        index = round(S.sl(1).Value);

        if S.main.fuse.Value == 1
            VOL_top = evalin('base',S.pp(1).String{S.pp(1).Value});
            VOL_bottom = evalin('base',S.pp(2).String{S.pp(2).Value});
            imgSlice = imfuse(rot90(squeeze(VOL_top(index,:,:))),rot90(squeeze(VOL_bottom(index,:,:))),'falsecolor','Scaling','independent','ColorChannels',[1 2 0]);
            minIntensity = 0;
            maxIntensity = 1;
        else
            VOL = evalin('base',S.pp(layer).String{S.pp(layer).Value});
            imgSlice = rot90(squeeze(VOL(index,:,:)));
            minIntensity = min(imgSlice(:));
            maxIntensity = max(imgSlice(:));
            if maxIntensity == minIntensity
                maxIntensity = minIntensity + 1;
            end
        end 
        
        S.tx(1).String = ['Y = ' num2str(index)];
        S.tx(1).TooltipString = ['Slice = ' num2str(index)];
        
        axes(S.ax(1)) % Select axes to plot in        
        imagesc(imgSlice,double([minIntensity maxIntensity]));
        %colorbar;
        axis square
        axis off
%         if ~isequal(xlim,[0 1])
%             set(S.ax(1),'XLim',xlim,'YLim',ylim);
%         end
        
        %         if get(findobj('tag','button_showaxes'),'Value')
        %             axis on
        %         else
        %             axis off
        %         end
        
        % Horizontal
        %line('XData',get(handles.view_upperleft,'XLim'), 'YData',[Cursor(2) Cursor(2)], 'EraseMode','normal', 'Tag','HCursor','Color','g','LineWidth',1);
        % Vertical
        %line('XData',[Cursor(1) Cursor(1)], 'YData',get(handles.view_upperleft,'YLim'), 'EraseMode','normal', 'Tag','VCursor','Color','r','LineWidth',1);
        
    end

% --- Update Second Axis Plot.
    function SecondPlotAction(varargin)
        if S.main.flip.Value == 1
            layer = 2;
        else
            layer = 1;
        end
        if strcmp(S.pp(layer).String{S.pp(layer).Value}, ' ')
            return
        end
        %Cursor = getappdata(hMainGui,'Cursor');
        % ax = get(get(findobj('tag','buttongroup_axes'),'SelectedObject'),'string');
        % if strcmpi(ax,'scaled'), ax = 'square'; end
        % if strcmpi(ax,'true'), ax = 'image'; end
%         xlim = S.ax(2).XLim;
%         ylim = S.ax(2).YLim;
        index = round(S.sl(2).Value);
        
        if S.main.fuse.Value == 1
            VOL_top = evalin('base',S.pp(1).String{S.pp(1).Value});
            VOL_bottom = evalin('base',S.pp(2).String{S.pp(2).Value});
            imgSlice = imfuse(rot90(squeeze(VOL_top(:,index,:))),rot90(squeeze(VOL_bottom(:,index,:))),'falsecolor','Scaling','independent','ColorChannels',[1 2 0]);
            minIntensity = 0;
            maxIntensity = 1;
        else
            VOL = evalin('base',S.pp(layer).String{S.pp(layer).Value});
            imgSlice = rot90(squeeze(VOL(:,index,:)));
            minIntensity = min(imgSlice(:));
            maxIntensity = max(imgSlice(:));
            if maxIntensity == minIntensity
                maxIntensity = minIntensity + 1;
            end
        end 
        
        S.tx(2).String = ['X = ' num2str(index)];
        S.tx(2).TooltipString = ['Slice = ' num2str(index)];
        
        axes(S.ax(2)) % Select axes to plot in
        imagesc(imgSlice,double([minIntensity maxIntensity]));
        %colorbar;
        axis square
        axis off
%         if ~isequal(xlim,[0 1])
%             set(S.ax(2),'XLim',xlim,'YLim',ylim);
%         end
        
        %         if get(findobj('tag','button_showaxes'),'Value')
        %             axis on
        %         else
        %             axis off
        %         end
        
        % Horizontal
        %line('XData',get(handles.view_upperleft,'XLim'), 'YData',[Cursor(2) Cursor(2)], 'EraseMode','normal', 'Tag','HCursor','Color','g','LineWidth',1);
        % Vertical
        %line('XData',[Cursor(1) Cursor(1)], 'YData',get(handles.view_upperleft,'YLim'), 'EraseMode','normal', 'Tag','VCursor','Color','r','LineWidth',1);
        
    end

% --- Update Third Axis Plot.
    function ThirdPlotAction(varargin)
        if S.main.flip.Value == 1
            layer = 2;
        else
            layer = 1;
        end
        if strcmp(S.pp(layer).String{S.pp(layer).Value}, ' ')
            return
        end
        %Cursor = getappdata(hMainGui,'Cursor');
        % ax = get(get(findobj('tag','buttongroup_axes'),'SelectedObject'),'string');
        % if strcmpi(ax,'scaled'), ax = 'square'; end
        % if strcmpi(ax,'true'), ax = 'image'; end
%         xlim = S.ax(3).XLim;
%         ylim = S.ax(3).YLim;
        index = round(S.sl(3).Value);
        
        if S.main.fuse.Value == 1
            VOL_top = evalin('base',S.pp(1).String{S.pp(1).Value});
            VOL_bottom = evalin('base',S.pp(2).String{S.pp(2).Value});
            imgSlice = imfuse(VOL_top(:,:,index),VOL_bottom(:,:,index),'falsecolor','Scaling','independent','ColorChannels',[1 2 0]);
            minIntensity = 0;
            maxIntensity = 1;
        else
            VOL = evalin('base',S.pp(layer).String{S.pp(layer).Value});
            imgSlice = squeeze(VOL(:,:,index));
            minIntensity = min(imgSlice(:));
            maxIntensity = max(imgSlice(:));
            if maxIntensity == minIntensity
                maxIntensity = minIntensity + 1;
            end
        end        
        
        S.tx(3).String = ['Z = ' num2str(index)];
        S.tx(3).TooltipString = ['Slice = ' num2str(index)];
        
        axes(S.ax(3)) % Select axes to plot in
        imagesc(imgSlice,double([minIntensity maxIntensity]));
        %colorbar;
        axis square
        axis off
%         if ~isequal(xlim,[0 1])
%             set(S.ax(3),'XLim',xlim,'YLim',ylim);
%         end
        
        %         if get(findobj('tag','button_showaxes'),'Value')
        %             axis on
        %         else
        %             axis off
        %         end
        
        % Horizontal
        %line('XData',get(handles.view_upperleft,'XLim'), 'YData',[Cursor(2) Cursor(2)], 'EraseMode','normal', 'Tag','HCursor','Color','g','LineWidth',1);
        % Vertical
        %line('XData',[Cursor(1) Cursor(1)], 'YData',get(handles.view_upperleft,'YLim'), 'EraseMode','normal', 'Tag','VCursor','Color','r','LineWidth',1);
        
    end


% Get current loaded volumes
    function scanInBaseWorkSpace = getLoadedScans(varargin)
        Vars = evalin('base','who;');
        selectedVars = cell(length(Vars),1);
        
        for i = 1:length(Vars)
            dims = evalin('base',sprintf('ndims(%s)',Vars{i}));
            %isVolumeStructure = evalin('base',sprintf('isfield(%s,''vol'') || isfield(%s,''DoseMatrix'')',Vars{i},Vars{i}));
            %if dims == 3 || isVolumeStructure
            if dims == 3
                selectedVars{i} = Vars{i};
            end
        end
        
        nonempty = cellfun(@(x) ~isempty(x),selectedVars);
        scanInBaseWorkSpace = selectedVars(nonempty);
        if isempty(scanInBaseWorkSpace)
            scanInBaseWorkSpace = {' '};
        end
    end
   
end

