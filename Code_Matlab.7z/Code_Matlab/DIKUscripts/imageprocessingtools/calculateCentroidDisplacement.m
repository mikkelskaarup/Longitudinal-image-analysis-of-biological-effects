function d = calculateCentroidDisplacement(M1,M2,vol)

P1 = regionprops(single(M1),'Centroid');
P2 = regionprops(single(M2),'Centroid');

x1 = interp1((1:length(vol.X(1,:,1)))',vol.X(1,:,1)',P1.Centroid(1));
y1 = interp1((1:length(vol.Y(:,1,1)))',vol.Y(:,1,1),P1.Centroid(2));
z1 = interp1((1:length(vol.Z(1,1,:)))',squeeze(vol.Z(1,1,:)),P1.Centroid(3));

x2 = interp1((1:length(vol.X(1,:,1)))',vol.X(1,:,1)',P2.Centroid(1));
y2 = interp1((1:length(vol.Y(:,1,1)))',vol.Y(:,1,1),P2.Centroid(2));
z2 = interp1((1:length(vol.Z(1,1,:)))',squeeze(vol.Z(1,1,:)),P2.Centroid(3));

d = sqrt( (x1-x2)^2 + (y1-y2)^2 + (z1-z2)^2 );