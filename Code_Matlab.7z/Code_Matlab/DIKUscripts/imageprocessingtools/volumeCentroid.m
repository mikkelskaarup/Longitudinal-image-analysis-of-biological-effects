function t = volumeCentroid(img,dimt)

% estimate centroid for both scans and initialize registration
[id]=kmeans(img(:),2);
cls=reshape(id,size(img));
cls=2-cls;
props=regionprops(cls,'Centroid');


c = props.Centroid.*dimt - props.Centroid.*dimt;


t(1)=c(2); t(2)=c(1); t(3)=c(3);