function S = getRays(X,Y,Z,M,varargin)
%
%
%
% Resolve inputs
if nargin < 4
    error('Not enough input arguments given.');
end
% Default input
smooth = 1;
smooth_iter = 5;
com_w = [];

k = 1;
while k <= length(varargin)
    switch varargin{k}
        case 'smooth'
            k = k + 1;
            smooth = varargin{k};
        case 'smooth_iter'
            k = k + 1;
            smooth_iter = varargin{k};
        case 'center'
            k = k + 1;
            com_w = varargin{k};
        otherwise
            error('Illegal option %s', varargin{k});
    end
    k = k + 1;
end

if isempty(com_w) || numel(com_w) ~= 3 % Find center of mass
    if numel(com_w) ~= 3 && ~isempty(com_w)
        warning(['Center of mass has ' num2str(numel(com_w)) ' elements. Recalculating...']);
    end
    STATS = regionprops(M,'Centroid');
    com_i = STATS.Centroid;
    % Convert to intrinsic coordinates
    com_w(1) = interp1(1:length(X(1,:,1)),X(1,:,1),com_i(1));
    com_w(2) = interp1(1:length(Y(:,1,1)),Y(:,1,1),com_i(2));
    com_w(3) = interp1(1:length(squeeze(Z(1,1,:))),squeeze(Z(1,1,:)),com_i(3));
else
    fprintf('Using center of mass: x=%.2f, y=%.2f, z=%.2f.\n',com_w);
end

if smooth
% Create mesh triangulation
    FV = smoothpatch(isosurface(X,Y,Z,M,0.9),1,smooth_iter);
else
    Mrim = gougeMask(M);
    FV.vertices = [X(Mrim),Y(Mrim),Z(Mrim)];
    FV.faces = [];
end
noPoints = length(FV.vertices);

% Compute directional vectors from center of mass to tumor mesh vertices
V = FV.vertices - repmat(com_w,noPoints,1);
% Compute length of each ray
len = sqrt(sum(V.^2,2));
% Normalize V
unit_dir = V./repmat(len,1,3);

% Save outputs
S = struct('Faces',FV.faces,'Vertices',FV.vertices,'V',V,'Unit_V',unit_dir,'CenterOfMass',com_w);
