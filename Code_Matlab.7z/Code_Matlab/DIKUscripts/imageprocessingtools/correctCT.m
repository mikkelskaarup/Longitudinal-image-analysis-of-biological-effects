%correctCT     Correct CT data
%   Correct CT-images to Hounsfield Units

function CTcorrected = correctCT(slice,info)

CTcorrected = round(double(slice) .* info.RescaleSlope + info.RescaleIntercept);

%disp(info.RescaleSlope)
%disp(max(slice(:))