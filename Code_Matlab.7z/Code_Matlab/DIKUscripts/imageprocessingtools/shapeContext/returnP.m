function P = returnP(x1,x2)

% Constructing P-matrix
P = [ones(1,length(x1(:)));
    x1(:)';
    x2(:)'];
