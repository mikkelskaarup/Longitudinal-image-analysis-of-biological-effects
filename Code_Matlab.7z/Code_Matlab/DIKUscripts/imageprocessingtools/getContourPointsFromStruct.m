function [x,y,z] = getContourPointsFromStruct(S,contour)

if ~isfield(S,contour)
    error('Contour not found!');
end

% Extract slice numbers from structure
C = S.(contour);
slices = fieldnames(C);
sliceNumbers = regexp(slices,'(?<=Slice_)\d+','match');
numbers = cellfun(@cell2mat,sliceNumbers,'UniformOutput',0);
numbers = numbers(~cellfun(@isempty,numbers));

noSlices = length(numbers);

x = zeros(S.(contour).TotalNumberOfContourPoints,1);
y = x;
z = x;

i = 0;

for s = 1:noSlices % Loop over slices
    noContours = length(fieldnames(S.(contour).(['Slice_' numbers{s}])));
    for c = 1:noContours % Loop over contours within slice
        xc = S.(contour).(['Slice_' numbers{s}]).(['Contour' num2str(c)]).x;
        yc = S.(contour).(['Slice_' numbers{s}]).(['Contour' num2str(c)]).y;
        zc = S.(contour).(['Slice_' numbers{s}]).(['Contour' num2str(c)]).z;
        
        x( i+1:length(xc)+i ) = xc;
        y( i+1:length(xc)+i ) = yc;
        z( i+1:length(xc)+i ) = zc;
        
        i = i+length(xc);
    end
end


