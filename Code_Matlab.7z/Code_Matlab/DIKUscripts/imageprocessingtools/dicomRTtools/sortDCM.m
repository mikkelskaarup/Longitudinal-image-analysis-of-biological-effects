function sortDCM(dName)

curr_path = cd;
cd(dName);

fArray = ls([cd '\*.dcm']);
if isempty(fArray)
    warning('No DICOM files to sort!!');
    return
end

h = waitbar(0,'Please wait...');

noFiles = length(fArray(:,1));

for i = 1:noFiles
    info = dicominfo([dName '/' fArray(i,:)]);
    if isfield(info,'StudyDescription')
        if isfield(info,'SeriesDescription')
            newFolder = [cd,filesep,info.PatientID,filesep,info.StudyDescription,filesep,info.SeriesDescription];
        else
            newFolder = [cd,filesep,info.PatientID,filesep,info.StudyDescription];
        end
    else
        newFolder = [cd,filesep,info.PatientID];
    end
    
    newFolder = cleanFolderName(newFolder);
    
    if ~exist(newFolder,'dir');
        mkdir(newFolder);
        movefile(fArray(i,:),newFolder);
    else
        movefile(fArray(i,:),newFolder);
    end
    
    waitbar(i/noFiles);
end
close(h)


cd(curr_path);