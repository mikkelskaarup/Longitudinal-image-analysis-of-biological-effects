function PLAN = sortPlanDoseCT(dName,copyRS)
if nargin < 2
    copyRS = 0;
end

if copyRS
    mvORcp = 'copy';
else 
    mvORcp = 'move';
end
%% Sort CT-scans
%%%%% TO BE MODIFIED %%%%%%
% CTArray = dir([dName '\CT*.dcm']);
% CTArray = {CTArray(:).name};
% if isempty(CTArray)
% %     warning('No CT files to sort!!');
% else
%     for i = 1:length(CTArray)
%         info = dicominfo([dName filesep CTArray{i}]);
%         CTfolder = [dName,filesep, 'CT'];
%         if ~exist(CTfolder,'dir');
%             mkdir(CTfolder);
%             movefile([dName,filesep,CTArray(i,:)],CTfolder);
%         else
%             movefile([dName,filesep,CTArray(i,:)],CTfolder);
%         end
%     end
% end

%% Sort RTPLANS
RPArray = dir([dName '\RP*.dcm']);
RPArray = {RPArray(:).name};
if isempty(RPArray)
    warning('No RP files to sort!!');
else
    for i = 1:length(RPArray)
        info = dicominfo([dName filesep RPArray{i}]);
        if exist('PLAN','var') && isfield(PLAN,['UID' strrep(info.SOPInstanceUID,'.','')])
            disp([dName filesep RPArray{i} ' already exist - skipping!']);
        else
            if isfield(info,'RTPlanLabel')
                disp(['Label: ' info.RTPlanLabel]);
                disp('************');
                RTPlanLabel = cleanPlanNameToFolder(info.RTPlanLabel);
                RPfolder = [dName,filesep,filesep,RTPlanLabel];
                RPfileName = ['RP_' RTPlanLabel];
                
                if ~exist(RPfolder,'dir');
                    system(['mkdir "' RPfolder '"']);
                end
                
                if ~exist([RPfolder filesep RPfileName '.dcm'],'file')
                    system(['move "' dName filesep RPArray{i} '" "' RPfolder filesep RPfileName '.dcm"']);
                else
                    plans = ls([RPfolder filesep RPfileName '*']);
                    uniquePlans = size(plans,1);
                    system(['move "' dName filesep RPArray{i} '" "' RPfolder filesep RPfileName...
                        '_' num2str(uniquePlans) '.dcm"']);
                    if ~exist([RPfolder filesep 'ReadMe.txt'],'file')
                        fid = fopen([RPfolder filesep 'ReadMePlan.txt'],'w');
                        fprintf(fid,'Multiple Plans with same name encountered.');
                        fclose(fid);
                    end
                end
                
                SOPInstanceUID = strrep(info.SOPInstanceUID,'.','');
                PLAN.(['UID' SOPInstanceUID]) = RTPlanLabel;
                if isfield(info,'ReferencedStructureSetSequence');
                    ReferencedStructUID = strrep(info.ReferencedStructureSetSequence.Item_1.ReferencedSOPInstanceUID,'.','');
                else
                    ReferencedStructUID = '';
                end
                STRUCT.(['UID' ReferencedStructUID]) = RTPlanLabel;
            else
                disp([RPArray{i} ' - No Plan Label - cannot rename']);
            end
        end
    end
end


%% Sort RTDOSES
RDArray = dir([dName '\RD*.dcm']);
RDArray = {RDArray(:).name}';

if isempty(RDArray)
    warning('No RD files to sort!!');
else
    RPUIDs = fieldnames(PLAN);
    for i = 1:length(RDArray)
        info = dicominfo([dName filesep RDArray{i}]);
        RDreferencedRPUID = ['UID' strrep(info.ReferencedRTPlanSequence.Item_1.ReferencedSOPInstanceUID,'.','')];
        RDfileName = ['RD_' info.DoseSummationType];
        
        planIndex = find(ismember(RPUIDs,RDreferencedRPUID));
        if ~isempty(planIndex)
            for j = 1:length(planIndex)
                RPfolder = [dName filesep PLAN.(RPUIDs{planIndex(j)})];
                if ~exist([RPfolder filesep RDfileName '.dcm'],'file')
                    system(['move "' dName filesep RDArray{i} '" "' RPfolder filesep RDfileName '.dcm"']);
                else
                    doses = ls([RPfolder filesep RDfileName '*']);
                    uniqueDoses = size(doses,1);
                    system(['move "' dName filesep RDArray{i} '" "' RPfolder filesep RDfileName...
                        '_' num2str(uniqueDoses) '.dcm"']);
                    if ~exist([RPfolder filesep 'ReadMe.txt'],'file')
                        fid = fopen([RPfolder filesep 'ReadMeDose.txt'],'w');
                        fprintf(fid,'Multiple Doses with same name encountered.');
                        fclose(fid);
                    end
                end
            end
        else
            warning(sprintf('No Plan match this dose-file: %s\nLeaving in Patient root folder!', RDArray{i}));
        end
        
    end
end

%% Sort RT Structures
RSArray = dir([dName '\RS*.dcm']);
RSArray = {RSArray(:).name};
if isempty(RSArray)
    warning('No RD files to sort!!');
else
    ReferencedRPUIDs = fieldnames(STRUCT);
    for i = 1:length(RSArray)
        info = dicominfo([dName filesep RSArray{i}]);
        RSUID = ['UID' strrep(info.SOPInstanceUID,'.','')];
        
        planIndex = find(ismember(ReferencedRPUIDs,RSUID));
        RSfileName = ['RS_' info.StructureSetLabel];
        if ~isempty(planIndex)
            for j = 1:length(planIndex)
                RPfolder = [dName filesep STRUCT.(ReferencedRPUIDs{planIndex(j)})];
                if ~exist([RPfolder filesep RSfileName '.dcm'],'file')
                    system([mvORcp ' "' dName filesep RSArray{i} '" "' RPfolder filesep RSfileName '.dcm"']);
                else
                    struct = ls([RPfolder filesep RSfileName '*']);
                    uniqueStructs = size(struct,1);
                    system([mvORcp ' "' dName filesep RSArray{i} '" "' RPfolder filesep RSfileName...
                        '_' num2str(uniqueStructs) '.dcm"']);
                    if ~exist([RPfolder filesep 'ReadMe.txt'],'file')
                        fid = fopen([RPfolder filesep 'ReadMeStructs.txt'],'w');
                        fprintf(fid,'Multiple Structuresets with same name encountered.');
                        fclose(fid);
                    end
                end
            end
        else
            warning(sprintf('No Plan match this strucutre-file: %s\nLeaving in Patient root folder!', RSArray{i}));
            system(['move "' dName filesep RSArray{i} '" "' dName filesep RSfileName '.dcm"']);
        end
        
    end
end