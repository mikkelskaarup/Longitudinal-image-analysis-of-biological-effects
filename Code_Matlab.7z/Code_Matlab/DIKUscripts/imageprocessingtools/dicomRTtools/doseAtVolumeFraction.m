function D = doseAtVolumeFraction(DVH,f)

if isstruct(DVH)
    DVHdose = DVH.Dose;
    DVHvolume = DVH.Volume;
    DVH = [DVHdose,DVHvolume];
end

if isempty(DVH)
    D = [];
else
    if sum(diff(DVH(:,1))) == 0 % differential dvh
        cumulatedDVH(:,1) = cumsum(DVH(:,1));
    else % cumulated dvh
        cumulatedDVH(:,1) = DVH(:,1); % dose in units of Gy
    end
    cumulatedDVH(:,2) = flipud(cumsum(flipud(DVH(:,2)))); % volume in units of cm3
    
    OARvolume = cumulatedDVH(1,2);
    
    ind = find(cumulatedDVH(:,2) >= f*OARvolume,1,'last');
    
    
    if cumulatedDVH(ind,2) == f*OARvolume || ind == length(cumulatedDVH(:,2))
        D = cumulatedDVH(ind,1);
    else % Use linear interpolation to find exact dose
        D = interp1(...
            [cumulatedDVH(ind,2),cumulatedDVH(ind+1,2)] , ...
            [cumulatedDVH(ind,1),cumulatedDVH(ind+1,1)] , f*OARvolume,'linear');
    end
end

