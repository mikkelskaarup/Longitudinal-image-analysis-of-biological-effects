function struct = getPlanInfo(in)

info = verifyRTinput(in);

struct.PlanLabel = info.RTPlanLabel;
struct.PlanInstanceUID = info.SOPInstanceUID;
struct.ReferencedDoseUID = info.DoseReferenceSequence.Item_1.DoseReferenceUID;

if strcmpi(info.DoseReferenceSequence.Item_1.DoseReferenceType,'TARGET')
    struct.PrescriptionDose = info.DoseReferenceSequence.Item_1.TargetPrescriptionDose;
elseif strcmpi(info.DoseReferenceSequence.Item_1.DoseReferenceType,'ORGAN_AT_RISK')
    struct.PrescriptionDose = info.DoseReferenceSequence.Item_1.DeliveryMaximumDose;
else
    errordlg('Something is wrong with DoseReferenceType!');
end