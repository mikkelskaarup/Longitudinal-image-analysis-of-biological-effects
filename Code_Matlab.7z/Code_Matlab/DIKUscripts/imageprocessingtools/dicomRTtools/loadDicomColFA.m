%%%%% lLOADDICOMFILES
% Function for loading various dicom image files
%
% Edit 21/11/2014 to allow loading mosaic
function [struct,dName] = loadDicomColFA(dName,varargin)

if nargin == 0
    dialog_title = 'Select folder containing DICOM files to load.';
    dName = uigetdir('',dialog_title);
    if ~dName % user pressed cancels
        struct = [];
        return
    end
end

% Default properties
convertpixelvalues = 1;
showwaitbar = 1;
precision = 'uint16';

k = 1;
while k <= length(varargin)
    switch lower(varargin{k})
        case 'convertpixelvalues'
            k = k + 1;
            convertpixelvalues = varargin{k};
        case 'showwaitbar'
            k = k + 1;
            showwaitbar = varargin{k};
        case 'precision'
            k = k + 1;
            precision = varargin{k};
    end
    k = k + 1;
end

fArray = listDicomFiles(dName);
noFiles = length(fArray);

if noFiles == 0
    warndlg('No DICOM files found!')
    return
end


infos = cell(length(fArray),1);

% Read meta data
ignore = zeros(length(fArray),1);
tic;
for i = 1:noFiles
    disp(['Reading files ... Number ' num2str(i) ' of ' num2str(noFiles) '...'])
    infos{i} = dicominfo(fullfile(dName,fArray{i}));
    % Check if image is projection image
    if ~isempty(regexpi(infos{i}.ImageType,'Projection Image'))
        disp(['Ignoring ' fArray{i} '. Image is a projection image.']);
        ignore(i) = 1;
    end
end
fArray = fArray(~ignore);
infos = infos(~ignore);
clear ignore
timeInfo = toc;
disp(['Read metadata from ' num2str(noFiles) ' dicomfiles in ' sprintf('%.2f',timeInfo) ' seconds.'])
noFiles = length(fArray);

% Does all images belong to the same series?
seriesUids = arrayfun(@(i) infos{i}.SeriesInstanceUID, 1:numel(infos),'UniformOutput',0); 
uniqueSeries = unique(seriesUids);

if length(uniqueSeries) > 1
    disp('Images from more than one series is present...')
    tmp = zeros(length(uniqueSeries),1);
    for i = 1:length(uniqueSeries)
        tmpIndexInSeriesUids = strcmp(seriesUids,uniqueSeries{i});
        tmp(i) = sum(tmpIndexInSeriesUids);
        disp(infos{find(tmpIndexInSeriesUids,1,'first')}.SeriesDescription)
    end
    % Save images from most frequent series
    [~,i] = max(tmp);
    usedSeriesUid = uniqueSeries{i};
    infos = infos(strcmp(seriesUids,usedSeriesUid));
    fArray = fArray(strcmp(seriesUids,usedSeriesUid));
    noFiles = length(fArray);
    disp(['Saving images from ' infos{1}.SeriesDescription '.']);
end

for i = 1:length(fArray)
    if isempty(regexpi(infos{i}.ImageType,'Projection Image'))
        nFrames = length(fArray);
        nRows = double(infos{i}.Rows);
        nCols = double(infos{i}.Columns);
        struct.info = infos{i};
    end
end

% PREALLOCATE
vol = zeros(nRows, nCols, nFrames,3);

WindowCenter = NaN(noFiles,1);
WindowWidth = NaN(noFiles,1);

% Read images
if showwaitbar
    h = waitbar(0,'Reading images.....');
end

for frame = 1:noFiles
    % Update waitbar
    if showwaitbar
        waitbar(frame / noFiles)
    end
        
    WindowCenter(frame) = infos{frame}.WindowCenter(1);
    WindowWidth(frame) = infos{frame}.WindowWidth(1);
    
    % Read DICOM image
    tmpImg = dicomread(infos{frame});
    vol(:,:,infos{frame}.InstanceNumber,:) = tmpImg;
end

struct.vol = vol;

% Average Window-Center and -Width
struct.WindowCenter = WindowCenter;
struct.WindowWidth = WindowWidth;

% Close waitbar
if exist('h','var')
    close(h)
end

if nargout == 0
    v = version('-release');
    if str2double(v(1:4)) < 2014
        assignin('base', genvarname(info.SeriesDescription), struct);
    else
        Vars = evalin('base','who;');
        name = matlab.lang.makeUniqueStrings(matlab.lang.makeValidName(infos{1}.SeriesDescription),Vars);
        assignin('base', name, struct);
    end
end