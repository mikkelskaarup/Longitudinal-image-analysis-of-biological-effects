function [volNew,XNew,YNew,ZNew,RNew] = fixVolumeOrientationDICOM(vol,X,Y,Z,R)

r = R(1:3,1:3);
Rx = [1 0 0; 0 cosd(90) -sind(90); 0 sind(90) cosd(90)];
Rz = [cosd(90) -sind(90) 0; sind(90) cosd(90) 0; 0 0 1];
Ry = [cosd(90) 0 sind(90); 0 1 0; -sind(90) 0 cosd(90)];
firstDirectionCosine = r(:,1);
secondDirectionCosine = r(:,2);

RNew = R;
if firstDirectionCosine(1) > 0.8 && secondDirectionCosine(2) < 0.8; % Coronal orientation
    volNew = flip(permute(vol,[3 2 1]),3);
    XNew = flip(permute(X,[3 2 1]),3);
    YNew = flip(permute(Y,[3 2 1]),3);
    ZNew = flip(permute(Z,[3 2 1]),3);
    RNew(1:3,1:3) = r*Rx;
elseif firstDirectionCosine(2) > 0.8 && secondDirectionCosine(3) < 0.8; % Sagital orientation
    volNew = flip(flip(permute(vol,[2 3 1]),2),3);
    XNew = flip(flip(permute(X,[2 3 1]),2),3);
    YNew = flip(flip(permute(Y,[2 3 1]),2),3);
    ZNew = flip(flip(permute(Z,[2 3 1]),2),3);
    RNew(1:3,1:3) = r*Ry*Rx;
else
    erorr('Situation not accounted for!')
end
