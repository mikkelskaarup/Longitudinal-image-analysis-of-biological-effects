function DVH = readRTDVH(D,RS)

%%%% TWO SEPARATE CASES; IF RS IS PROVIDED OR NOT
if nargin < 2
    %%%% RS IS NOT PROVIDED
    ROIitemsInRDfile = fieldnames(D);
    numberOfROIsInRDfile = length(ROIitemsInRDfile);
    for i = 1:numberOfROIsInRDfile
        DVH.(ROIitemsInRDfile{i}).DVHType = D.(ROIitemsInRDfile{i}).DVHType;
        DVH.(ROIitemsInRDfile{i}).DoseUnits = D.(ROIitemsInRDfile{i}).DoseUnits;
        DVH.(ROIitemsInRDfile{i}).DoseType = D.(ROIitemsInRDfile{i}).DoseType;
        DVH.(ROIitemsInRDfile{i}).VolumeUnits = D.(ROIitemsInRDfile{i}).DVHVolumeUnits;
        
        dvhdata = D.(ROIitemsInRDfile{i}).DVHData;
        
        % DVHData is stored as a datastream in the order D1,V1,D2,V2,...,Dn,Vn.
        % Where Di is the bin width. Di multiplied by DVHDoseScaling equals
        % dose.
        % See DICOM Standard PS 3.3 - C.8.8.4 RT DVH Module
        DVH.(ROIitemsInRDfile{i}).Dose = dvhdata(1:2:end-1)*D.(ROIitemsInRDfile{i}).DVHDoseScaling;
        DVH.(ROIitemsInRDfile{i}).Volume = dvhdata(2:2:end);
         
        DVH.(ROIitemsInRDfile{i}).MaximumDose = D.(ROIitemsInRDfile{i}).DVHMaximumDose;
        DVH.(ROIitemsInRDfile{i}).MeanDose    = D.(ROIitemsInRDfile{i}).DVHMeanDose;
        DVH.(ROIitemsInRDfile{i}).MinimumDose = D.(ROIitemsInRDfile{i}).DVHMinimumDose;
        DVH.(ROIitemsInRDfile{i}).DVHReferencedROISequence = D.(ROIitemsInRDfile{i}).DVHReferencedROISequence;
    end
    
else
    %%%% RS IS PROVIDED
    % Item_names in DVH-sequence
    ROIitemsInRDfile = fieldnames(D);
    numberOfROIsInRDfile = length(ROIitemsInRDfile);
    RDroiNumber = zeros(numberOfROIsInRDfile,1);
    for item = 1:numberOfROIsInRDfile
        RDroiNumber(item) = D.(['Item_' num2str(item)]).DVHReferencedROISequence.Item_1.ReferencedROINumber;
    end
    % Names in RT Structure file
    names = fieldnames(RS);
    ROInames = names(structfun(@isstruct, RS));
    noROIs = length(ROInames);
    
    % Loop and match ROI numbers
    for i = 1:noROIs
        roiName = ROInames{i};
        RSroiNumber = RS.(roiName).ROIno;
        
        itemIndex = find(RDroiNumber == RSroiNumber);
        
        if isempty(itemIndex)
            disp(['No DVH data available for ' roiName '.']);
            continue
        else
            dvhdata = D.(['Item_' num2str(itemIndex)]).DVHData;
        end
        DVH.(roiName).DVHType = D.(['Item_' num2str(itemIndex)]).DVHType;
        DVH.(roiName).DoseUnits = D.(['Item_' num2str(itemIndex)]).DoseUnits;
        DVH.(roiName).DoseType = D.(['Item_' num2str(itemIndex)]).DoseType;
        DVH.(roiName).VolumeUnits = D.(['Item_' num2str(itemIndex)]).DVHVolumeUnits;
        % DVHData is stored as a datastream in the order D1,V1,D2,V2,...,Dn,Vn.
        % Where Di is the bin width. Di multiplied by DVHDoseScaling equals
        % dose.
        % See DICOM Standard PS 3.3 - C.8.8.4 RT DVH Module
        DVH.(roiName).Dose = dvhdata(1:2:end-1)*D.(['Item_' num2str(itemIndex)]).DVHDoseScaling;
        DVH.(roiName).Volume = dvhdata(2:2:end);
        % Exported MaximumDose in RT Dose file (might be in percent
        % relative to the Prescribed Target Dose)
        DVH.(roiName).MaximumDose = D.(['Item_' num2str(itemIndex)]).DVHMaximumDose;
        DVH.(roiName).MeanDose    = D.(['Item_' num2str(itemIndex)]).DVHMeanDose;
        DVH.(roiName).MinimumDose = D.(['Item_' num2str(itemIndex)]).DVHMinimumDose;
    end
end

