function RD = summedRTDoses(varargin)

noRDinput = length(varargin);

if sum(cellfun(@isstruct,varargin)) ~= noRDinput
    error('All inputs must be structures.')
end

% Use first input as basis
RD = varargin{1};
for ri = 2:noRDinput
    RDi = varargin{ri};
    if ~strcmp(RD.FrameOfReferenceUID,RDi.FrameOfReferenceUID)
        error('Cannot sum doses with different FrameOfReferences.')
    end
    if RD.VoxelDimension ~= RDi.VoxelDimension
        error('Cannot sum doses with different voxel dimensions.')
    end
    if ~strcmp(RD.Unit,RDi.Unit)
        error('Cannot sum doses with different Units.')
    end
    if length(fieldnames(RD.DVH)) ~= length(fieldnames(RDi.DVH))
        error('Cannot sum DVH'' with different ROI''s.')
    end
    
    % account for different matrix size
    R = affineTransformation(RDi,RD);
    
    % Add dose matrices
    RD.vol = RD.vol + R.vol;
    
    if ~isempty(RD.DVH)
        RDROInames = fieldnames(RD.DVH);
        RDiROInames = fieldnames(RDi.DVH);
        for r = 1:length(RDROInames)
            dose = [RD.DVH.(RDROInames{r}).Dose; RDi.DVH.(RDiROInames{strcmp(RDiROInames,RDROInames{r})}).Dose];
            volume = sort([RD.DVH.(RDROInames{r}).Volume; RDi.DVH.(RDiROInames{strcmp(RDiROInames,RDROInames{r})}).Volume],'descend');
            RD.DVH.(RDROInames{r}).Dose = dose;
            RD.DVH.(RDROInames{r}).Volume = volume;
            [minDose,maxDose,avgDose] = DVHDoseExtrema(RD.DVH.(RDROInames{r}));
            RD.DVH.(RDROInames{r}).MaximumDose = maxDose;
            RD.DVH.(RDROInames{r}).MeanDose = avgDose;
            RD.DVH.(RDROInames{r}).MinimumDose = minDose;
        end
    end
end

RD.SummationType = ['Manually summed ' RD.SummationType];