function dvh = CalculateDVH(RD,mask,doseEdges,type)

doseMatrix = RD.vol;
voxelSize = prod(RD.VoxelDimension)/1000; %cm3

relevantVoxels = doseMatrix(mask); % length equals number of voxels in roi

if nargin < 3
    if strcmpi(RD.Unit,'GY')
        doseEdges = 0:0.5:ceil(max(relevantVoxels));
    else
        doseEdges = 0:0.005:ceil(max(relevantVoxels));
    end
end
if nargin < 4
    type = 'Differential';
end

n = hist(relevantVoxels,doseEdges)';

switch lower(type)
    case 'differential'
        dvh = n * voxelSize;
    case 'cumulative'
        c = cumsum(n);
        dvh = (numel(relevantVoxels) - c) * voxelSize;
    otherwise
        error('Unknown input. Type must be "Differential" or "Cumulative"!')    
end

