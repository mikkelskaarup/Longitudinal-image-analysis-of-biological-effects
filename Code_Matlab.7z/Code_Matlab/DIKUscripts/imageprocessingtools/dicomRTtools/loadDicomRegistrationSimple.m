function M = loadDicomRegistrationSimple(str)

if nargin == 0
    dialog_title = 'Select DICOM Registration File to load.';
    [fName,dName] = uigetfile('*.dcm',dialog_title);
    if ~fName % user pressed cancel
        return
    end
    str = fullfile(dName,fName);
end

if exist(str,'dir') == 7 % 'str' is a folder
    fArray = dir([str filesep 'RE*.dcm']);
    REGinfo = dicominfo(fullfile(str,fArray.name));
elseif exist(str,'file')
    REGinfo = dicominfo(str);
else
    error('No DICOM registration file found!');
end


M.FixedFoR = REGinfo.FrameOfReferenceUID;
noRegMatrices = size(fieldnames(REGinfo.RegistrationSequence),1);
for i = 1:noRegMatrices
    if ~strcmp(M.FixedFoR,REGinfo.RegistrationSequence.(['Item_' num2str(i) ]).FrameOfReferenceUID)
        M.MovingFoR = REGinfo.RegistrationSequence.(['Item_' num2str(i) ]).FrameOfReferenceUID;
        matrix = REGinfo.RegistrationSequence.(['Item_' num2str(i) ]).MatrixRegistrationSequence.Item_1.MatrixSequence.Item_1.FrameOfReferenceTransformationMatrix;
        M.T = reshape(matrix,4,4);
    end
end

if nargout == 0
    savedTempName = ['REG_' REGinfo.StationName];
    v = version('-release');
    if str2double(v(1:4)) < 2014
        assignin('base', genvarname(savedTempName), M);
    else
        Vars = evalin('base','who;');
        name = matlab.lang.makeUniqueStrings(matlab.lang.makeValidName(savedTempName),Vars);
        assignin('base', name, M);
    end
end