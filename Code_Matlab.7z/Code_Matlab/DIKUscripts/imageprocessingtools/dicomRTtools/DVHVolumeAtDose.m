function V = DVHVolumeAtDose(DVH,d)
%%%
% MLJ March 2015
% Calculate V5, V10 eg. absolute dose
%

if isempty(DVH)
    V = [];
else
    dose = cumsum(DVH.Dose);
    volume = DVH.Volume/DVH.Volume(1);
    ind = find(dose >= d,1,'first');
    
    if isempty(ind)
        V = 0;
    elseif dose(ind) == d
        V = volume(ind);
    else % Use linear interpolation to find exact volume
        V = interp1(dose,volume,d);
    end

end