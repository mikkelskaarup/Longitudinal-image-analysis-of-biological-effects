function t = centroidDifference(img1,img2,dimt1,dimt2)

% estimate centroid for both scans and initialize registration
[id]=kmeans(img2(:),2);
cls=reshape(id,size(img2));
cls=2-cls;
props2=regionprops(cls,'Centroid');
[id]=kmeans(img1(:),2);
cls=reshape(id,size(img1));
cls=2-cls;
props1=regionprops(cls,'Centroid');
cDiff = props1.Centroid.*dimt1 - props2.Centroid.*dimt2;


t(1)=cDiff(2); t(2)=cDiff(1); t(3)=cDiff(3);