function M = getMaskFromContour2(S,img)

M = zeros(size(img.vol));

slices = fieldnames(S);
sliceNumbers = regexp(slices,'(?<=Slice_)\d+','match');
numbers = cellfun(@cell2mat,sliceNumbers,'UniformOutput',0);
sliceNumbers = numbers(~cellfun(@isempty,numbers));

noSlices = length(sliceNumbers);

for i=1:noSlices
    contourNames = fieldnames(S.(['Slice_' sliceNumbers{i}]));
    noContours = length(contourNames);
    for j = 1:noContours
        x = S.(['Slice_' sliceNumbers{i}]).(contourNames{j}).x;
        y = S.(['Slice_' sliceNumbers{i}]).(contourNames{j}).y;
        tmpMask = roipoly(img.X(1,:,j),img.Y(:,1,j),img.vol(:,:,j),x,y);
        
        M(:,:,str2double(sliceNumbers{i})) = M(:,:,str2double(sliceNumbers{i})) + tmpMask;
    end
end

% Correct for ROI in ROI
M(M==2)=0;
% Convert to logic
M = M~=0;