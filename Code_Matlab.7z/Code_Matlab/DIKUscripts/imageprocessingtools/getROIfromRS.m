function [ROInames,ROInumbers] = getROIfromRS(RS)

ROIitems = fieldnames(RS.StructureSetROISequence);
numberOfROIs = length(ROIitems);

ROInames = cell(numberOfROIs,1);
ROInumbers = zeros(numberOfROIs,1);
% Extract structure Names and ROI numbers
for item = 1:numberOfROIs
    ROInames{item} = RS.StructureSetROISequence.(ROIitems{item}).ROIName;
    ROInumbers(item) = RS.StructureSetROISequence.(ROIitems{item}).ROINumber;
end