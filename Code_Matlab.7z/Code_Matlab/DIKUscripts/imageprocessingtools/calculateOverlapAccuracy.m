function A = calculateOverlapAccuracy(brain,tv,tfv)

% True positive
TP = tv & tfv;
% True negative
TN = brain & ~(tv|tfv);

A = ( sum(TP(:)) + sum(TN(:)) ) / sum(brain(:));