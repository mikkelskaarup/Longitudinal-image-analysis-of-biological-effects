function C = getContourFromMask(mask,img,contourType,sortPointsMethod)

if nargin < 3
    contourType = 'Inner';
end
if nargin < 4
    sortPointsMethod = 'MINDIST';
end

noSlices = size(img.vol,3);
totalNumberOfPoints = 0;

for i=1:noSlices
    if sum(sum(mask(:,:,i))) ~=0
        imgx = img.X(1,:,i); imgy = img.Y(:,1,i);
        [L,num] = bwlabel(mask(:,:,i));
        
        for j = 1:num
            tempMask = L==j;
            coor = mask2poly(tempMask,contourType,sortPointsMethod);
            x = imgx(coor(:,1)); y = imgy(coor(:,2));
            C.(['Slice_' num2str(i)]).(['Contour' num2str(j)]).x = x';
            C.(['Slice_' num2str(i)]).(['Contour' num2str(j)]).y = y;
        end
        
        totalNumberOfPoints = totalNumberOfPoints + numel(coor(:,1));
    end
end

C.totalNumberOfPoints = totalNumberOfPoints;