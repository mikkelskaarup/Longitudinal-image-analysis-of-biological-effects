function margin = estimateRequiredMargin(vol1,vol2,voxelDimension,innerORouter)
% Estimate the margin added to vol1 that is required to contain vol2
% vol1 and vol2 must be binary masks

if nargin < 4
    innerORouter = 'outer';
end

distMapVol1 = bwdistsc(vol1,voxelDimension);
marginMaskVol2 = gbmRimMask(vol2,innerORouter);
diffMap = distMapVol1.*marginMaskVol2;
distances = diffMap(diffMap~=0);
if ~isempty(distances)
    margin = max(distances);
else
    margin = 0;
end