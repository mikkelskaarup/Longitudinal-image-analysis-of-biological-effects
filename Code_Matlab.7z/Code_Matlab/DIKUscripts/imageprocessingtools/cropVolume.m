function cS = cropVolume(S,RS,roi,offset)

cS = S;

RSnames = fieldnames(RS);
dim = size(S.vol);
aspect = [S.info.PixelSpacing' S.Z(1,1,2)-S.Z(1,1,1)];

mask = zeros(size(S.vol));
ind = find(ismember(fieldnames(RS),roi));

if isempty(ind)
    warning('No structure match ''roi'' name. Volume not cropped.')
    return
end

for i = 1:length(ind)
    mask = mask | createMaskFromROI(RS.(RSnames{ind(i)}),S,dim);
end

% x-extrema
for x = 1:dim(1)
    if sum(sum(mask(x,:,:))) > 0
        xmin = x;
        break
    end
end
for x = xmin:dim(1)
    if sum(sum(mask(x,:,:))) == 0
        xmax = x-1;
        break
    end
end
% y-extrema
for y = 1:dim(2)
    if sum(sum(mask(:,y,:))) > 0
        ymin = y;
        break
    end
end
for y = ymin:dim(2)
    if sum(sum(mask(:,y,:))) == 0
        ymax = y-1;
        break
    end
end
% z-extrema
for z = 1:dim(3)
    if sum(sum(mask(:,:,z))) > 0
        zmin = z;
        break
    end
end
for z = zmin:dim(3)
    if sum(sum(mask(:,:,z))) == 0
        zmax = z-1;
        break
    end
end

xoff = ceil(offset/aspect(1));
yoff = ceil(offset/aspect(2));
zoff = ceil(offset/aspect(3));

cS.vol = S.vol(xmin-xoff:xmax+xoff,ymin-yoff:ymax+yoff,zmin-zoff:zmax+zoff);
cS.X = S.X(xmin-xoff:xmax+xoff,ymin-yoff:ymax+yoff,zmin-zoff:zmax+zoff);
cS.Y = S.Y(xmin-xoff:xmax+xoff,ymin-yoff:ymax+yoff,zmin-zoff:zmax+zoff);
cS.Z = S.Z(xmin-xoff:xmax+xoff,ymin-yoff:ymax+yoff,zmin-zoff:zmax+zoff);

cS.ReferenceObject = getRobject(cS,'world');
% cS.ippx = S.ippx(zmin-zoff:zmax+zoff);
% cS.ippy = S.ippy(zmin-zoff:zmax+zoff);
% cS.ippz = S.ippz(zmin-zoff:zmax+zoff);
% cS.z = S.z(zmin-zoff:zmax+zoff);



