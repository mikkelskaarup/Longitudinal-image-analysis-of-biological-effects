function M = lineMask(x,y,p,n)

[X,Y] = meshgrid(x,y);

a = n./n(1);
a = a(2);

b = p(2)-a*p(1);

M = Y < a.*X + b; 

