% Calculate distances between contour1, defined by the points C1, and
% contour2, defined by C2. Points of C2 included in contour1 are not
% included.

function [d, C1i, C2i] = calculateContourDistances(C1,C2)

%%% Find points in C2 not inside C1
% Creating triangulation of contour1
if strcmp(version('-release'),'2014b')
    DT_C1 = delaunayTriangulation(C1);
else
    DT_C1 = delaunayTri(C1);
end
[S1.faces, S1.vertices] = freeBoundary(DT_C1);
inside = inpolyhedron(S1,C2);
C2OutsideC1 = C2(~inside,:);

%%% Find minimum distance between points in C2 (not enclosed by C1) and
%%% points in C1
% Pre-allocate
C1closestC2notInside = NaN(size(C2OutsideC1));
for i = 1:size(C2OutsideC1,1)
    % Estimate vector between C2(i) and all points in C1
    v = C1 - repmat(C2OutsideC1(i,:),size(C1,1),1);
    % Estimate length of vectors, ie. distance between point C2(i) and
    % all points on C1
    d = sqrt(sum(v.^2,2));
    % Find the minimum distance between point C2(i) and all points on C1
    % ie. closest point
    [~,k] = min(d);
    C1closestC2notInside(i,:) = C1(k,:);
end

displacementVectors = C2OutsideC1 - C1closestC2notInside;

distances = sqrt(sum(displacementVectors.^2,2));

[d,j] = max(distances);

% Return index of points
[~,C1i]=ismember(C1closestC2notInside(j,:),C1,'rows');
[~,C2i]=ismember(C2OutsideC1(j,:),C2,'rows');
