function [coor,M] = GetImagePositionPatientFromHdr(nii)

sMatrix = [nii.hdr.hist.srow_x; nii.hdr.hist.srow_y; nii.hdr.hist.srow_z];

qb = nii.hdr.hist.quatern_b;
qc = nii.hdr.hist.quatern_c;
qd = nii.hdr.hist.quatern_d;

if nii.hdr.hist.sform_code > 0
    m = 'Method3';
elseif nii.hdr.hist.qform_code > 0
    m = 'Method2';
elseif ~isequal(sMatrix,zeros(3,4))
    m = 'Method3';
elseif ~(qb == 0 && qc == 0 && qd == 0)
    m = 'Method2';
else
    error('Unable to determine transform');
end

switch m
    case 'Method2'
        qa = sqrt(1-qb^2-qc^2-qd^2);
        q = nii.hdr.dime.pixdim(1);
        if q ~= 1 && q ~= -1
            q = 1;
        end
        R = [qa^2+qb^2-qc^2-qd^2 , 2*(qb*qc-qa*qd) , 2*(qb*qd+qa*qc);
            2*(qb*qc + qa*qd) , qa^2+qc^2-qb^2-qd^2 , 2*(qc*qd-qa*qb);
            2*(qb*qd-qa*qc) , 2*(qc*qd + qa*qb) , qa^2+qd^2-qc^2-qb^2];
        
        if R(1,1) < 0
            i = 0;
        else
            i = nii.hdr.dime.dim(2)-1;
        end
        if R(2,2) < 0
            j = 0;
        else
            j = nii.hdr.dime.dim(3)-1;
        end
        
        k = 0;

        S = [nii.hdr.dime.pixdim(2) 0 0 0;
             0 nii.hdr.dime.pixdim(3) 0 0;
             0 0 nii.hdr.dime.pixdim(4) 0;
             0 0 0 1];
         
        Tipp = [1 0 0 nii.hdr.hist.qoffset_x;
                0 1 0 nii.hdr.hist.qoffset_y;
                0 0 1 nii.hdr.hist.qoffset_z;
                0 0 0 1]; 
            
        T0 = [0 0 0 nii.hdr.dime.pixdim(2);
              0 0 0 nii.hdr.dime.pixdim(3);
              0 0 0 nii.hdr.dime.pixdim(4);
              0 0 0 0];
        
        Raff = eye(4);
        Raff(1:3,1:3) = R;
    
        M = Raff*Tipp-T0;
                
        coor = R * [i; j; q*k] .* ...
           [nii.hdr.dime.pixdim(2);
            nii.hdr.dime.pixdim(3);
            nii.hdr.dime.pixdim(4)] + ...
           [nii.hdr.hist.qoffset_x;
            nii.hdr.hist.qoffset_y;
            nii.hdr.hist.qoffset_z];
    case 'Method3'
        if sMatrix(1,1) < 0
            i = 0;
        else
            i = nii.hdr.dime.dim(2)-1;
        end
        if sMatrix(2,2) < 0
            j = 0;
        else
            j = nii.hdr.dime.dim(3)-1;
        end
        
        k = 0;
        
        coor = sMatrix * [i;j;k;1];
    otherwise
        error('Bugger');
end

coor(1:2) = -coor(1:2);
