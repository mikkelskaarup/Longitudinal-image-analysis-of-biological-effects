function [ f df ] = cf_SYM_NMI_SVF(p,dim_warp, mu,pts,img1,img2,trival1,trival2,warp_offset,im_offset,warp_scale,im_scale,pn )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
[f1 df1]=cf_NMI_SVF(p,dim_warp, mu,pts,img1,trival1,warp_offset,im_offset,warp_scale,im_scale,pn);
%[f2 df2]=cf_NMI_SVF(-p,dim_warp, mu,pts,img2,trival2,warp_offset,im_offset,warp_scale,im_scale,pn);

df=df1;
f=f1;
end

