function [f df]=cf_rigidNMI_3dpw(p, I, points,center, Rtrival,scale,det)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);




%Rotation matrices
R=[p(1) p(2) p(3);p(4) p(5) p(6); p(7) p(8) p(9)];
dR1=[1 0 0; 0 0 0 ;0 0 0];
dR2=[0 1 0; 0 0 0 ;0 0 0];
dR3=[0 0 1; 0 0 0 ;0 0 0];
dR4=[0 0 0; 1 0 0 ;0 0 0];
dR5=[0 0 0; 0 1 0 ;0 0 0];
dR6=[0 0 0; 0 0 1 ;0 0 0];
dR7=[0 0 0; 0 0 0 ;1 0 0];
dR8=[0 0 0; 0 0 0 ;0 1 0];
dR9=[0 0 0; 0 0 0 ;0 0 1];


t1=zeros(3,1);t1(1)=p(10);t1(2)=p(11);t1(3)=p(12);

%derived rotation matrices
size_points=size(points,1);
pts=(points-repmat(center,size_points,1))*R+repmat(t1',[size_points 1])+repmat(center,size_points,1);
%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


tic
[res d(:,1) d(:,2) d(:,3)]=NMI(pts,Rtrival+2,I+2,[0 0 0],scale,det);
toc
%d=-d;
d=d./repmat(scale,size(d,1),1);

df(10)=sum(d(:,1));
df(11)=sum(d(:,2));
df(12)=sum(d(:,3));
df(1)=sum(sum((points-repmat(center,size_points,1))*dR1.*d,2));
df(2)=sum(sum((points-repmat(center,size_points,1))*dR2.*d,2));
df(3)=sum(sum((points-repmat(center,size_points,1))*dR3.*d,2));
df(4)=sum(sum((points-repmat(center,size_points,1))*dR4.*d,2));
df(5)=sum(sum((points-repmat(center,size_points,1))*dR5.*d,2));
df(6)=sum(sum((points-repmat(center,size_points,1))*dR6.*d,2));
df(7)=sum(sum((points-repmat(center,size_points,1))*dR7.*d,2));
df(8)=sum(sum((points-repmat(center,size_points,1))*dR8.*d,2));
df(9)=sum(sum((points-repmat(center,size_points,1))*dR9.*d,2));

%disp([res p']);
f=6-res;