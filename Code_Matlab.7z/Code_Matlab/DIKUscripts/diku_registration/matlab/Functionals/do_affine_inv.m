function [pts R]=cf_rigidNMI_3dpw(p, points,center)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);




%Rotation matrices
R=[p(1) p(2) p(3);p(4) p(5) p(6); p(7) p(8) p(9)];

t1=zeros(3,1);t1(1)=p(10);t1(2)=p(11);t1(3)=p(12);

%derived rotation matrices
size_points=size(points,1);
pts=(points-repmat(center,size_points,1))*R+repmat(t1',[size_points 1])+repmat(center,size_points,1);

R=inv(R)';

%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


