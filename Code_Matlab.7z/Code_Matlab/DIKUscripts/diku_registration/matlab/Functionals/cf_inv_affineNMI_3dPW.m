function [f df]=cf_inv_affineNMI_3dPW(p, I, points,center, Rtrival,scale,det)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);
x=p;
y1=1/(((1+x(1))*(1+x(5))*(1+x(9)))+(x(4)*x(8)*x(3))+(x(7)*x(2)*x(6))-((1+x(1))*x(8)*x(6))-(x(4)*x(2)*(1+x(9)))-(x(7)*(1+x(5))*x(3)));
%compute the transposed co-factor matrix


y2=[((1+x(5))*(1+x(9))-x(6)*x(8)) -(x(4)*(1+x(9))-x(7)*x(6)) (x(4)*x(8)-x(7)*(1+x(5)));
    -(x(2)*(1+x(9))-x(8)*x(3)) ((1+x(1))*(1+x(9))-x(7)*x(3)) -((1+x(1))*x(8)-x(7)*x(2));
    (x(2)*x(6)-(1+x(5))*x(3)) -((1+x(1))*x(6)-x(4)*x(3)) ((1+x(1))*(1+x(5))-x(4)*x(2)) ];

%Make the inverse
R=y1*y2;

%compute the derivative of the determinant wrt. the parameters
dy1=-1/(((1+x(1))*(1+x(5))*(1+x(9)))+(x(4)*x(8)*x(3))+(x(7)*x(2)*x(6))-((1+x(1))*x(8)*x(6))-(x(4)*x(2)*(1+x(9)))-(x(7)*(1+x(5))*x(3)))^2;
dy11=dy1*((1+x(5))*(1+x(9))-x(8)*x(6));
dy12=dy1*(x(7)*x(6)-x(4)*(1+x(9)));
dy13=dy1*(x(4)*x(8)-x(7)*(1+x(5)));
dy14=dy1*(x(8)*x(3)-x(2 )*(1+x(9)));
dy15=dy1*((1+x(1))*(1+x(9))-x(7)*x(3));
dy16=dy1*(x(7)*x(2)-(1+x(1))*x(8));
dy17=dy1*(x(2)*x(6)-(1+x(5))*x(3));
dy18=dy1*(x(4)*x(3)-(1+x(1))*x(6));
dy19=dy1*((1+x(1))*(1+x(5))-x(4)*x(2));

%compute the derivatives of the transposed co-factor matrix wrt the parameters and
%asemble with the derivative of the determinant using the product rule

dR1=dy11*y2+y1*[0 0 0;
    0 (1+x(9)) -x(8) ;
    0 -(x(6)) (1+x(5))];

dR2=dy12*y2+y1*[0 0 0;
    -(1+x(9)) 0 x(7);
    x(6) 0 -x(4) ];

dR3=dy13*y2+y1*[0 0 0;
    x(8) -x(7) 0;
    -(1+x(5)) x(4) 0];

dR4=dy14*y2+y1*[0 -((1+x(9))) x(8);
    0 0 0;
    0 (x(3)) -x(2) ];

dR5=dy15*y2+y1*[(1+x(9)) 0 -x(7);
    0 0 0;
    -x(3) 0 (1+x(1)) ];

dR6=dy16*y2+y1*[-x(8) x(7) 0;
    0 0 0;
    x(2) -((1+x(1))) 0];

dR7=dy17*y2+y1*[0 x(6) -(1+x(5));
0 -x(3) x(2);
    0 0 0];

dR8=dy18*y2+y1*[-x(6) 0 x(4);
    x(3) 0 -(1+x(1)) ;
    0 0 0];

dR9=dy19*y2+y1*[(1+x(5)) -x(4) 0;
    -x(2) (1+x(1)) 0;
    0 0 0];

%Rotation matrices



t1=zeros(3,1);t1(1)=p(10);t1(2)=p(11);t1(3)=p(12);

%derived rotation matrices
size_points=size(points,1);
pts=(points-repmat(center,size_points,1)-repmat(t1',size_points,1))*R+repmat(center,size_points,1);
%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


tic
%[res d(:,1) d(:,2) d(:,3)]=NMI(pts,Rtrival+2,I+2,[0 0 0],scale,det);

[res d(:,1) d(:,2) d(:,3)]=PNorm(pts,Rtrival+2,I+2,[0 0 0],scale,det,2);
toc
%d=-d;
d=d./repmat(scale,size(d,1),1);
df(10:12)=-sum(d*R');
%df(10)=sum(d(:,1));
%df(11)=sum(d(:,2));
%df(12)=sum(d(:,3));
df(1)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR1.*d,2));
df(2)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR2.*d,2));
df(3)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR3.*d,2));
df(4)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR4.*d,2));
df(5)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR5.*d,2));
df(6)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR6.*d,2));
df(7)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR7.*d,2));
df(8)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR8.*d,2));
df(9)=sum(sum((points-repmat(center,size_points,1)-repmat(t1',size_points,1))*dR9.*d,2));

disp([res p']);
f=res;