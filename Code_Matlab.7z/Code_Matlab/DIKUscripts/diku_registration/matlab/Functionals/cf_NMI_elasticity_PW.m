function [f df]=cf_NMI_elasticity_PW(p,lambda, mu,dfdx,dfdp,pts,img, val,simp,Rtrival,offset,p_space,scale,pn,weight)

%function [f df]=cost_fun_msh3d_mex(p, lambda, mu, Ad, grid,I, A, value,simp, offset, scale,p_space)
N=numel(p)/3;
p=reshape(p,numel(p)/3,3);
df=zeros(numel(p),1);
%p(1,:)=ones(1,4)*-0.1;
%  disp(max(p));
%  disp(min(p));
%r=0;
%drdp=zeros(numel(p),1);
pt=reshape(p,size(val));
[phi , ~, ~, d1, d2, d3]=SplineInterpolation_tbb(pts,pt,offset,p_space);
clear pt ;
% I=eye(3);
% for i=1:size(pts,1)
% a=det(I+[d1(i,:);d2(i,:);d3(i,:)]);
% if(a<0)
%     f=inf;
%      disp('Inf')
%     return;
% end
% end
phi=pts+phi;

tic;



[drdp r f]=EigenDerivN_tbb(p/p_space(1),double(simp),double(dfdx),lambda,mu);
if (f==Inf)
    disp('Inf')
    return
end
if (sum(isnan(drdp(:)))>0)
    disp('Inf (dfdp)')
    return
end

% [drdp r f]=EigenDerivN_tbbFastOgden(p/p_space(1),double(simp),double(dfdx),lambda,mu);
% if (f==Inf)
%     disp('Inf')
%     return
% end
toc
%drdp=reshape(drdp,size(p,1),2)%*0;r=0;
%drdp=reshape(drdp,4,size(p,1   ))'*0; r=0;
%resO=res;IphiO=Iphi;phiO=phi; dDdpO=dDdp;dDdphiO=dDdPhi;p0=p;delt=p*0;delt(51,4)=.000001;p=p0+delt;
% pt=reshape(p,size(val));
% [phi]=splineinterpolation(pts,p,offset,p_space);
% phi=pts+phi;
% tic;
%[f d(:,1) d(:,2) d(:,3)]=PNorm(phi,Rtrival,img,[0 256 0 256],[257 257],[0 0 0],[1 1 1],pn);
%det=ones(size(pts,1),1);


tic
%[f d(:,1) d(:,2) d(:,3)]=NMI3D_DET_PW3(phi,Rtrival+2,img+2,[0 130 0 130],[140 140],[0 0 0],[1 1 1],weight);
[f d(:,1) d(:,2) d(:,3)]=NMI(phi,Rtrival+2,img+2,[0 0 0],scale,weight);
%toc
toc
%[dfdx f]=correlationratio(phi,I,1,bins,no_bins);
%dphidp=repmat(eye(4),size(x,1),1);
%Iphi=interpolation4d(phi, I, 1);
% % [dfdx f]=correlation_ratio3d_2(I, center,p, A, bins, no_bins);
% % %res=(Iphi-RtriVal);
% % dDdp=zeros(size(p));
% % for i=1:3
     dDdp=dDdPFunc(double(d),double(dfdp),double(simp'-1),double(N));
% % end
%dDdp(:)=dDdp(:);
% dDdp(1)=100;

 f=(6-f+r);
% disp([f r]);
 df=(drdp(:)+dDdp(:));
%f=(6-f);
disp([f r]);
%df=(dDdp(:));

