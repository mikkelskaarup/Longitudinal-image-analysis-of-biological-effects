function [f, df]=cf_NMI_SVF_BWD(p,dim_warp, mu,pts,img,Rtrival,warp_offset,im_offset,warp_scale,im_scale,pn)


%reshape of deformation parameters to LxNxMx3
p=reshape(p,dim_warp);

%Compute deformation without derivatives
[pts3]=SS_Trap_1st(double(pts),double(p),double(warp_offset),double(warp_scale),double(40),double(5));


%for all images compuete similarity
for i=1:size(Rtrival,2)
[f(i) d(:,1,i) d(:,2,i) d(:,3,i)]=NMI(pts3,squeeze(Rtrival(:,i))+2,img+2,im_offset,im_scale,double(ones(size(squeeze(Rtrival(:,i))))));
end

%sum function value and derivatives
f=squeeze(sum(f));
d=squeeze(sum(d,3));

%compute derivatives with respect to p (deformation parameters)
[pts df]=SS_Trap_2nd(double(pts),double(p),double(warp_offset),double(warp_scale),double(40),double(5),d);

%regularize p
r=(0.5*mu)*sum(p(:).^2);

%add derivatives
df=df+mu*p(:);
 f=(2*size(Rtrival,2)-f)+r;

