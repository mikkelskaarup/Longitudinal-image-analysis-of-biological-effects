function [ pts]=cf_rigidNMI_3dPW_Affine(p, points,center)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)





t11=p(10);t12=p(11);t13=p(12);

%Rotation matrices
S=[p(1) p(2) p(3);p(4) p(5) p(6);p(7) p(8) p(9)]+eye(3);
t1=zeros(3,1);t1(1)=t11;t1(2)=t12;t1(3)=t13;

S=inv(S);
%derived rotation matrices

size_points=size(points,1);
pts=(points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*S'+repmat(center,size_points,1);

%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


