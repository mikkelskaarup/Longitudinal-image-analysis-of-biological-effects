function [ f df ] = cf_SYM_NMI_SVF_TEMPLATE(P,dim_warp, mu,pts,img,org_img,trival,org_trival,warp_offset,im_offset1,warp_scale,im_scale1,pn )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
f=0;
s=prod(dim_warp);
parfor i=1:size(trival,2)
  p=P((i-1)*s+1:(i)*s);
[f1(i), df1(:,i)]=cf_NMI_SVF_FWD(p,dim_warp, mu,pts,img,squeeze(org_trival(:,i)),warp_offset,im_offset1,warp_scale,im_scale1,pn);
[f2(i), df2(:,i)]=cf_NMI_SVF_BWD(-p,dim_warp, mu,pts,squeeze(org_img(:,:,:,i)),trival,warp_offset,im_offset1,warp_scale,im_scale1,pn);

%minus df2 as -p is passed to cf_NMI_SVF_BWD
end;
f=sum(f1+f2);
df=df1(:)-df2(:);
end

