function [f df]=cf_rigidNMI_3dpw_hessian_scale(p, I, points,center, Rtrival,scale,det)
for i=1:size(I,5)
  [f_(i) df_(:,i)]=cf_rigidNMI_3dpw_hessian(p, squeeze(I(:,:,:,:,i)), points,center,squeeze(Rtrival(:,:,i)),scale,det);
end
f=sum(f);
df=sum(df,2)