function [f df]=cf_NMI_SVF_AFF(p,dim_warp, mu,pts,img,Rtrival,warp_offset,im_offset,warp_scale,im_scale,pn,aff,center,aff_global,center_global)

%function [f df]=cost_fun_msh3d_mex(p, lambda, mu, Ad, grid,I, A, value,simp, offset, scale,p_space)
p=reshape(p,dim_warp);
[pts3]=SS_Trap_1st(double(pts),double(p),double(warp_offset),double(warp_scale),double(40),double(5));

[pts3 invR_Global]=do_affine_inv(aff_global(:),pts3,center_global);
[pts3 invR_Local]=do_affine_inv(aff(:),pts3,center);

[f d(:,1) d(:,2) d(:,3)]=NMI(pts3,Rtrival+2,img+2,im_offset,im_scale,double(ones(size(Rtrival))));

d=d*invR_Local'*invR_Global';


[pts df]=SS_Trap_2nd(double(pts),double(p),double(warp_offset),double(warp_scale),double(40),double(5),d);
r=(0.5*mu)*sum(p(:).^2);
df=df+mu*p(:);
disp([2-f r])
 f=(2-f)+r;

