function [f df]=cf_inverse_est(p,lambda, mu,dfdx,dfdp,pts,ptsT,val,offset,simp,p_space)
N=numel(p)/3;
p=reshape(p,numel(p)/3,3);
df=zeros(numel(p),1);
pt=reshape(p,size(val));
[phi]=SplineInterpolation_tbb_compact(pts,pt,offset,p_space);
phi=pts+phi;
% clear pt ;
% 
%  [drdp r f]=EigenDerivN_tbb(p/p_space(1),double(simp),double(dfdx),lambda,mu);
%  if (f==Inf)
%      disp('Inf')
%      return
% end
r=0;
dpts=phi-ptsT;
f=sum(dpts(:).^2);
d=2*(dpts);
dDdp=dDdPFunc(double(d),double(dfdp),double(simp'-1),double(N));
f=(f+r);
disp([r]);
disp([f]);
%df=(drdp(:)+dDdp(:));
df=(dDdp(:));

