%ipath = '/Volumes/Windows/GBM/Recurrence/DicomFiles';
ipath = '/Volumes/MLJ HD/GBM/Recurrence/DicomFiles';
%ipath='/Users/MLJ/Documents/Dicom';
%ipath='H:\Windows\GBM\Recurrence\DicomFiles';
%opath='H:\Windows\DIKU_registration\RegOutput';
opath='/Volumes/MLJ HD/GBM/Recurrence/RegOutput';

%%

CREATEMONTAGE = 1;

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;

%
warning off all

%patients = {'Patient03','Patient09','Patient19','Patient22','Patient23','Patient30','Patient50','Patient0l','Patient0t','Patient0ad','Patient0o','Patient0r'};
patients = {'Patient19'};


for j = 1:length(patients)
    dpath=fullfile(ipath,patients{j});
    outpath=fullfile(opath,patients{j});
    if ~exist(outpath,'file')
        mkdir(outpath)
    end
    
    % get number of MR scans in folder
    MRIbaseline = dir(fullfile(dpath,'Baseline','MR','*t1*tra*'));
    baselineMR = MRIbaseline(1).name;
    followupStudies = dir(fullfile(dpath,'*ollow*'));
    noFollowup = length(followupStudies);
    
    fDirs = cell(noFollowup+1,1);
    fDirs{1} = fullfile(dpath,'Baseline','MR',baselineMR);
    for i = 1:noFollowup
        currentFollowupStudy = followupStudies(i).name;
        t1FolderName = dir(fullfile(dpath,currentFollowupStudy,'MR','*t1*tra*'));
        fDirs{i+1} = fullfile(dpath,currentFollowupStudy,'MR',t1FolderName.name);
    end
    
    % Register all followups to baseline
    idx = ones(1,noFollowup);
    jdx = (1:noFollowup) + 1;
    
    
    for i=4%:length(idx)
        
        followupNumber = regexp(followupStudies(i).name,'\d+','match');
        if ~isempty(followupNumber)
            followupNumber = followupNumber{1};
        else
            followupNUmber = num2str(jdx(i));
        end
        
        % read images
        MRI1=loadDicomFiles(fDirs{idx(i)},'showwaitbar',0);
        MRI2=loadDicomFiles(fDirs{jdx(i)},'showwaitbar',0);
        
        img1=double(MRI1.vol);
        img2=double(MRI2.vol);
        
        %get image resolution
        dimt1=[MRI1.info.PixelSpacing' abs(MRI1.Z(1,1,1)-MRI1.Z(1,1,2))];
        dimt2=[MRI2.info.PixelSpacing' abs(MRI2.Z(1,1,1)-MRI2.Z(1,1,2))];
        
        % Image size [mm]
        S1=round(size(img1).*dimt1);
        S2=round(size(img2).*dimt2);
        Smax=max(S1,S2);
        % rescale images to conform with 160 bins (good values are between 80 and 256)
        img1=img1-min(img1(:));
        img2=img2-min(img2(:));
        img2=img2/max(img2(:))*160;
        img1=img1/max(img1(:))*160;
        
        % Load rigid registration from REGISTER_RH_rigid
        p = load(fullfile(outpath,['MR' followupNumber '_to_MR0_RH_' patients{j} '_rigid']));
        p3 = p.p;
        
        %define center of rotation (mm from corner of img1)
        center=[floor(Smax(1)/2) floor(Smax(2)/2) floor(Smax(3)/2)]
        
        %resample img1 (1mm resolution) to prepare non-rigid registration
        resolution_rigid=[1 1 1];
        [X1, X2, X3]=ndgrid(0:resolution_rigid(2):Smax(1),0:resolution_rigid(1):Smax(2),0:resolution_rigid(3):Smax(3));
        ptsresample=[X1(:) X2(:) X3(:)];
        [pts3]=do_sym_affine(p3(:),ptsresample,center);
        Rtrival=(SplineInterpolation_lin(pts3,img1,[0 0 0],dimt1));
        img11=reshape(Rtrival,size(X1));
        
        %setting up non-rigid registration
        resolution=2;
        [X1, X2, X3]=ndgrid(0:resolution:Smax(1),0:resolution:Smax(2),0:resolution:Smax(3));
        pts=[X1(:) X2(:) X3(:)];
        Itrival=(SplineInterpolation_tbb(pts,img11,[0 0 0],resolution_rigid));
        %Itrival=(SplineInterpolation_tbb(pts,img1,[0 0 0],dimt1));
        Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));
        
        % extracting positions with information
        no=find(Itrival+Jtrival>0);
        
        % initializ to 0
        pp4=zeros([30 30 30 3]);
        ww=[40 40 40];
        
        %no. of points in deformation grid
        grid_size=45;
        
        % set decreasing grid size of deformation field
        pyramidLevels = [40 20 10];
        tic
        for pl=1:length(pyramidLevels)
            if pl==1
                curr_options = options;
            elseif pl==2
                curr_options = options2;
            elseif pl == 3
                curr_options = options3;
            elseif pl == 4
                curr_options = options4;
            else
                error('Bummer!!')
            end
            ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
            %resampling deformation field to new resolution
            %resampling deformation field to new resolution
            [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
            tpts=[XX1(:) XX2(:) XX3(:)]*pyramidLevels(pl);
            n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
            %setting scale and offset of img11
            scale=[1 1 1];
            offset=[1 1 1]*0;
            
            %setting size of deformation grid and parametrization
            val=ones([grid_size grid_size grid_size 3]);
            ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
            p4=reshape(n,size(val));
            offset2=-ww;
            
            % Estimate warp-field by nMutualInformation
            pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),curr_options,size(p4),(0.0005),pts(no,:),img11,img2,Jtrival(no),Itrival(no),offset,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);
            pp4=reshape(pp4,size(p4));
            
        end
        toc
        saveparams(fullfile(outpath,['MR' followupNumber '_to_MR0_RH_' patients{j} '_deformable']),pp4);
        
        % Reconstruct and save
        [X11, X21, X31]=ndgrid(0:dimt1(1):S1(1)-dimt1(1),0:dimt1(2):S1(2)-dimt1(2),0:dimt1(3):S1(3)-dimt1(3));
        org_pts1=[X11(:), X21(:), X31(:)];
        [X12, X22, X32]=ndgrid(0:dimt2(1):S2(1)-dimt2(1),0:dimt2(2):S2(2)-dimt2(2),0:dimt2(3):S2(3)-dimt2(3));
        org_pts2=[X12(:), X22(:), X32(:)];
        % Original
        %n1=SplineInterpolation_lin(org_pts1+repmat(0*dimt1,numel(X11),1),double(MRI1.vol),[0 0 0],dimt1);
        %n11=SplineInterpolation_lin(org_pts2+repmat(0*dimt2,numel(X12),1),double(MRI2.vol),[0 0 0],dimt2);
        
        % Inverse transform
        [~, ipts3]=do_sym_affine(p3(:),org_pts1,center);
        % non-rigid
        inr_pts = SS_Trap_1st(ipts3,-pp4,offset2,ww,40,5);
        n3=SplineInterpolation_lin(inr_pts+repmat(0*dimt2,numel(X11),1),double(MRI2.vol),[0 0 0],dimt2);

        
        % Forward transform
        nr_pts=SS_Trap_1st(org_pts2,pp4,offset2,ww,40,5);
        pts3=do_sym_affine(p3(:),nr_pts,center);
        n33=SplineInterpolation_lin(pts3+repmat(0*dimt1,numel(X12),1),double(MRI1.vol),[0 0 0],dimt1);
        
        
        img2deformable = reshape(n3,size(X11));
        img1deformable = reshape(n33,size(X12));
                
        save([outpath filesep 'MR' followupNumber 'rigid+deform to MR0'],'img2deformable')
        save([outpath filesep 'MR0rigid+deform to MR' followupNumber],'img1deformable')
    end
end