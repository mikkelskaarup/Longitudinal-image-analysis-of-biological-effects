dpath='H:\Windows\GBM\Recurrence\NiftiFiles\Patient0t\';
dpath='/Users/MLJ/Documents/Nifti/Patient0t/';


no_cores=4;

try
    parpool(no_cores)
catch
end

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;
options4=options;
options4.MaxIter=100;

CTfile = dir([dpath '*CT.nii*']);
MRIfilesT1 = dir([dpath '*t1.nii*']);
noMRIfilesT1 = size(MRIfilesT1,1);
baselineMR = MRIfilesT1(1).name;
baselineCT = CTfile.name;
%%
warning off all

for i=2:2%noMRIfilesT1
    
    % read images
    MRI1=load_untouch_nii(fullfile(dpath,baselineMR));
    MRI2=load_untouch_nii(fullfile(dpath,MRIfilesT1(i).name));
    img1=double(MRI1.img);
    img2=double(MRI2.img);
    
    %get image resolution
    dimt1=MRI1.hdr.dime.pixdim(2:4);
    dimt2=MRI2.hdr.dime.pixdim(2:4);
    
    % Image size [mm]
    S1=round(size(img1).*dimt1);
    S2=round(size(img2).*dimt2);
    
    % rescale images to conform with 160 bins (good values are between 80 and 256)
    img1=img1-min(img1(:));
    img2=img2-min(img2(:));
    img2=img2/max(img2(:))*80;
    img1=img1/max(img1(:))*80;
    
    %define center of rotation (mm from corner of img1)
    center=[floor(S1(1)/2) floor(S1(2)/2) floor(S1(3)/2)]
    %setting image-resolution for affine registration to 1mm
    resolution=[1 1 1];
    [X11, X2, X3]=ndgrid(0:resolution(1):S1(1)-resolution(1),0:resolution(2):S1(2)-resolution(2),0:resolution(3):S1(3)-resolution(3));
    pts=[X11(:) X2(:) X3(:)];
    
    %vectorize images in 'resolution' resolution
    Itrival=(SplineInterpolation_tbb(pts,img1,[0 0 0],dimt1));
    Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));
    
    %initialize parameters to 0 for affine
    p2=zeros(12,1);
    %using 1-norm
    %perform translation initialization
    p2=minFunc(@cf_rigidPNorm_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
    %include rotation
    p2=minFunc(@cf_rigidPNorm_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
    
    %include scale
    p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
    
    %full affine
    %change parametrization from angles to.... matrix
    
    [f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
    p3=T(:);
    p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);
    
    p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
    
    %full symmetric affine registration
    p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1));
    
    saveparams(['MR' num2str(i) '_to_MR' num2str(1) '_RH_patient0t_affine_' date],p3);
    %saveparams(['MR' num2str(i) '_to_CT_RH_patient0t_affine'],p3);

    
end
