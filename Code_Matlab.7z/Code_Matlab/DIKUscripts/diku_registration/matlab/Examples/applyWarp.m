set(0,'DefaultFigureWindowStyle','docked')
%dpath='H:\Windows\GBM\Recurrence\NiftiFiles\Patient0t\';
dpath='/Users/MLJ/Documents/Nifti/Patient0t/';


CTfile = dir([dpath '*CT.nii*']);
baselineCT = CTfile.name;
MRIfilesT1 = dir([dpath '*t1.nii*']);
noMRIfilesT1 = size(MRIfilesT1,1);
baselineMR = MRIfilesT1(1).name;

%MRI1=load_untouch_nii(fullfile(dpath,baselineMR));
MRI1=load_untouch_nii(fullfile(dpath,baselineCT));

followup = 1;
MRI2=load_untouch_nii(fullfile(dpath,MRIfilesT1(followup+1).name));
img1=double(MRI1.img);
img2=double(MRI2.img);

%get image resolution
dimt1=MRI1.hdr.dime.pixdim(2:4);
dimt2=MRI2.hdr.dime.pixdim(2:4);

% Image size [mm]
S1=round(size(img1).*dimt1);
S2=round(size(img2).*dimt2);

% rescale images to conform with 160 bins (good values are between 80 and 256)
img1=img1-min(img1(:));
img2=img2-min(img2(:));
img2=img2/max(img2(:))*160;
img1=img1/max(img1(:))*160;

%define center of rotation (mm from corner of img1)
center=[floor(S1(1)/2) floor(S1(2)/2) floor(S1(3)/2)]

%p = load(['MR' num2str(followup+1) '_to_MR1_RH_patient0t_affine']);
p = load(['MR' num2str(followup+1) '_to_CT_RH_patient0t_affine']);
p3 = p.p;

[X11, X21, X31]=ndgrid(0:dimt1(1):S1(1)-dimt1(1),0:dimt1(2):S1(2)-dimt1(2),0:dimt1(3):S1(3)-dimt1(3));
org_pts1=[X11(:) X21(:) X31(:)];
[X12, X22, X32]=ndgrid(0:dimt2(1):S2(1)-dimt2(1),0:dimt2(2):S2(2)-dimt2(2),0:dimt2(3):S2(3)-dimt2(3));
org_pts2=[X12(:) X22(:) X32(:)];

n1=SplineInterpolation_lin(org_pts1+repmat(0.5*dimt1,numel(X11),1),double(img1),[0 0 0],dimt1);
n11=SplineInterpolation_lin(org_pts2+repmat(0.5*dimt2,numel(X12),1),double(img2),[0 0 0],dimt2);

ww = [5 5 5];
offset2=-ww ;
%%
%img2 matched to img1 by inv affine
[pts3, ipts3]=do_sym_affine(p3(:),org_pts1,center);
n3=SplineInterpolation_lin(ipts3+repmat(0.5*dimt2,numel(X11),1),double(img2),[0 0 0],dimt2);

%img2 matched to img1 by affine
%nr warp
[pts3, ipts3]=do_sym_affine(p3(:),org_pts2,center);
n33=SplineInterpolation_lin(pts3+repmat(0.5*dimt1,numel(X12),1),double(img1),[0 0 0],dimt1);


img11 = reshape(n1,size(X11));
img21 = reshape(n11,size(X12));
img12 = reshape(n3,size(X11));
img22 = reshape(n33,size(X12));


%end

%%
MRI1slice = 256;
figure(1),imagesc(squeeze(img11(MRI1slice,:,:))),
figure(2),imagesc(squeeze(img12(MRI1slice,:,:))),
%figure(3),imagesc(imfuse(squeeze(img11(MRI1slice,:,:)),squeeze(img12(MRI1slice,:,:))));axis image

%%
MRI2slice = 26;
figure(4),imagesc(img21(:,:,MRI2slice)),axis image
figure(5),imagesc(img22(:,:,MRI2slice)),axis image
figure(6),imagesc(imfuse(img21(:,:,MRI2slice),img22(:,:,MRI2slice)));axis image
