dpath='/Users/MLJ/Documents/MGH10';

% IBSR_labels 
% a1=zeros(45,1);
% a2=zeros(45,1);
% a3=zeros(45,1);
% a4=zeros(45,1);
% b1=zeros(45,1);
% b2=zeros(45,1);
% b3=zeros(45,1);
% b4=zeros(45,1);
% cnt=1;
cnt=1;
for ii=i
for jj=ii+1:5
idx(cnt)=ii;
jdx(cnt)=jj;
cnt=cnt+1;
end
end

% options.LS_init=2;
% options.LS=3;
warning off all
%parfor i=1:45
i = 1;
mri=load_nii([dpath '/EHeads/g' num2str(jdx(i)) '.nii']);
mri2=load_nii([dpath '/EHeads/g' num2str(idx(i)) '.nii']);
 
  
  
% mri=load_nii(['/home/cjr806/IBSR18/Atlases/c' num2str(jdx(i)) '.img']);
% mri2=load_nii(['/home/cjr806/IBSR18/Atlases/c' num2str(idx(i)) '.img']);
center=[128 128 96]
ww=[5 5 5];
pt=load(['c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_p_c' num2str(jdx(i)) '.mat' ]);
S=size(mri.img).*mri.hdr.dime.pixdim(2:4)-1;
p3=pt.p;

dim1=mri.hdr.dime.pixdim(2:4);


dim2=mri2.hdr.dime.pixdim(2:4);

offset2=-ww;
pt2=load(['c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_c' num2str(jdx(i)) '.mat' ]);
pp4=pt2.p;
[X11, X2, X3]=ndgrid(0:dim1(1):S(1),0:dim1(2):S(2),0:dim1(3):S(3));
org_pts=[X11(:) X2(:) X3(:)];
[X1, X2, X3]=ndgrid(0:dim2(1):S(1),0:dim2(2):S(2),0:dim2(3):S(3));
org_pts2=[X1(:) X2(:) X3(:)];
cnt=1;
%[invaf_pts af_pts]=do_sym_affine(p(:),nr_pts,center);
%af_pts=af_pts;
%p=reshape(a1(10:end),[a1(1) a1(1) a1(1) 3]);

%tic;[nr_pts]=SS_Trap_1st(af_pts,pp4,offset2,ww,double(40),double(5));toc
mri=load_nii([dpath '/EHeads/g' num2str(jdx(i)) '.nii']);
mri2=load_nii([dpath '/EHeads/g' num2str(idx(i)) '.nii']);


n1=NNInterpolation_lin(org_pts+repmat(0.5*dim1,numel(X11),1),double(mri.img(:,:,:)),[0 0 0],dim1);

n11=NNInterpolation_lin(org_pts2+repmat(0.5*dim2,numel(X1),1),double(mri2.img(:,:,:)),[0 0 0],dim2);

%img2 (from the run script) matched to img1 by first nr warp and then
%affine
tic;[nr_pts]=SS_Trap_1st(org_pts,pp4,offset2,ww,double(40),double(5));toc
[pts3 ipts3]=do_sym_affine(p3(:),nr_pts,center);

n3=NNInterpolation_lin(pts3+repmat(0.5*dim2,numel(X11),1),double(mri2.img(:,:,:)),[0 0 0],dim2);
%img1 (from the run script) matched to img2 by first inv affine and then
%nr warp
[pts3 ipts3]=do_sym_affine(p3(:),org_pts2,center);
tic;[inr_pts]=SS_Trap_1st(ipts3,-pp4,offset2,ww,double(40),double(5));toc
n33=NNInterpolation_lin(inr_pts+repmat(0.5*dim1,numel(X1),1),double(mri.img(:,:,:)),[0 0 0],dim1);


img1 = reshape(n1,size(X1));
img2 = reshape(n11,size(X1));

img12 = reshape(n33,size(X1));
img22 = reshape(n3,size(X1));



%%
slice = 100;
figure(1),imagesc(img1(:,:,slice)); axis image
figure(2),imagesc(img2(:,:,slice)); axis image
figure(3),imagesc(img12(:,:,slice)); axis image
figure(4),imagesc(img22(:,:,slice)); axis image

% id=unique(n1);
% id=id(2:end);
% % [TO,MO]=evalutationKlien(n2,n1,id(2:end));
% % tto11(cnt,:)=TO;
% % aa11(cnt)=mean(TO)
% 
% % %[TO,MO]=evalutationKlien(n3,n1,id);
% % 
% % TO1(i,:)=TO;
% % MO1(i,:)=MO;
% % no=find(~isnan(TO));
% % b1(i)=mean(MO(no));
% % a1(i)=mean(TO(no));
% [TO,MO]=evalutationKlien(n1,n3,id);
% TO2=TO;
% MO2=MO;
% no=find(~isnan(TO));
% a2(i)=mean(TO(no))
% b2(i)=mean(MO(no));
% [TO,MO]=evalutationKlien(n11,n33,id);
% TO3=TO;
% MO3=MO;
% no=find(~isnan(TO));
% a3(i)=mean(TO(no))
% b3(i)=mean(MO(no));
% saveparams(['c' num2str(idx(i)) 'MGH_160_dr_iter_04_c' num2str(jdx(i))  ],[TO2 TO3 MO2 MO3]);
% % [TO,MO]=evalutationKlien(n33,n11,id);
% % TO4(i,:)=TO;
% % MO4(i,:)=MO;
% % no=find(~isnan(TO));
% % a4(i)=mean(TO(no));
% % b4(i)=mean(MO(no));
%end