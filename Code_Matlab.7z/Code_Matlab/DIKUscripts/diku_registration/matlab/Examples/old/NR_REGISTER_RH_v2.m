
lpath='/Users/MLJ/Dropbox/Work/RH/Research/Matlab/toolboxes/DIKU_registration';
%dpath='/Users/MLJ/Documents/MGH10';
dpath='/Volumes/MLJ HD/GBM/Recurrence/NiftiFiles';
no_cores=4;
addpath([lpath '/minFunc_2012/minFunc/']);
addpath([lpath '/minFunc_2012/minFunc/mex/']);
addpath([lpath '/minFunc_2012/minFunc/compiled/']);
%addpath([lpath '/NIFTI_20110921/']);
addpath([lpath '/Matlab/Functionals/']);
addpath([lpath '/Matlab/Examples/']);
addpath([lpath '/Matlab/Similarity/']);
addpath([lpath '/Matlab/Interpolations/']);
addpath([lpath '/Matlab/Levelset/']);
addpath([lpath '/C++/Leveset/']);
addpath([lpath '/C++/Interpolation/']);
% try
%     parpool(no_cores)
% catch
% end
cnt=1;
for ii=1
    for jj=ii+1:5
        idx(cnt)=ii;
        jdx(cnt)=jj;
        cnt=cnt+1;
    end
end

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=20;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';
options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;
options4=options;
options4.MaxIter=100;



warning off all

%parfor i=1:4
i = 1;
% read images
%mri1=load_nii([dpath '/EHeads/g' num2str(idx(i)) '.nii']);
mri1 = load_untouch_nii([dpath '/Patient30/20120521_t1.nii.gz']);
img1=double(mri1.img)*2;
S1=size(img1)-1;
%mri2=load_nii([dpath '/EHeads/g' num2str(jdx(i)) '.nii']);
mri2 = load_untouch_nii([dpath '/Patient30/20120718_t1.nii.gz']);
img2=double(mri2.img)*2;
S2=size(img2)-1;

%get image resolution
dimt2=mri2.hdr.dime.pixdim(2:4);
dimt1=mri1.hdr.dime.pixdim(2:4);

% rescale images to conform with 160 bins (good values are between 80 and 256)
img1=img1/max(img1(:))*160;
img2=img2/max(img2(:))*160;

%define center of rotation (mm from corner of img1)
center=[128 128 96]
center=[floor(S1(1)/2) floor(S1(2)/2) floor(S1(3)/2)];
%setting image-resolution for affine registration to 2mm
resolution=2;
[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
pts=[X1(:) X2(:) X3(:)];

%vectorize images in 'resolution' resolution
Itrival=(SplineInterpolation_tbb(pts,img1,[0 0 0],dimt1));
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));

%initialize parameters to 0 for affine
p2=zeros(12,1);
%using 1-norm
%perform translation initialization
p2=minFunc(@cf_rigidPNorm_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
%include rotation
p2=minFunc(@cf_rigidPNorm_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
%include scale
p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full affine
%change parametrization from angles to.... matrix
[f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
p3=T(:);
p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);
p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full symmetric affine registration (original resolution)
p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1));

%resample img1 (1mm resolution) to prepare non-rigid registration
[X1, X2, X3]=ndgrid(0:1:S1(1),0:1:S1(2),0:1:S1(3));
ptsresample=[X1(:) X2(:) X3(:)];

% Resample affine transformed img1
[pts3]=do_sym_affine(p3(:),ptsresample,center);
Rtrival=(SplineInterpolation_lin(pts3,img1,[0 0 0],dimt1));
Rtrival=(SplineInterpolation_lin(pts3,img2,[0 0 0],dimt2));
% Reshaping affine transformed img1
img2_aff=reshape(Rtrival,size(X1));

%setting up non-rigid registration
resolution=2;
[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
pts=[X1(:) X2(:) X3(:)];
Itrival=(SplineInterpolation_tbb(pts,img2_aff,[0 0 0],[1 1 1]));

% extracting positions with information
no=find(Itrival+Jtrival>0);

% initializ to 0
pp4=zeros([30 30 30 3]);

%no. of points in deformation grid
grid_size=45;
%setting size of deformation grid and parametrization
val=ones([grid_size grid_size grid_size 3]);
pyramidLevels = [40 20 10 5];

for pl = 1:length(pyramidLevels)
    if (pl==1 || pl==2)
        curr_options = options2;
    elseif pl == 3
        curr_options = options3;
    elseif pl == 4
        curr_options = options4;
    else
        error('Bummer!!')
    end
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    %resampling deformation field to new resolution
    [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
    tpts=[XX1(:) XX2(:) XX3(:)]*pyramidLevels(pl);
    n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
    
    %setting scale and offset of img11
    scale=[1 1 1];
    offset=[1 1 1]*0;
    
    p4=reshape(n,size(val));
    offset2=-ww;
    
    pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),curr_options,size(p4),(0.0005),pts(no,:),img1,img2_aff,Itrival(no),Jtrival(no),offset2,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);

    %pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),curr_options,size(p4),(0.0005),pts(no,:),img2_aff,img2,Jtrival(no),Itrival(no),offset2,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);
    pp4=reshape(pp4,size(p4));
    
end

[X1, X2, X3]=ndgrid(0:1:S1(1),0:1:S1(2),0:1:S1(3));
ptsresample=[X1(:) X2(:) X3(:)];
[aff_pts]=do_sym_affine(p3(:),ptsresample,center);
tic;[aff_nr_pts]=SS_Trap_1st(aff_pts,pp4,offset2,ww,double(40),double(5));toc
n3 = SplineInterpolation_lin(aff_nr_pts+repmat(0.5*dim2,numel(X1),1),double(mri2.img),[0 0 0],dim2);

% Resample affine transformed img2
[pts3]=do_sym_affine(p3(:),ptsresample,center);
Rtrival=(SplineInterpolation_lin(pts3,img1,[0 0 0],dimt1));
% Reshaping affine transformed img2
img2_aff=reshape(Rtrival,size(X1));


% Saving warp-field
saveparams([dpath '/Warps/c'  num2str(idx(i)) 'MGH0_0004_160_dr_iter_c' num2str(jdx(i))  ],pp4);
% Saving full affine
saveparams([dpath '/Warps/c'  num2str(idx(i)) 'MGH0_0004_160_dr_iter_p_c' num2str(jdx(i))  ],p3);


%end