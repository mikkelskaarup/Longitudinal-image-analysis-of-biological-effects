function [ y, dy ] = inv3x3( x )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%Compute the determinant
y1=1/((x(1,1)*x(2,2)*x(3,3))+(x(1,2)*x(2,3)*x(3,1))+(x(1,3)*x(2,1)*x(3,2))-(x(1,1)*x(2,3)*x(3,2))-(x(1,2)*x(2,1)*x(3,3))-(x(1,3)*x(2,2)*x(3,1)));
%compute the co-factor matrix
y2=[(x(2,2)*x(3,3)-x(3,2)*x(2,3)) -(x(2,1)*x(3,3)-x(2,3)*x(3,1)) (x(2,1)*x(3,2)-x(2,2)*x(3,1));
    -(x(1,2)*x(3,3)-x(1,3)*x(3,2)) (x(1,1)*x(3,3)-x(1,3)*x(3,1)) -(x(1,1)*x(3,2)-x(1,2)*x(3,1));
    (x(1,2)*x(2,3)-x(1,3)*x(2,2)) -(x(1,1)*x(2,3)-x(1,3)*x(2,1)) (x(1,1)*x(2,2)-x(1,2)*x(2,1)) ];
%Make the inverse
y=y1*y2';
%compute the derivative of the determinant wrt. the parameters
dy1=-1/((x(1,1)*x(2,2)*x(3,3))+(x(1,2)*x(2,3)*x(3,1))+(x(1,3)*x(2,1)*x(3,2))-(x(1,1)*x(2,3)*x(3,2))-(x(1,2)*x(2,1)*x(3,3))-(x(1,3)*x(2,2)*x(3,1)))^2;
dy11=dy1*(x(2,2)*x(3,3)-x(2,3)*x(3,2));
dy12=dy1*(x(1,3)*x(3,2)-x(1,2)*x(3,3));
dy13=dy1*(x(1,2)*x(2,3)-x(1,3)*x(2,2));
dy14=dy1*(x(2,3)*x(3,1)-x(2,1)*x(3,3));
dy15=dy1*(x(1,1)*x(3,3)-x(1,3)*x(3,1));
dy16=dy1*(x(1,3)*x(2,1)-x(1,1)*x(2,3));
dy17=dy1*(x(2,1)*x(3,2)-x(2,2)*x(3,1));
dy18=dy1*(x(1,2)*x(3,1)-x(1,1)*x(3,2));
dy19=dy1*(x(1,1)*x(2,2)-x(1,2)*x(2,1));

%compute the derivatives of the co-factor matrix wrt the parameters and
%asemble with the derivative of the determinant using the product rule

dy(1,:,:)=dy11*y2'+y1*[0 0 0;
    0 x(3,3) -(x(3,2));
    0 -x(2,3) x(2,2) ]';

dy(2,:,:)=dy12*y2'+y1*[0 -x(3,3) x(3,2);
    0 0 0;
    0 x(1,3) -x(1,2) ]';

dy(3,:,:)=dy13*y2'+y1*[0 x(2,3) -x(2,2);
    0 -x(1,3) x(1,2);
    0 0 0]';

dy(4,:,:)=dy14*y2'+y1*[0 0 0;
    -(x(3,3)) 0 (x(3,1));
    x(2,3) 0 -x(2,1) ]';

dy(5,:,:)=dy15*y2'+y1*[x(3,3) 0 -x(3,1);
    0 0 0;
    -x(1,3) 0 x(1,1) ]';

dy(6,:,:)=dy16*y2'+y1*[-x(2,3) 0 x(2,1);
    x(1,3) 0 -(x(1,1));
    0 0 0]';

dy(7,:,:)=dy17*y2'+y1*[0 0 0;
x(3,2) -x(3,1) 0;
    -x(2,2) x(2,1) 0]';

dy(8,:,:)=dy18*y2'+y1*[-x(3,2) x(3,1) 0;
    0 0 0 ;
    x(1,2) -x(1,1) 0]';

dy(9,:,:)=dy19*y2'+y1*[x(2,2) -x(2,1) 0;
    -x(1,2) x(1,1) 0;
    0 0 0]';

end

