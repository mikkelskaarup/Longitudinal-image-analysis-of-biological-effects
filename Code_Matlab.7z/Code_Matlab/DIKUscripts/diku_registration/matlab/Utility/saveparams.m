function saveparams( name, p )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

save(name,'p');

end

