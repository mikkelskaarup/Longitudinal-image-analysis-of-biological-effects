function [im1, im2, im3]=imfeatures(img1,k)
L1=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[2,0,0])));
L2=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[0,2,0])));
L3=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[0,0,2])));
L11=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[2,0,0])));
L22=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[0,2,0])));
L33=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[0,0,2])));
L12=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[1,1,0])));
L23=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[0,1,1])));
L13=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[1,0,1])));

parfor j=1:numel(L1)
H=[L11(j) L12(j) L13(j);L12(j) L22(j) L23(j); L13(j) L23(j) L33(j)];
dt=det(H);
D(j)=(sign(dt)*(abs(dt)^(1/3)));
TR(j)=((L11(j)+L22(j)+L33(j))/3);
H2=H*H;
DTR(j)=(((L11(j)+L22(j)+L33(j))^2-(H2(1,1)+H2(2,2)+H2(3,3)))/6);
% if(mod(j,10000)==0)
%     disp(j)
% end
end
im1=reshape(D,size(img1));
im2=reshape(TR,size(img1));
im3=reshape(DTR,size(img1));
end