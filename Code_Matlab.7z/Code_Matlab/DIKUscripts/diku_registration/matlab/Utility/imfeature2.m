function [im1, im2, im3]=imfeatures(img1,k)
L1=real(ifftn(scalen(fftn(img1),[0.5,0.5,0.5]*k,[0,0,0])));



im1=L1
im2=L1;
im3=L1;

end