function [ v ] = kern( x,y )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
if(sum((x-y).^2)<=1)
v=1-sqrt(sum((x-y).^2))
else
  v=0;

end

