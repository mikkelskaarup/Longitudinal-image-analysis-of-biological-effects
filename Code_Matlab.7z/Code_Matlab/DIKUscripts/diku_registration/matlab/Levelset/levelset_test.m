
warning off MATLAB:nearlysingularmatrix
addpath('C:\Libs\minFunc')
options.Method='lbfgs';            
options.display = 'lbfgs';   
options.MaxIter=10;
options.TolX=10^(-16);
options.TolFun=10^(-16);
options.DerivativeCheck='off';
warning off all

% A=ones(100,100,100);
% % find(dist<20);
% % no=find(dist<20);
% A(30:50,30:50,30:50)=-1;
% imagesc(A(:,:,40))
% img=A*10+30+rand(size(A))*0;
%____________________________________
s=size(img);
[x y z]=ndgrid(1:s(1),1:s(2),1:s(3));
x=x-s(1)/2;
y=y-s(2)/2;
z=z-s(3)/2;
dist=sqrt(x.^2+y.^2+z.^2)-30;
imagesc(dist(:,:,40))
% A=ones(80,80,80);
% % find(dist<20);
% % no=find(dist<20);
% A(30:50,30:50,30:50)=-1;
% imagesc(A(:,:,40))
% A=A*10+30+rand(size(A))*0;
%__________ no1=find(Iphi>0);
st_mu=0;
cnt=1;
f1=0;
for i=1:4
    tic
%     no1=find(dist>0);
%  no2=find(dist<=0);
%  mu1=mean(img(no1))
%  mu2=mean(img(no2))
%  toc
%     [f df]=cf_levelset_PNorm_cut(dist(:),img(:),10,1e-5,200,2,2,mu1,mu2);
%     disp(f)
%     disp(f1)
%     pause(0.5)
%     f1=f;
%    no=find(abs(df)>1e-6);
    no1=find(dist>0);
 no2=find(dist<=0);
 mu1=mean(img(no1))
 mu2=mean(img(no2))
 if(abs(mu2-st_mu)<1e-8)
    cnt=cnt+1;
 else
     cnt=1;
 end
 if(cnt>4) 
     break;
 end
 
 st_mu=mu2;
   no=find(abs(dist)<=2000);
p=minFunc(@cf_levelset_PNorm_cut,dist(no),options,img(no),1e8,500,100000,400,2,2,mu1,mu2);
dist(no)=p;
dist2=dist;

no=find(dist2<0);
bw=zeros(size(dist2));
bw(no)=1;
bw1=bwdist(bw,'euclidean');
bw1(no)=-bw1(no)+1;
bw2=bwdist(-bw+1,'euclidean');
dist=double(bw1-bw2);
end

   