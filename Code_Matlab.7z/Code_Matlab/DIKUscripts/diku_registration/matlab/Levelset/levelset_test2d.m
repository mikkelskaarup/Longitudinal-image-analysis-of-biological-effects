%use minFunc lib
warning off MATLAB:nearlysingularmatrix
addpath('C:\Libs\minFunc')
options.Method='lbfgs';            
options.display = 'iter';   
options.MaxIter=10;
options.TolX=10^(-16);
options.TolFun=10^(-16);
options.DerivativeCheck='off';
warning off all
%------------TEST IMAGE--------------
A=ones(100,100);
% find(dist<20);
% no=find(dist<20);
A(30:50,30:50)=-1;
imagesc(A)
img=A*10+30+randn(size(A))*2;
img=real(ifftn(scalen(fftn(img),[1, 1]*0.5,[0, 0])));
%____________________________________


s2=size(img);
s=[100 100];
[x y]=ndgrid(1:s(1),1:s(2));
x=x-s(1)/2;
y=y-s(2)/2;
dist=sqrt(x.^2+y.^2)-30;
imagesc(dist)
dist=repmat(dist,ceil(s2(1)/s(1)),ceil(s2(2)/s(2)));
dist=dist(1:s2(1),1:s2(2));
dist=dist;
%pause;
%____________________________________
dst=dist;
%%
for i=1:100
    
%       no=find(abs(dist)<=2);
%p=minFunc(@cf_levelset_PNorm,dist(no),options,img(no),3,1,10,2);
    no1=find(dist>0);
 no2=find(dist<=0);
 mu1=median(img(no1))
 mu2=median(img(no2))
   no=find(abs(dist)<=200);
p=minFunc(@cf_levelset_PNorm_cut,dist(no)/10,options,img(no),0.0,1e-12,0,0,2,2,mu1,mu2);

dist(no)=p*10;
dist2=dist;
%dist2=reshape(p,size(dist));

no=find(dist2<0);
bw=zeros(size(dist2));
bw(no)=1;
bw1=bwdist(bw,'euclidean');
bw1(no)=-bw1(no)+1;
bw2=bwdist(-bw+1,'euclidean');
dist=double(bw1-bw2);
end
%%
% abw=bw;
% adist=dist;
% adist2=dist2;
% dist=dst;
%    for i=1:100
% %       no=find(abs(dist)<=2);
% %p=minFunc(@cf_levelset_PNorm,dist(no),options,img(no),3,1,10,2);
%     no1=find(dist>0);
%  no2=find(dist<=0);
%  mu1=mean(img(no1))
%  mu2=mean(img(no2))
%    no=find(abs(dist)<=2);
% p=minFunc(@cf_levelset_PNorm_cut,dist(no),options,img(no),1e1,1e1,100000,1,2,mu1,mu2);
% 
% dist(no)=p;
% dist2=dist;
% %dist2=reshape(p,size(dist));
% 
% no=find(dist2<0);
% bw=zeros(size(dist2));
% bw(no)=1;
% bw1=bwdist(bw,'euclidean');
% bw1(no)=-bw1(no)+1;
% bw2=bwdist(-bw+1,'euclidean');
% dist=double(bw1-bw2);
% end