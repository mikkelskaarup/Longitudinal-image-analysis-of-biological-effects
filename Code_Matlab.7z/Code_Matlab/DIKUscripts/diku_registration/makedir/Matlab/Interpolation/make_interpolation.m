
if( strcmp(computer,'PCWIN64'))
if(debug)
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_lin_tbb.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_lin.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_tbb.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_tbb_compact.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
end
if(~debug)
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_lin_tbb.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir', '.\..\..\..\Matlab\Interpolations')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_lin.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , '.\..\..\..\Matlab\Interpolations')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_tbb.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , '.\..\..\..\Matlab\Interpolations')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_tbb_compact.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , '.\..\..\..\Matlab\Interpolations')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , '.\..\..\..\Matlab\Interpolations')
end
else
if(debug)
    mex('./../../../C++/Interpolation/SplineInterpolation_lin_tbb.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Interpolations/debug')
    mex('./../../../C++/Interpolation/SplineInterpolation_lin.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Interpolations/debug')
    mex('./../../../C++/Interpolation/SplineInterpolation_tbb.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Interpolations/debug')
    mex('./../../../C++/Interpolation/SplineInterpolation_tbb_compact.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Interpolations/debug')
    mex('./../../../C++/Interpolation/SplineInterpolation.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Interpolations/debug')
end
if(~debug)
    mex('./../../../C++/Interpolation/SplineInterpolation_lin_tbb.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir', './../../../Matlab/Interpolations')
    mex('./../../../C++/Interpolation/SplineInterpolation_lin.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , './../../../Matlab/Interpolations')
    mex('./../../../C++/Interpolation/SplineInterpolation_tbb.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , './../../../Matlab/Interpolations','$CFLAGS -Wall')
    mex('./../../../C++/Interpolation/SplineInterpolation_tbb_compact.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , './../../../Matlab/Interpolations')
    mex('./../../../C++/Interpolation/SplineInterpolation.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , './../../../Matlab/Interpolations')
end
end