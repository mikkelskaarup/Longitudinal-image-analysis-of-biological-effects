// EigenDeriv.cpp : Defines the entry point for the console application.


#include <math.h>
#include <mex.h>
#include <matrix.h>
#include <vector>
#include <vnl/vnl_matrix.h>
#include <vnl/algo/vnl_determinant.h>
#include <vnl/algo/vnl_symmetric_eigensystem.h>
#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/mutex.h"

using namespace std;


using namespace tbb;
typedef mutex MyMutexType;
	MyMutexType MyMutex;
	MyMutexType MyMutex2;
class EigenDerivTBB
{
	
	

private:
	int* dim_p;
	int* dim_simp;
	int* dim_ad;
	double* p ;
	double* simp;
	double* Ad ;
	double* lambda;
	double* mu ;
	int p_space;
	int poly_space;
	int* dim_mu;
	mwSize dim,dim2;
	double* drdp;
	double* r;
	double* f;
    int N;
    bool* lterm;

	




public:
	EigenDerivTBB(int* vdim_p,int* vdim_simp,int* vdim_ad,double* vp,double* vsimp,double* vAd,double* vlambda,double* vmu ,int vp_space,int vpoly_space,double* vdrdp,double* vr,	double* vf, int* vdim_mu, int vN,bool* term) 
	{
		dim_mu=vdim_mu;
dim_p=vdim_p;
dim_simp=vdim_simp;
	dim_ad=vdim_ad;
	p=vp;
	simp=vsimp;
	Ad=vAd;
	lambda= vlambda;
	mu=vmu;
	p_space=vp_space;
	poly_space=	vpoly_space;
	drdp=vdrdp;
	r=vr;
	f=vf;
    N=vN;
    lterm=term;


	//this->MyMutex=new MyMutexType[dim_simp[0]];
	}

	void operator()(const blocked_range<int> & rr) const
	{

        double *ldrdp=new double[N];
        
		vnl_matrix<double> p_m(poly_space,p_space);
		vnl_matrix<double> Ad_m(poly_space,p_space);
		vnl_matrix<int> indices(poly_space,p_space);
		vnl_matrix<double> PIJ(p_space,poly_space,0);
		vnl_matrix<double> I_m(p_space,p_space);
		I_m.set_identity();
		vnl_matrix<double> E_m(p_space,p_space);
		vnl_matrix<double> nablaPhi_m(p_space,p_space);
		vnl_matrix<double> eigen_vectors(p_space,p_space);
		vnl_vector<double> eigenvalues(p_space);
		vnl_vector<double> log_eigenvalues(p_space);
		vnl_vector<double> inv_eigenvalues(p_space);
		vnl_vector<double> drepsilon(p_space);
			double sum_log_eigs;
	double sum_log_eigs_sq;
		double sum_eigs;
		double lr=0;
		int lam_mu=0;
         for (int j=0;j<N;j++)ldrdp[j]=0;
        
        for(int i=rr.begin();i!=rr.end();i++)
		{
				if(dim_mu[0]>1)
					lam_mu=i;
				vector<int> vertices;
				for (int j=0;j<poly_space;j++){
					vertices.push_back((int)simp[i+(j*dim_simp[0])]);
					int l_index=vertices[j];		
					for (int k=0;k<p_space;k++){
						l_index=vertices[j]+k*dim_p[0];
						p_m.put(j,k,p[l_index]);
						Ad_m.put(j,k,Ad[i*dim_ad[0]*dim_ad[1]+k*dim_ad[0]+j]);
					}
				}
				nablaPhi_m=I_m+p_m.transpose()*Ad_m;
				if(vnl_determinant<double>(nablaPhi_m)<0 ||lterm[0]){
					f[0]=mxGetInf();
                    lterm[0]=true;
                    delete ldrdp;
					return;
				}
				sum_eigs=0;
				sum_log_eigs=0;
				sum_log_eigs_sq=0;
				E_m=nablaPhi_m*nablaPhi_m.transpose();
				vnl_symmetric_eigensystem<double> eig(E_m);		
				for (unsigned int j=0;j<p_space;j++){
					/*	if(eig.get_eigenvalue(j)<=0){
					f[0]=mxGetInf();			
					return;
					}*/
					sum_eigs+=eig.get_eigenvalue(j);
					sum_log_eigs+=log(eig.get_eigenvalue(j));
					sum_log_eigs_sq+=pow(log(eig.get_eigenvalue(j)),2);
					log_eigenvalues.put(j,log(eig.get_eigenvalue(j)));
					inv_eigenvalues.put(j,1/(eig.get_eigenvalue(j)));
					eigen_vectors.set_row(j,eig.get_eigenvector(j));

				}


				for (unsigned int j=0;j<p_space;j++){
					drepsilon.put(j,mu[lam_mu]/2*inv_eigenvalues.get(j)*log_eigenvalues.get(j)+lambda[lam_mu]/4*inv_eigenvalues.get(j)*sum_log_eigs);	
				}
				for (unsigned int j=0;j<poly_space;j++){
					for(unsigned int k=0;k<p_space;k++){
						indices.put(j,k,vertices[j]+k*dim_p[0]);
					}
				}

				vnl_matrix<double> tmp=Ad_m*nablaPhi_m.transpose()*eigen_vectors.transpose();
				vnl_matrix<int> it=indices.transpose();
				for (unsigned int j=0;j<poly_space;j++){
					for(unsigned int k=0;k<p_space;k++){
						for (unsigned int l=0;l<E_m.rows();l++){
							//MyMutexType::scoped_lock lock(MyMutex);
							
	/*						drdp[it(k,j)];
							2*eigen_vectors.get(l,k);
							tmp.get(j,l);
							drepsilon.get(l);*/



							ldrdp[it(k,j)]=ldrdp[it(k,j)]+2*eigen_vectors.get(l,k)*tmp.get(j,l)*drepsilon.get(l);
						}

					}
				}
				
				lr+=mu[lam_mu]/4*sum_log_eigs_sq+lambda[lam_mu]/8*pow(sum_log_eigs,2);
//				mexPrintf("%d \n",i);
		}
		{
		MyMutexType::scoped_lock lock(MyMutex2);
            {
                r[0]+=lr;
                for (int j=0;j<N;j++)drdp[j]=drdp[j]+ldrdp[j];
            }
        }
        delete ldrdp;
	}

	double b0(int j, double xi) const
	{
		return 0;
	}
	double db0(int j, double xi) const
	{
		return 0;
	}


};

void printMatrixMatlab(vnl_matrix<double> m){

	for(int i=0;i<m.rows();i++){
		for(int j=0;j<m.cols();j++){
			mexPrintf("%f ", m.get(i,j));
		}
		mexPrintf("\n");
	}

}
void printMatrixMatlab(vnl_matrix<int> m){

	for(int i=0;i<m.rows();i++){
		for(int j=0;j<m.cols();j++){
			mexPrintf("%d ", m.get(i,j));
		}
		mexPrintf("\n");
	}

}
class RiemanianElasticity
{
void evalu(double* p, double* simp, double* dxdp, double* regParams, int* dim_p, int* dim_ad)
{
	int* dim_p =(int*)mxGetDimensions(prhs[0]);
	int* dim_simp=(int*)mxGetDimensions(prhs[1]);
	int* dim_ad=(int*)mxGetDimensions(prhs[2]);
	int* dim_mu=(int*)mxGetDimensions(prhs[4]);


	double* p = static_cast<double*>(mxGetData(prhs[0]));
	double* simp = static_cast<double*>(mxGetData(prhs[1]));
	double* Ad = static_cast<double*>(mxGetData(prhs[2]));
	double* lambda = static_cast<double*>(mxGetData(prhs[3]));
	double* mu = static_cast<double*>(mxGetData(prhs[4]));

	int p_space=dim_ad[1];
	int poly_space=dim_ad[0];
	double sum_eigs;
	double sum_log_eigs;
	double sum_log_eigs_sq;
    	double lmu=mu[0];
    	double llambda=lambda[0];
	int dim[1],dim2[1];
	dim[0]=dim_p[0]*dim_p[1];
	dim2[0]=1;

	//vnl_matrix<double> p_m(poly_space,p_space);
	//vnl_matrix<double> Ad_m(poly_space,p_space);
	//vnl_matrix<int> indices(poly_space,p_space);
	//vnl_matrix<double> PIJ(p_space,poly_space,0);
	//vnl_matrix<double> I_m(p_space,p_space);
	//I_m.set_identity();
	//vnl_matrix<double> E_m(p_space,p_space);
	//vnl_matrix<double> nablaPhi_m(p_space,p_space);
	//vnl_matrix<double> eigen_vectors(p_space,p_space);
	//vnl_vector<double> eigenvalues(p_space);
	//vnl_vector<double> log_eigenvalues(p_space);
	//vnl_vector<double> inv_eigenvalues(p_space);
	//vnl_vector<double> drepsilon(p_space);
	plhs[0] = mxCreateNumericArray(1,dim,mxDOUBLE_CLASS, mxREAL);
	double* drdp = static_cast<double*>(mxGetData(plhs[0]));
	plhs[1] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
	double* r = static_cast<double*>(mxGetData(plhs[1]));
	plhs[2] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
	double* f = static_cast<double*>(mxGetData(plhs[2]));
	
	r[0]=0;
	f[0]=0;
	int N=dim_simp[0];
    bool term=false;

	parallel_for(blocked_range<int>(0,N,N/12),EigenDerivTBB(dim_p,dim_simp,dim_ad,p,simp,Ad,&llambda,&lmu ,p_space,poly_space,drdp,r,f,dim_mu,dim[0],&term),auto_partitioner());
    return;


}
};
void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
				 const mxArray *prhs[])
{
	int* dim_p =(int*)mxGetDimensions(prhs[0]);
	int* dim_simp=(int*)mxGetDimensions(prhs[1]);
	int* dim_ad=(int*)mxGetDimensions(prhs[2]);
	int* dim_mu=(int*)mxGetDimensions(prhs[4]);


	double* p = static_cast<double*>(mxGetData(prhs[0]));
	double* simp = static_cast<double*>(mxGetData(prhs[1]));
	double* Ad = static_cast<double*>(mxGetData(prhs[2]));
	double* lambda = static_cast<double*>(mxGetData(prhs[3]));
	double* mu = static_cast<double*>(mxGetData(prhs[4]));

	int p_space=dim_ad[1];
	int poly_space=dim_ad[0];
	double sum_eigs;
	double sum_log_eigs;
	double sum_log_eigs_sq;
    	double lmu=mu[0];
    	double llambda=lambda[0];
	int dim[1],dim2[1];
	dim[0]=dim_p[0]*dim_p[1];
	dim2[0]=1;

	//vnl_matrix<double> p_m(poly_space,p_space);
	//vnl_matrix<double> Ad_m(poly_space,p_space);
	//vnl_matrix<int> indices(poly_space,p_space);
	//vnl_matrix<double> PIJ(p_space,poly_space,0);
	//vnl_matrix<double> I_m(p_space,p_space);
	//I_m.set_identity();
	//vnl_matrix<double> E_m(p_space,p_space);
	//vnl_matrix<double> nablaPhi_m(p_space,p_space);
	//vnl_matrix<double> eigen_vectors(p_space,p_space);
	//vnl_vector<double> eigenvalues(p_space);
	//vnl_vector<double> log_eigenvalues(p_space);
	//vnl_vector<double> inv_eigenvalues(p_space);
	//vnl_vector<double> drepsilon(p_space);
	plhs[0] = mxCreateNumericArray(1,dim,mxDOUBLE_CLASS, mxREAL);
	double* drdp = static_cast<double*>(mxGetData(plhs[0]));
	plhs[1] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
	double* r = static_cast<double*>(mxGetData(plhs[1]));
	plhs[2] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
	double* f = static_cast<double*>(mxGetData(plhs[2]));
	
	r[0]=0;
	f[0]=0;
	int N=dim_simp[0];
    bool term=false;
//	mexPrintf("Start \n");	
    //task_scheduler_init init(2);
	parallel_for(blocked_range<int>(0,N),EigenDerivTBB(dim_p,dim_simp,dim_ad,p,simp,Ad,&llambda,&lmu ,p_space,poly_space,drdp,r,f,dim_mu,dim[0],&term),auto_partitioner());
    return;

//EigenDerivTBB(int* vdim_p,int* vdim_simp,int* vdim_ad,double* vp,double* vsimp,double* vAd,double* vlambda,double* vmu ,int vp_space,int vpoly_space,mwSize vdim,mwSize vdim2,double* vdrdp,double* vr,	double* vf) 
}

