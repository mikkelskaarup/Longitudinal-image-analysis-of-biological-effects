// EigenDeriv.cpp : Defines the entry point for the console application.


#include <math.h>
#include <mex.h>
#include <matrix.h>
#include <vector>
#include <vnl/vnl_matrix.h>
#include <vnl/algo/vnl_determinant.h>
#include <vnl/algo/vnl_symmetric_eigensystem.h>


using namespace std;

void printMatrixMatlab(vnl_matrix<double> m){

	for(int i=0;i<m.rows();i++){
		for(int j=0;j<m.cols();j++){
			mexPrintf("%f ", m.get(i,j));
		}
		mexPrintf("\n");
	}

}
void printMatrixMatlab(vnl_matrix<int> m){

	for(int i=0;i<m.rows();i++){
		for(int j=0;j<m.cols();j++){
			mexPrintf("%d ", m.get(i,j));
		}
		mexPrintf("\n");
	}

}



void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
const mxArray *prhs[])
{
	int* dim_p =(int*)mxGetDimensions(prhs[0]);
	int* dim_simp=(int*)mxGetDimensions(prhs[1]);
	int* dim_ad=(int*)mxGetDimensions(prhs[2]);
	int* dim_mu=(int*)mxGetDimensions(prhs[4]);

	double* p = static_cast<double*>(mxGetData(prhs[0]));
    double* simp = static_cast<double*>(mxGetData(prhs[1]));
	double* Ad = static_cast<double*>(mxGetData(prhs[2]));
	double* lambda = static_cast<double*>(mxGetData(prhs[3]));
	double* mu = static_cast<double*>(mxGetData(prhs[4]));
	
	int p_space=dim_ad[1];
	int poly_space=dim_ad[0];
	double sum_eigs;
	double sum_log_eigs;
	double sum_log_eigs_sq;

	mwSize dim[1],dim2[1];
	dim[0]=dim_p[0]*dim_p[1];
	dim2[0]=1;
	
	vnl_matrix<double> p_m(poly_space,p_space);
	vnl_matrix<double> Ad_m(poly_space,p_space);
	vnl_matrix<int> indices(poly_space,p_space);
	vnl_matrix<double> PIJ(p_space,poly_space,0);
	vnl_matrix<double> I_m(p_space,p_space);
	I_m.set_identity();
	vnl_matrix<double> E_m(p_space,p_space);
	vnl_matrix<double> nablaPhi_m(p_space,p_space);
	vnl_matrix<double> eigen_vectors(p_space,p_space);
	vnl_vector<double> eigenvalues(p_space);
	vnl_vector<double> log_eigenvalues(p_space);
	vnl_vector<double> inv_eigenvalues(p_space);
	vnl_vector<double> drepsilon(p_space);
	plhs[0] = mxCreateNumericArray(1,dim,mxDOUBLE_CLASS, mxREAL);
    double* drdp = static_cast<double*>(mxGetData(plhs[0]));
	plhs[1] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
    double* r = static_cast<double*>(mxGetData(plhs[1]));
	plhs[2] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
    double* f = static_cast<double*>(mxGetData(plhs[2]));
	int lam_mu=0;
	r[0]=0;
	f[0]=0;
	vector<int> vertices;
	for (int i=0;i<dim_simp[0];i++){
		if(dim_mu[0]>1)lam_mu=i;
		
		for (int j=0;j<poly_space;j++){
			vertices.push_back((int)simp[i+(j*dim_simp[0])]-1);
			int l_index=vertices[j];		
			for (int k=0;k<p_space;k++){
				l_index=vertices[j]+k*dim_p[0];
				p_m.put(j,k,p[l_index]);
				Ad_m.put(j,k,Ad[i*dim_ad[0]*dim_ad[1]+k*dim_ad[0]+j]);
				}
		}
		nablaPhi_m=I_m+p_m.transpose()*Ad_m;
		if(vnl_determinant<double>(nablaPhi_m)<0){
			f[0]=mxGetInf();
            p_m.clear();
            Ad_m.clear();
            indices.clear();
            PIJ.clear();
            I_m.clear();
            E_m.clear();
            nablaPhi_m.clear();
            eigen_vectors.clear();
            eigenvalues.clear();
            log_eigenvalues.clear();
            inv_eigenvalues.clear();
            drepsilon.clear();
			return;
		}
		sum_eigs=0;
		sum_log_eigs=0;
		sum_log_eigs_sq=0;
		E_m=nablaPhi_m*nablaPhi_m.transpose();
		vnl_symmetric_eigensystem<double> eig(E_m);		
		for (unsigned int j=0;j<p_space;j++){
		/*	if(eig.get_eigenvalue(j)<=0){
				f[0]=mxGetInf();			
				return;
			}*/
			sum_eigs+=eig.get_eigenvalue(j);
			sum_log_eigs+=log(eig.get_eigenvalue(j));
			sum_log_eigs_sq+=pow(log(eig.get_eigenvalue(j)),2);
			log_eigenvalues.put(j,log(eig.get_eigenvalue(j)));
			inv_eigenvalues.put(j,1/(eig.get_eigenvalue(j)));
			eigen_vectors.set_row(j,eig.get_eigenvector(j));
			
		}
		

		for (unsigned int j=0;j<p_space;j++){
			drepsilon.put(j,mu[lam_mu]/2*inv_eigenvalues.get(j)*log_eigenvalues.get(j)+lambda[lam_mu]/4*inv_eigenvalues.get(j)*sum_log_eigs);	
		}
		for (unsigned int j=0;j<poly_space;j++){
			for(unsigned int k=0;k<p_space;k++){
				indices.put(j,k,vertices[j]+k*dim_p[0]);
			}
		}

		vnl_matrix<double> tmp=Ad_m*nablaPhi_m.transpose()*eigen_vectors.transpose();
		vnl_matrix<int> it=indices.transpose();
		for (unsigned int j=0;j<poly_space;j++){
			for(unsigned int k=0;k<p_space;k++){
				for (unsigned int l=0;l<E_m.rows();l++){
					drdp[it(k,j)]=drdp[it(k,j)]+2*eigen_vectors.get(l,k)*tmp.get(j,l)*drepsilon.get(l);
				}

			}
		}
		
		tmp.clear();
		it.clear();
		vertices.clear();
		r[0]+=mu[lam_mu]/4*sum_log_eigs_sq+lambda[lam_mu]/8*pow(sum_log_eigs,2);
	}
	p_m.clear();
	Ad_m.clear();
	indices.clear();
	PIJ.clear();
	I_m.clear();
	E_m.clear();
	nablaPhi_m.clear();
	eigen_vectors.clear();
	eigenvalues.clear();
	log_eigenvalues.clear();
	inv_eigenvalues.clear();
	drepsilon.clear();
	
			
}

void eigderiv(int nlhs, mxArray *plhs[], int nrhs,
const mxArray *prhs[])
{
	int* dim_p =(int*)mxGetDimensions(prhs[0]);
	int* dim_simp=(int*)mxGetDimensions(prhs[1]);
	int* dim_ad=(int*)mxGetDimensions(prhs[2]);
	int* dim_lambda=(int*)mxGetDimensions(prhs[3]);
	int* dim_mu=(int*)mxGetDimensions(prhs[4]);

	double* p = static_cast<double*>(mxGetData(prhs[0]));
    double* simp = static_cast<double*>(mxGetData(prhs[1]));
	double* Ad = static_cast<double*>(mxGetData(prhs[2]));
	double* lambda = static_cast<double*>(mxGetData(prhs[3]));
	double* mu = static_cast<double*>(mxGetData(prhs[4]));
	
	int p_space=dim_ad[1];
	int poly_space=dim_ad[0];
	double sum_eigs;
	double sum_log_eigs;
	double sum_log_eigs_sq;

	mwSize dim[1],dim2[1];
	dim[0]=dim_p[0]*dim_p[1];
	dim2[0]=1;
	
	vnl_matrix<double> p_m(poly_space,p_space);
	vnl_matrix<double> Ad_m(poly_space,p_space);
	vnl_matrix<int> indices(poly_space,p_space);
	vnl_matrix<double> PIJ(p_space,poly_space,0);
	vnl_matrix<double> I_m(p_space,p_space);
	I_m.set_identity();
	vnl_matrix<double> E_m(p_space,p_space);
	vnl_matrix<double> nablaPhi_m(p_space,p_space);
	vnl_matrix<double> eigen_vectors(p_space,p_space);
	vnl_vector<double> eigenvalues(p_space);
	vnl_vector<double> log_eigenvalues(p_space);
	vnl_vector<double> inv_eigenvalues(p_space);
	vnl_vector<double> drepsilon(p_space);
	plhs[0] = mxCreateNumericArray(1,dim,mxDOUBLE_CLASS, mxREAL);
    double* drdp = static_cast<double*>(mxGetData(plhs[0]));
	plhs[1] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
    double* r = static_cast<double*>(mxGetData(plhs[1]));
	plhs[2] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
    double* f = static_cast<double*>(mxGetData(plhs[2]));
	//lamda mu counter
	int lam_mu=0;
	r[0]=0;
	f[0]=0;
	for (int i=0;i<dim_simp[0];i++){
		if(dim_mu[0]>1){
			lam_mu=i;
		}

		vector<int> vertices;
		for (int j=0;j<poly_space;j++){
			vertices.push_back((int)simp[i+(j*dim_simp[0])]-1);
			int l_index=vertices[j];		
			for (int k=0;k<p_space;k++){
				l_index=vertices[j]+k*dim_p[0];
				p_m.put(j,k,p[l_index]);
				Ad_m.put(j,k,Ad[i*dim_ad[0]*dim_ad[1]+k*dim_ad[0]+j]);
				}
		}
		nablaPhi_m=I_m+p_m.transpose()*Ad_m;
		if(vnl_determinant<double>(nablaPhi_m)<0){
			f[0]=mxGetInf();
			return;
		}
		sum_eigs=0;
		sum_log_eigs=0;
		sum_log_eigs_sq=0;
		E_m=nablaPhi_m*nablaPhi_m.transpose();
		vnl_symmetric_eigensystem<double> eig(E_m);		
		for (unsigned int j=0;j<p_space;j++){
			sum_eigs+=eig.get_eigenvalue(j);
			sum_log_eigs+=log(eig.get_eigenvalue(j));
			sum_log_eigs_sq+=pow(log(eig.get_eigenvalue(j)),2);
			log_eigenvalues.put(j,log(eig.get_eigenvalue(j)));
			inv_eigenvalues.put(j,1/(eig.get_eigenvalue(j)));
			eigen_vectors.set_row(j,eig.get_eigenvector(j));
		}

		for (unsigned int j=0;j<p_space;j++){
			drepsilon.put(j,mu[lam_mu]/2*inv_eigenvalues.get(j)*log_eigenvalues.get(j)+lambda[lam_mu]/4*inv_eigenvalues.get(j)*sum_log_eigs);	
		}
		for (unsigned int j=0;j<poly_space;j++){
			for(unsigned int k=0;k<p_space;k++){
				indices.put(j,k,vertices[j]+k*dim_p[0]);
			}
		}

		vnl_matrix<double> tmp=Ad_m*nablaPhi_m.transpose()*eigen_vectors.transpose();
		vnl_matrix<int> it=indices.transpose();
		for (unsigned int j=0;j<poly_space;j++){
			for(unsigned int k=0;k<p_space;k++){
				for (unsigned int l=0;l<E_m.rows();l++){
					drdp[it(k,j)]=drdp[it(k,j)]+2*eigen_vectors.get(l,k)*tmp.get(j,l)*drepsilon.get(l);
				}

			}
		}
		r[0]+=mu[lam_mu]/4*sum_log_eigs_sq+lambda[lam_mu]/8*pow(sum_log_eigs,2);
	}
			
}

//void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
//const mxArray *prhs[])
//{
//if(nrhs>5)
//eigderiv_dot(nlhs,plhs,nrhs,prhs);
//else eigderiv(nlhs,plhs,nrhs,prhs);
//}