// splineinterpolation2d.cpp : Defines the entry point for the console application.
//


#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <vector>
#include <omp.h>


#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/spin_mutex.h"
using namespace std;
using namespace tbb;
typedef spin_mutex MyMutexType;
MyMutexType MyMutex;
MyMutexType MyMutex2;
MyMutexType MyMutex3;
MyMutexType MyMutex4;
class interp
{
private:
	//	mwSize* dims;
	double* pts ;
	double* dataI ;
	double* dataR ;
	double* offset ;
	double* range;
	double* scale;
	int ndim ;
	int* dim_pts ;
	int* dim_img;
	int* dim_offset;
	int* dim_scale;
	int N;
	double* no_bins;
	double* pI ;
	double* pR ;
	double* pRI;
    double* det;
    double* sumDet;
	double* dfdx;
	double* diff1 ;
	double* diff2 ;
	double* diff3 ;
    double* weight ;
	double p;
	double* vall;
	

public:
	interp(double* vpts,double* vdataI,double* vdataR,double* voffset,double* vscale,int* vdim_img,
		int vN,double* vrange, double* vno_bins,	double* vdiff1 ,double* vdiff2,	double* vdiff3,double* vval,double vp, double* vweight ) {
			pts=vpts;
			dataI=vdataI;
			dataR=vdataR;
			p=vp;
			vall=vval;
			no_bins=vno_bins;
			range=vrange;
			offset=voffset;
			scale=vscale;
			dim_img=vdim_img;
			N=vN;
            weight=vweight;
            //sumDet=vsumDet;
			diff1=vdiff1;
			diff2=vdiff2;
			diff3=vdiff3;
	//		dfdx=vdfdx;
		

	}

	void operator()(const blocked_range<int> & r) const
	{

double sumdfdp=0;
			
		int s=64;
		int idx_idx=0;
		double lval=0;
		
		for(int i=r.begin();i!=r.end();i++)
		{
            //lsumDet+=1/det[i];
			double t=(pts[i]-offset[0])/scale[0]-floor((pts[i]-offset[0])/scale[0]);
			double t2=t*t;
			double t3=t2*t;

			double x[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double dx[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
			t=floor((pts[i]-offset[0])/scale[0])-1;
			int px[4]={(int)min<double>(max<double>(t-1,0),dim_img[0]-1),(int) max<double>(min<double>(t,dim_img[0]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[0]-1),(int) max<double>(min<double>(t+2,dim_img[0]-1),0)};

			t=(pts[i+N]-offset[1])/scale[1]-floor((pts[i+N]-offset[1])/scale[1]);
			t2=t*t;
			t3=t2*t;

			double y[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double dy[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
			t=floor((pts[i+N]-offset[1])/scale[1])-1;
			int py[4]={(int)min<double>(max<double>(t-1,0),dim_img[1]-1),(int) max<double>(min<double>(t,dim_img[1]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[1]-1),(int) max<double>(min<double>(t+2,dim_img[1]-1),0)};

			t=(pts[i+2*N]-offset[2])/scale[2]-floor((pts[i+2*N]-offset[2])/scale[2]);
			t2=t*t;
			t3=t2*t;

			double z[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double dz[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
			t=floor((pts[i+2*N]-offset[2])/scale[2])-1;

			int pz[4]={(int)min<double>(max<double>(t-1,0),dim_img[2]-1),(int) max<double>(min<double>(t,dim_img[2]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[2]-1),(int) max<double>(min<double>(t+2,dim_img[2]-1),0)};

			idx_idx=i*64;
			int index=0;
			double valtjeck=0;
			int idxR=(int)floor((dataR[i]-range[2]));	
			t=(dataR[i])-floor(dataR[i]);
			t2=t*t;
			t3=t2*t;

			double tr_val[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double val=0;
			for(int j=0;j<4;j++){
				for(int k=0;k<4;k++){
					for(int l=0;l<4;l++){

						int idx=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
						double dfdp=x[l]*y[k]*z[j]/216;
						val+=dataI[idx]*dfdp;
						sumdfdp+=dfdp;
						diff1[i]+=dx[l]*y[k]*z[j]/216*dataI[idx];
						diff2[i]+=x[l]*dy[k]*z[j]/216*dataI[idx];
						diff3[i]+=x[l]*y[k]*dz[j]/216*dataI[idx];
						
				
					}
				}
			}
			
			t=val-floor(val);
			t2=t*t;
			t3=t2*t;
			int dd=(int)(floor(val)-range[0]);
			//			
			double t_val[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double dt_val[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
			double tmp;
			double dNMIdW=0;			
			for(int m=0;m<4;m++)
						{
								for (int nn=0;nn<4;nn++){
									tmp=pow(abs((idxR+nn-1)-(dd+m-1)),p)/(N*36)*tr_val[nn]*weight[i];		
                                    //tmp=pow(abs((idxR+nn-1)-(dd+m-1)),p)/(N*36)*tr_val[nn];
									lval+=t_val[m]*tmp;
									dNMIdW+=dt_val[m]*tmp;
								}
						}
			diff1[i]=dNMIdW*diff1[i];
			diff2[i]=dNMIdW*diff2[i];
			diff3[i]=dNMIdW*diff3[i];
		}
        	{
				MyMutexType::scoped_lock lock(MyMutex2);
				vall[0]=vall[0]+lval;
		}
	}
};

class ParzenWindowPNorm
	{
		public:
		ParzenWindowPNorm()
		
		//create histograms
		//task_scheduler_init init(8);
		evaluate( double* pts,
		double* dataR,
		double* dataI,
		double* range,
		double* no_bins, 
		double* offset, 
		double* scale=,
		double p=1,
		double* weight,
		int* dim_img,
		int N=0,
		double* diff1 ,
		double* diff2 ,
		double* diff3 ,
		double* val;)
		{
		parallel_for(blocked_range<int>(0,N),interp(pts,dataI,dataR,offset,scale,dim_img,N,range,no_bins,diff1 ,diff2,diff3,val,p,weight),auto_partitioner());




		
		return;

		}


	};
	
