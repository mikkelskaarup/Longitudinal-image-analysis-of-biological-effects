// splineinterpolation2d.cpp : Defines the entry point for the console application.
//


#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <vector>


#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/spin_mutex.h"
using namespace std;
using namespace tbb;
typedef spin_mutex MyMutexType;
MyMutexType MyMutex;
MyMutexType MyMutex2;
MyMutexType MyMutex3;
class ImageBoundaryCondition{
private:
	int* imageDimensions;
public:
	void setImageDimensions(int* _imageDimensions){this->imageDimensions=_imageDimensions;};
	inline void returnIndexing(int t,int dimension,int* idx){
		idx[0]=(int)min<double>(max<double>(t-1,0),imageDimensions[dimension]-1);
		idx[1]=(int) max<double>(min<double>(t,imageDimensions[dimension]-1),0);
		idx[2]=(int)min<double>(max<double>(t+1,0),imageDimensions[dimension]-1);
		idx[3]=	(int) max<double>(min<double>(t+2,imageDimensions[dimension]-1),0);
	}
};
class BasisFunction{
public:
	double t;
	inline virtual void set_t(double x);
	inline virtual void f(double* x);
	inline  virtual void dfdt(double* df);
	inline   virtual void  ddfdt(double* ddf);
};
class BSpline{
private:
	double t;
	double t2;
	double t3;
public:
	BSpline(double t){
		this->t=t;
		this->t2=t*t;
		this->t3=t2*t;

	}
	inline void set_t(double t){
			this->t=t;
			this->t2=t*t;
			this->t3=t2*t;

	}
	inline void f(double* x){
		x[0]=-t3+3*t2-3*t+1;
		x[1]=3*t3-6*t2+4;
		x[2]=-3*t3+3*t2+3*t+1;
		x[3]= t3;
	}
	inline void dfdt(double* df){
			df[0]=-3*t2+6*t-3;
			df[1]=9*t2-12*t;
			df[2]=-9*t2+6*t+3;
			df[3]=3*t2;
		}
	inline void ddfdt(double* ddf){
				ddf[0]=-6*t+6;
				ddf[1]= 18*t-12;
				ddf[2]= -18*t+6;
				ddf[3]= 6*t;
			}
};
class ParallelPNorm
{
private:
	//	mwSize* dims;
	double* evaluationPoints ;
	double* stationaryImageData ;
	double* movingImageData ;
	double* origo ;

	double* aspectRatio;
	int ndim ;
	int* dim_evaluationPoints ;
	int* dim_stationaryImageData;
	int* dim_origo;
	int* dim_aspectRatio;
	int N;
	

	double* dfdx;
		double* stationaryImageDerivatives1 ;
	double* stationaryImageDerivatives2 ;
	double* stationaryImageDerivatives3 ;
	double* functionValue;
	double pNorm;
	double* evaluationPointWeight ;
	

public:
	ParallelPNorm(double* _evaluationPoints,double* _stationaryImageData,double* _movingImageData,double* _origo,double* _aspectRatio,int vndim,int* _dim_evaluationPoints,int* _dim_stationaryImageData,int* _dim_origo,int* _dim_aspectRatio,
		int _N,	double* _stationaryImageDerivatives1 ,double* _stationaryImageDerivatives2,	double* _stationaryImageDerivatives3,double* _functionValue,double _pNorm,double* _evaluationPointWeight ) {
			evaluationPoints=_evaluationPoints;
			stationaryImageData=_stationaryImageData;
			movingImageData=_movingImageData;
			pNorm=_pNorm;
		
			origo=_origo;
			aspectRatio=_aspectRatio;
			ndim=vndim;
			dim_evaluationPoints=_dim_evaluationPoints;
			dim_stationaryImageData=_dim_stationaryImageData;
			dim_origo=_dim_origo;
			dim_aspectRatio=_dim_aspectRatio;
			N=_N;
			functionValue=_functionValue;
			stationaryImageDerivatives1=_stationaryImageDerivatives1;
			stationaryImageDerivatives2=_stationaryImageDerivatives2;
			stationaryImageDerivatives3=_stationaryImageDerivatives3;
            evaluationPointWeight=_evaluationPointWeight;
	//		dfdx=vdfdx;
		

	}

	void operator()(const blocked_range<int> & r) const
	{

double sumdfdp=0;
			
		int s=64;
		int idx_idx=0;
		double x[4]={0,0,0,0};
		double dx[4]={0,0,0,0};
		double y[4]={0,0,0,0};
		double dy[4]={0,0,0,0};
		double z[4]={0,0,0,0};
		double dz[4]={0,0,0,0};
		int index_x[4]={0,0,0,0};
		int index_y[4]={0,0,0,0};
		int index_z[4]={0,0,0,0};
		int index=0;
		double lval=0;
		int indexMovingImage=0;
		int idx;
		int dd;
		double dPNormdW;
		double dfdp;
		double t;
		double lfunctionValue=0;

		double tr_val[4]={0,0,0,0};
		double t_val[4]={0,0,0,0};
		double dt_val[4]={0,0,0,0};
		double tmp_value;

		BSpline* bSpline=new BSpline(0);
		ImageBoundaryCondition* boundaryCondition=new ImageBoundaryCondition();
		boundaryCondition->setImageDimensions(dim_stationaryImageData);
		for(int i=r.begin();i!=r.end();i++)
		{

			t=(evaluationPoints[i]-origo[0])/aspectRatio[0]-floor((evaluationPoints[i]-origo[0])/aspectRatio[0]);
			bSpline->set_t(t);
			bSpline->f(x);
			bSpline->dfdt(dx);
			t=floor((evaluationPoints[i]-origo[0])/aspectRatio[0])-1;
			boundaryCondition->returnIndexing(t,0,index_x);

			t=(evaluationPoints[i+N]-origo[1])/aspectRatio[1]-floor((evaluationPoints[i+N]-origo[1])/aspectRatio[1]);
			bSpline->set_t(t);
			bSpline->f(y);
			bSpline->dfdt(dy);
			t=floor((evaluationPoints[i+N]-origo[1])/aspectRatio[1])-1;
			boundaryCondition->returnIndexing(t,1,index_y);

			t=(evaluationPoints[i+2*N]-origo[2])/aspectRatio[2]-floor((evaluationPoints[i+2*N]-origo[2])/aspectRatio[2]);
			bSpline->set_t(t);
			bSpline->f(z);
			bSpline->dfdt(dz);
			t=floor((evaluationPoints[i+2*N]-origo[2])/aspectRatio[2])-1;
			boundaryCondition->returnIndexing(t,2,index_z);

			idx_idx=i*64;
			index=0;
			lval=0;
			indexMovingImage=(int)floor(movingImageData[i]);
			t=(movingImageData[i])-floor(movingImageData[i]);
			bSpline->set_t(t);
			bSpline->f(tr_val);
			
			for(int j=0;j<4;j++){
				for(int k=0;k<4;k++){
					for(int l=0;l<4;l++){

						idx=index_x[l]+dim_stationaryImageData[0]*index_y[k]+dim_stationaryImageData[0]*dim_stationaryImageData[1]*index_z[j];
						dfdp=x[l]*y[k]*z[j]/216;
						sumdfdp+=dfdp;
						lval+=stationaryImageData[idx]*dfdp;
						stationaryImageDerivatives1[i]+=dx[l]*y[k]*z[j]/216*stationaryImageData[idx];
						stationaryImageDerivatives2[i]+=x[l]*dy[k]*z[j]/216*stationaryImageData[idx];
						stationaryImageDerivatives3[i]+=x[l]*y[k]*dz[j]/216*stationaryImageData[idx];
					}
				}
			}
			t=lval-floor(lval);
	      	dd=(int)(floor(lval));
			bSpline->set_t(t);
			bSpline->f(t_val);
			bSpline->dfdt(dt_val);
			dPNormdW=0;
			for(int m=0;m<4;m++)
				{
						for (int nn=0;nn<4;nn++){
							tmp_value=pow(abs((indexMovingImage+nn-1)-(dd+m-1)),pNorm)/(36)*tr_val[nn]*evaluationPointWeight[i];
	      					lfunctionValue+=t_val[m]*tmp_value;
							dPNormdW+=dt_val[m]*tmp_value;
						}
				}
				stationaryImageDerivatives1[i]+=dPNormdW*stationaryImageDerivatives1[i];
				stationaryImageDerivatives2[i]+=dPNormdW*stationaryImageDerivatives2[i];
				stationaryImageDerivatives3[i]+=dPNormdW*stationaryImageDerivatives3[i];
				}


		{
				MyMutexType::scoped_lock lock(MyMutex2);
				functionValue[0]=functionValue[0]+lfunctionValue;
		}
		
		
	}
};
void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
		const mxArray *prhs[])
	{
		//Colloecting input arguments and casting them to C++ double format
		double* evaluationPoints = static_cast<double*>(mxGetData(prhs[0]));
		double* movingImageData = static_cast<double*>(mxGetData(prhs[1]));
		double* stationaryImageData = static_cast<double*>(mxGetData(prhs[2]));
		double* origo = static_cast<double*>(mxGetData(prhs[3]));
		double* aspectRatio = static_cast<double*>(mxGetData(prhs[4]));
		double* pNorm = static_cast<double*>(mxGetData(prhs[5]));
        double* evaluationPointWeight = static_cast<double*>(mxGetData(prhs[6]));

        //Retrieveing dimensions of input arguments
		int ndim =(int)mxGetNumberOfDimensions(prhs[2]);
		int* dim_evaluationPoints =(int*)mxGetDimensions(prhs[0]);
		int* dim_stationaryImageData=(int*)mxGetDimensions(prhs[2]);
		int* dim_origo=(int*)mxGetDimensions(prhs[5]);
		int* dim_aspectRatio=(int*)mxGetDimensions(prhs[6]);
		int N=dim_evaluationPoints[0];

		//Setting up size of return arguments
		mwSize dim_derivatives[2];
		mwSize dim_functionvalue[1];

		dim_functionvalue[0] = 1;

		dim_derivatives[0] = N;
		dim_derivatives[1] = 1;

		//Allocating memory for return arguments
		plhs[0] = mxCreateNumericArray(1,dim_functionvalue,mxDOUBLE_CLASS, mxREAL);
		double* functionValue = static_cast<double*>(mxGetData(plhs[0]));
		plhs[1] = mxCreateNumericArray(2,dim_derivatives,mxDOUBLE_CLASS, mxREAL);
		double* stationaryImageDerivatives1 = static_cast<double*>(mxGetData(plhs[1]));
		plhs[2] = mxCreateNumericArray(2,dim_derivatives,mxDOUBLE_CLASS, mxREAL);
		double* stationaryImageDerivatives2 = static_cast<double*>(mxGetData(plhs[2]));
		plhs[3] = mxCreateNumericArray(2,dim_derivatives,mxDOUBLE_CLASS, mxREAL);
		double* stationaryImageDerivatives3 = static_cast<double*>(mxGetData(plhs[3]));

		//calling the TBB parallel pnorm class
		parallel_for(blocked_range<int>(0,N),ParallelPNorm(evaluationPoints,stationaryImageData,movingImageData,origo,aspectRatio,ndim,dim_evaluationPoints,dim_stationaryImageData,dim_origo,dim_aspectRatio,N,stationaryImageDerivatives1,stationaryImageDerivatives2,stationaryImageDerivatives3,functionValue,pNorm[0],evaluationPointWeight),auto_partitioner());
		
		return;

	};
