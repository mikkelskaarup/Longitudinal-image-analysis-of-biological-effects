// splineinterpolation2d.cpp : Defines the entry point for the console application.
//

#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <vector>


#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/spin_mutex.h"
using namespace std;
using namespace tbb;
typedef spin_mutex MyMutexType;
MyMutexType MyMutex;
MyMutexType MyMutex2;
MyMutexType MyMutex3;
MyMutexType MyMutex4;
class interp
{
private:
	//	mwSize* dims;
	double* pts ;
	double* dataI ;
	double* dataR ;
	double* offset ;
	double* range;
	double* scale;
	int ndim ;
	
	const int* dim_img;
	int* dim_offset;
	int* dim_scale;
	int N;
	int* no_bins;
	double* pI ;
	double* pR ;
	double* pRI;
    double* det;
    double* sumDet;
	double* dfdx;
		double* diff1 ;
	double* diff2 ;
	double* diff3 ;
	double* val;

public:
	interp(double* vpts,double* vdataI,double* vdataR,double* voffset,double* vscale,int vndim,const int* vdim_img,int* vdim_offset,int* vdim_scale,
		int vN,mwSize* vdims,double* vrange, int* vno_bins,double* vpI,double* vpR, double* vpRI, double* vdet, double* vsumDet,	double* vdiff1 ,double* vdiff2,	double* vdiff3,double* vval	) {
			pts=vpts;
			dataI=vdataI;
			dataR=vdataR;
			pI=vpI;
			pR=vpR;
			pRI=vpRI;
			no_bins=vno_bins;
			range=vrange;
			offset=voffset;
			scale=vscale;
			ndim=vndim;
			
			dim_img=vdim_img;
			dim_offset=vdim_offset;
			dim_scale=vdim_scale;
			N=vN;
            det=vdet;
		diff1=vdiff1;
			diff2=vdiff2;
			diff3=vdiff3;
            sumDet=vsumDet;
			val=vval;
	//		dfdx=vdfdx;
		

	}

	void operator()(const blocked_range<int> & r) const
	{

double sumdfdp=0;
			

		
	
		double* lpI=new double[(int)no_bins[0]];
		double* lpR=new double[(int)no_bins[0]];
		double* lpRI=new double[(int)no_bins[0]*(int)no_bins[1]];
        double lsumDet=0;
		for(int i=0;i<no_bins[0];i++){
			lpI[i]=0;
			for(int j=0;j<no_bins[1];j++){
				lpRI[j + i*(int)no_bins[1]]=0;
				lpR[j]=0;
			}
		}
		for(int i=r.begin();i!=r.end();i++)
		{
            diff1[i]=0;
			diff2[i]=0;
			diff3[i]=0;
			val[i]=0;
			lsumDet+=det[i];
			double t=(pts[i]-offset[0])/scale[0]-floor((pts[i]-offset[0])/scale[0]);
			
			double x[2]={1-t, t};
			double dx[2]={-1, 1};
			t=floor((pts[i]-offset[0])/scale[0])-1;
			int px[2]={(int)min<double>(max<double>(t-1,0),dim_img[0]-1),(int) max<double>(min<double>(t,dim_img[0]-1),0)};

			t=(pts[i+N]-offset[1])/scale[1]-floor((pts[i+N]-offset[1])/scale[1]);
			
            double y[2]={1-t, t};
			double dy[2]={-1, 1};
			
			t=floor((pts[i+N]-offset[1])/scale[1])-1;
			int py[2]={(int)min<double>(max<double>(t-1,0),dim_img[0]-1),(int) max<double>(min<double>(t,dim_img[0]-1),0)};

			t=(pts[i+2*N]-offset[2])/scale[2]-floor((pts[i+2*N]-offset[2])/scale[2]);
			
            double z[2]={1-t, t};
			double dz[2]={-1, 1};
			t=floor((pts[i+2*N]-offset[2])/scale[2])-1;

            int pz[2]={(int)min<double>(max<double>(t-1,0),dim_img[0]-1),(int) max<double>(min<double>(t,dim_img[0]-1),0)};


			int index=0;
			double valtjeck=0;
			int idxR=(int)floor((dataR[i]-range[2]));	
			t=(dataR[i])-floor(dataR[i]);
			double t2=t*t;
			double t3=t2*t;

			double tr_val[2]={1-t, t};
			for (int nn=0;nn<2;nn++){	
				lpR[idxR+nn-1]+=det[i]*tr_val[nn];
			}
			for(int j=0;j<2;j++){
				for(int k=0;k<2;k++){
					for(int l=0;l<2;l++){

						int idx=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
						double dfdp=x[l]*y[k]*z[j];
						val[i]+=dataI[idx]*dfdp;
						sumdfdp+=dfdp;
						
						diff1[i]+=dx[l]*y[k]*z[j]*dataI[idx];
						diff2[i]+=x[l]*dy[k]*z[j]*dataI[idx];
						diff3[i]+=x[l]*y[k]*dz[j]*dataI[idx];
						//using Parzen window 3rd order b-spline
				
					}
				}
			}
			t=val[i]-(int)(val[i]);
		

						double t_val[2]={1-t, t};
						int dd=(int)((val[i]));
						/*lpI[dd]+=dfdp*1/det[i];
						lpRI[idxR+(int)no_bins[1]*dd]+=dfdp*1/det[i];*/
						for(int m=0;m<2;m++)
						{
								lpI[dd+m-1]+=det[i]*t_val[m];
								for (int nn=0;nn<2;nn++){	
								lpRI[idxR+nn-1+(int)no_bins[1]*(dd+m-1)]+=det[i]*t_val[m]*tr_val[nn];
								}
						}
		/*	mexPrintf("\n");
			mexPrintf("sum dfdp: %f %f\n",sumdfdp,valtjeck);*/
		}
		for(int i=0;i<no_bins[0];i++){
			{
					MyMutexType::scoped_lock lock(MyMutex3);
					
			pI[i]+=lpI[i];
			}
			for(int j=0;j<no_bins[1];j++){
				MyMutexType::scoped_lock lock(MyMutex2);
				pRI[j + i*(int)no_bins[1]]+=lpRI[j + i*(int)no_bins[1]];
			}
		}
		for(int j=0;j<no_bins[1];j++){
			MyMutexType::scoped_lock lock(MyMutex);
			pR[j]+=lpR[j];
		}
        {
        	MyMutexType::scoped_lock lock(MyMutex4);
            sumDet[0]+=lsumDet;
        }
        
		delete lpR;
			delete lpI;
			delete lpRI;
		
	}
};


class NMI2
{
private:
	mwSize* dims;
	double* pts ;
	double* dataR ;
	double* dataI ;
	double* offset ;
	double* range;
	double* scale;
	int ndim ;
	
	const int* dim_img;
	int* dim_offset;
	int* dim_scale;
	int N;
	int* no_bins;
	double* diff1 ;
	double* diff2 ;
	double* diff3 ;
	double* pI ;
	double* pR;
	double* pRI ;
	double* LogpI ;
	double* LogpRI;
    double* det;
	double* val;
    double* detSum;
	double HI,HR,HRI;
	

public:
	NMI2(double* vpts,double* vdataR,double* vdataI,double* voffset,double* vscale,int vndim,const int* vdim_img,int* vdim_offset,int* vdim_scale,
		int vN,	double* vdiff1 ,double* vdiff2,	double* vdiff3 ,mwSize* vdims,double vHI,double vHR,double vHRI,double* vrange, int* vno_bins,double* vLogpI, double* vLogpRI,double* vdet,double* vval,double* vdetSum) {
			HR=vHR;
			HI=vHI;
			HRI=vHRI;
			LogpI=vLogpI;
			LogpRI=vLogpRI;
			range=vrange;
			no_bins=vno_bins;
			pts=vpts;
			dataR=vdataR;
			dataI=vdataI;
			offset=voffset;
			scale=vscale;
			ndim=vndim;
		
			dim_img=vdim_img;
			dim_offset=vdim_offset;
			dim_scale=vdim_scale;
			N=vN;
			diff1=vdiff1;
			diff2=vdiff2;
			diff3=vdiff3;
			det=vdet;
			val=vval;			
			//dfdp= vdfdp;
               detSum=vdetSum;
			dims=vdims;
			//mexPrintf("%d \n",N);
	}

	void operator()(const blocked_range<int> & r) const
	{


		
		for(int i=r.begin();i!=r.end();i++)
		{
			int idxR=(int)floor((dataR[i]-range[2]));	
			double t=(dataR[i])-floor(dataR[i]);
			double tr_val[2]={1-t,t};
			t=val[i]-floor(val[i]);
			int dd=(int)(floor(val[i])-range[0]);
			double t_val[2]={1-t, t};
			double dt_val[2]={-1, 1};
			double dNMIdW=0;			
			for(int m=0;m<2;m++)
						{
								for (int nn=0;nn<2;nn++){	
									dNMIdW+=det[i]*((-(LogpI[dd+m-1]+1)-(HR+HI)*(-(LogpRI[idxR+nn-1+(int)no_bins[1]*(dd+m-1)]+1))/HRI)/(HRI*detSum[0]))*dt_val[m]*tr_val[nn];						
								}
						}
			diff1[i]=dNMIdW*diff1[i];
			diff2[i]=dNMIdW*diff2[i];
			diff3[i]=dNMIdW*diff3[i];
		}
		
	}
};













	void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
		const mxArray *prhs[])
	{

		//bool doDerivative = false;
		//if(nlhs>1)
		//    doDerivative = true;
		if(nrhs==0)
			mexPrintf("NMI3D takes 6 arguments,pts,ref_data, Image, range, nobins, offset, scale (optional) ");
		if(nrhs<6)
			mexErrMsgTxt("Number of arguments must be 6");
		//mexPrintf("Spline interpolation takes 4 arguments ");
		double* pts = static_cast<double*>(mxGetData(prhs[0]));
		double* dataR = static_cast<double*>(mxGetData(prhs[1]));
		double* dataI = static_cast<double*>(mxGetData(prhs[2]));
		double* range = static_cast<double*>(mxGetData(prhs[3]));
		double* n_bins = static_cast<double*>(mxGetData(prhs[4]));
		double* offset = static_cast<double*>(mxGetData(prhs[5]));
		double* scale=new double[2];
		scale[0]=1;
		scale[1]=1;

		int* no_bins=new int[2];
		no_bins[0]=n_bins[0];
		no_bins[1]=n_bins[1];
		
		scale = static_cast<double*>(mxGetData(prhs[6]));
		double* det = static_cast<double*>(mxGetData(prhs[7]));
		double detSum=0;
		double* pI=new double[(int)no_bins[0]];
		double* pR=new double[(int)no_bins[1]];
		double* pRI=new double[(int)(no_bins[0]*no_bins[1])];
		double* LogpI=new double[(int)no_bins[1]];
		double* LogpRI=new double[(int)(no_bins[0]*no_bins[1])];

		int ndim =(int)mxGetNumberOfDimensions(prhs[2]);
		const int* dim_img=static_cast<const int*>(mxGetDimensions(prhs[2]));
		const int* dim_pts=static_cast<const int*>(mxGetDimensions(prhs[0]));
		int* dim_offset=(int*)mxGetDimensions(prhs[5]);
		int* dim_scale=(int*)mxGetDimensions(prhs[6]);
		int N=(int)dim_pts[0];
		////Allocate Tc
		mwSize dims[2];
		mwSize dims2[1];

		dims2[0] = 1; 
	

		
		dims[0] = N; dims[1] = 1;
		double* vals=new double[N];
		double* diff1 ;
		double* diff2 ;
		double* diff3 ;
		double HRI=0;
		double HI=0;
		double HR=0;
		bool do_deriv=false;
		if(nlhs>3)do_deriv=true;
		plhs[0] = mxCreateNumericArray(1,dims2,mxDOUBLE_CLASS, mxREAL);
		double* val = static_cast<double*>(mxGetData(plhs[0]));
		plhs[1] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff1 = static_cast<double*>(mxGetData(plhs[1]));
		plhs[2] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff2 = static_cast<double*>(mxGetData(plhs[2]));
		
		plhs[3] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff3 = static_cast<double*>(mxGetData(plhs[3]));
		//Initializing bins to 0
		for(int i=0;i<no_bins[0];i++){
			pI[i]=1/(N*no_bins[0]);
			for(int j=0;j<no_bins[1];j++){
				pRI[j + i*(int)no_bins[1]]=1/(N*no_bins[0]*no_bins[1]);
				pR[j]=1/(N*no_bins[1]);
			}
		}

		//const int NN = N;
		/*task_scheduler_init init(4);
		parallel_for(blocked_range<int>(0,N,N/4),interp(pts,data,offset,scale,ndim,dim_pts,dim_img,dim_offset,dim_scale,N,diff1 ,diff2 ,dfdx,do_deriv,val,dfdp,idx,dims),simple_partitioner());
		*/
		//create histograms
		//task_scheduler_init init(4);
		//mexPrintf("building histogram\n");
		parallel_for(blocked_range<int>(0,N),interp(pts,dataI,dataR,offset,scale,ndim,dim_img,dim_offset,dim_scale,N,dims,range,no_bins,pI,pR,pRI,det,&detSum,diff1,diff2,diff3,vals),auto_partitioner());
		double sumPI=0;
        double sumPIR=0;
        double sumPR=0;
		//take the logarithm
		//mexPrintf("taking the log\n");
        detSum++;
		for(int i=0;i<no_bins[0];i++){
			LogpI[i]=0;
			if(pI[i]>0){
				pI[i]=pI[i]/detSum;
				LogpI[i]=log(pI[i]);
				HI+=pI[i]*LogpI[i];
				sumPI+=pI[i];
			}
			for(int j=0;j<no_bins[1];j++){
				LogpRI[j + i*(int)no_bins[1]]=0;
				if(pRI[j + i*(int)no_bins[1]]>0){
					pRI[j + i*(int)no_bins[1]]=pRI[j + i*(int)no_bins[1]]/detSum;
					LogpRI[j + i*(int)no_bins[1]]=log(pRI[j + i*(int)no_bins[1]]);
					HRI+=pRI[j + i*(int)no_bins[1]]*LogpRI[j + i*(int)no_bins[1]];
                    sumPIR+=pRI[j + i*(int)no_bins[1]];
				}
			}
		}
// 		mexPrintf("sumPI: %f \n",sumPI);
		for(int j=0;j<no_bins[1];j++){
			if(pR[j]>0){
				pR[j]=pR[j]/detSum;
				HR+=pR[j]*log(pR[j]);
                sumPR+=pR[j];
			}
		}
//         mexPrintf("sumPIR: %f \n",sumPIR);
//         mexPrintf("sumPR: %f \n",sumPR);
//        mexPrintf("detSum: %f \n",detSum);
		//compute the spatial derivatives of NMI
		
		//task_scheduler_init init2();
// 		mexPrintf("NMI calc. HR HI HRI.. %f %f %f\n",HR,HI,HRI);
		parallel_for(blocked_range<int>(0,N),NMI2(pts,dataR,dataI,offset,scale,ndim,dim_img,dim_offset,dim_scale,N,diff1 ,diff2,diff3 ,dims,HI,HR,HRI,range, no_bins,LogpI,LogpRI,det,vals,&detSum),auto_partitioner());
		
		val[0]=((-HR)+(-HI))/(-HRI);
		delete pI;
		delete pR;
		delete pRI;
		delete LogpI;
		delete LogpRI;
		delete vals;
		return;




	};