// splineinterpolation2d.cpp : Defines the entry point for the console application.
//


#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <vector>


#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/spin_mutex.h"
using namespace std;
using namespace tbb;
typedef spin_mutex MyMutexType;
MyMutexType MyMutex;
MyMutexType MyMutex2;
MyMutexType MyMutex3;
class interp
{
private:
	//	mwSize* dims;
	double* pts ;
	double* dataI ;
	double* dataR ;
	double* offset ;
	double* range;
	double* scale;
	int ndim ;
	int* dim_pts ;
	int* dim_img;
	int* dim_offset;
	int* dim_scale;
	int N;
	double* no_bins;
	double* pI ;
	double* pR ;
	double* pRI;

	double* dfdx;
		double* diff1 ;
	double* diff2 ;
	double* diff3 ;
	double* val;
	double p;
	

public:
	interp(double* vpts,double* vdataI,double* vdataR,double* voffset,double* vscale,int vndim,int* vdim_pts,int* vdim_img,int* vdim_offset,int* vdim_scale,
		int vN,mwSize* vdims,double* vrange, double* vno_bins,	double* vdiff1 ,double* vdiff2,	double* vdiff3,double* vval,double vp ) {
			pts=vpts;
			dataI=vdataI;
			dataR=vdataR;
			p=vp;
			no_bins=vno_bins;
			range=vrange;
			offset=voffset;
			scale=vscale;
			ndim=vndim;
			dim_pts=vdim_pts;
			dim_img=vdim_img;
			dim_offset=vdim_offset;
			dim_scale=vdim_scale;
			N=vN;
			val=vval;
			diff1=vdiff1;
			diff2=vdiff2;
			diff3=vdiff3;
	//		dfdx=vdfdx;
		

	}

	void operator()(const blocked_range<int> & r) const
	{

double sumdfdp=0;
			
		int s=8;
		int idx_idx=0;
		
		double lval=0;
		for(int i=r.begin();i!=r.end();i++)
		{

						double t=(pts[i]-offset[0])/scale[0]-floor((pts[i]-offset[0])/scale[0]);
			double x[2]={t,1-t};
			double dx[2]={1,-1};
			t=floor((pts[i]-offset[0])/scale[0])-1;
			int px[2]={(int) max<double>(min<double>(t,dim_img[0]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[0]-1)};

			t=(pts[i+N]-offset[1])/scale[1]-floor((pts[i+N]-offset[1])/scale[1]);
			
			double y[2]={t,1-t};
			double dy[2]={1,-1};
			t=floor((pts[i+N]-offset[1])/scale[1])-1;
			int py[2]={(int) max<double>(min<double>(t,dim_img[1]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[1]-1)};

			t=(pts[i+2*N]-offset[2])/scale[2]-floor((pts[i+2*N]-offset[2])/scale[2]);
			
			double z[2]={t,1-t};
			double dz[2]={1,-1};
			t=floor((pts[i+2*N]-offset[2])/scale[2])-1;

			int pz[2]={(int) max<double>(min<double>(t,dim_img[2]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[2]-1)};
			idx_idx=i*8;
			int index=0;
			double valtjeck=0;
			int idxR=(int)floor((dataR[i]-range[2])+0.5);	
			
			for(int j=0;j<2;j++){
				for(int k=0;k<2;k++){
					for(int l=0;l<2;l++){

						int idx=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
						double dfdp=x[l]*y[k]*z[j];
						sumdfdp+=dfdp;
						int dd=(int)floor((dataI[idx]-range[0])+0.5);
						
						double dMIdW=pow(abs(idxR-dd),p)/N;
						lval=lval+dfdp*dMIdW;
						diff1[i]+=dMIdW*dx[l]*y[k]*z[j];
						diff2[i]+=dMIdW*x[l]*dy[k]*z[j];
						diff3[i]+=dMIdW*x[l]*y[k]*dz[j];
						
					
					}
				}
			}
		/*	mexPrintf("\n");
			mexPrintf("sum dfdp: %f %f\n",sumdfdp,valtjeck);*/
		}
		{
				MyMutexType::scoped_lock lock(MyMutex2);
				val[0]=val[0]+lval;
		}
		
		
	}
};
void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
		const mxArray *prhs[])
	{

		//bool doDerivative = false;
		//if(nlhs>1)
		//    doDerivative = true;
		if(nrhs==0)
			mexPrintf("NMI3D takes 6 arguments,pts,ref_data, Image, range, nobins, offset, scale (optional) ");
		if(nrhs<6)
			mexErrMsgTxt("Number of arguments must be 6");
		//mexPrintf("Spline interpolation takes 4 arguments ");
		double* pts = static_cast<double*>(mxGetData(prhs[0]));
		double* dataR = static_cast<double*>(mxGetData(prhs[1]));
		double* dataI = static_cast<double*>(mxGetData(prhs[2]));
		double* range = static_cast<double*>(mxGetData(prhs[3]));
		double* no_bins = static_cast<double*>(mxGetData(prhs[4]));
		double* offset = static_cast<double*>(mxGetData(prhs[5]));
		double* scale=new double[2];
		scale[0]=1;
		scale[1]=1;

		scale = static_cast<double*>(mxGetData(prhs[6]));
		double* p = static_cast<double*>(mxGetData(prhs[7]));
//		mexPrintf("%f \n",p[0]);


		int ndim =(int)mxGetNumberOfDimensions(prhs[2]);
		int* dim_pts =(int*)mxGetDimensions(prhs[0]);
		int* dim_img=(int*)mxGetDimensions(prhs[2]);
		int* dim_offset=(int*)mxGetDimensions(prhs[5]);
		int* dim_scale=(int*)mxGetDimensions(prhs[6]);
		int N=dim_pts[0];
		////Allocate Tc
		mwSize dims[2];
		mwSize dims2[1];

		dims2[0] = 1; 
		

		
		dims[0] = N; dims[1] = 1;
		
		double* diff1 ;
		double* diff2 ;
		double* diff3 ;
			bool do_deriv=false;
		if(nlhs>3)do_deriv=true;
		plhs[0] = mxCreateNumericArray(1,dims2,mxDOUBLE_CLASS, mxREAL);
		double* val = static_cast<double*>(mxGetData(plhs[0]));
		plhs[1] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff1 = static_cast<double*>(mxGetData(plhs[1]));
		plhs[2] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff2 = static_cast<double*>(mxGetData(plhs[2]));
		
		plhs[3] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff3 = static_cast<double*>(mxGetData(plhs[3]));
		//Initializing bins to 0
//		mexPrintf("%f \n",p[0]);

		//const int NN = N;
		/*task_scheduler_init init(4);
		parallel_for(blocked_range<int>(0,N,N/4),interp(pts,data,offset,scale,ndim,dim_pts,dim_img,dim_offset,dim_scale,N,diff1 ,diff2 ,dfdx,do_deriv,val,dfdp,idx,dims),simple_partitioner());
		*/
		//create histograms
		//task_scheduler_init init(8);
		//mexPrintf("building histogram\n");
		parallel_for(blocked_range<int>(0,N),interp(pts,dataI,dataR,offset,scale,ndim,dim_pts,dim_img,dim_offset,dim_scale,N,dims,range,no_bins,diff1,diff2,diff3,val,p[0]),auto_partitioner());
		
		return;




	};