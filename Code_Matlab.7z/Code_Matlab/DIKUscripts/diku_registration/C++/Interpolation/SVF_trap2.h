#ifndef SVF_TRAP_H_
#define SVF_TRAP_H_
#include <vector>
#include <stdio.h>
#include <math.h>

using namespace std;

void SVF_TRAP(double* data, //vector field
		int* dims, //dimension of the vector field
		int* dim_img, // number of elements in each direction
		double* pts, // evaluation points
		int N, //Number of evaluation points
		double* offset, //the offset
		double* scale, //scale of the vector field
		int steps, //number of time steps
		int* ncnt, //vector of previous counts
		int iter, //iterations for n+1
		double * derivs, //Image derivatives
		double* val, // deformed points
		double* dvdp) {
	double diff1[3];
	double diff2[3];
	double diff3[3];
	vector<double> dfdp(8, 0);
	vector<double> dfdx(24, 0);
	double dx[2] = { -1, 1 };
	double dy[2] = { -1, 1 };
	double dz[2] = { -1, 1 };
	double px[2] = { -1, 1 };
	double py[2] = { -1, 1 };
	double pz[2] = { -1, 1 };
	vector<double> inv(9, 0);
	vector<double> M(9, 0);
	vector<double> M1(9, 0);
	vector<double> tmp_mul(3, 0);
	double tpts[3];
	double dpts[3];
	vector<int> idx_x;
	vector<double> X;
  double x[2];
  double y[2];
  double z[2];
	int idx;
	int index;
	int s = 8;
	int idx_idx = 0;
	int cnt = 0;
	//Looping over all evaluation points
	for (int i = 0; i < N; i++) {
		cnt = 0;
		idx_x.assign(ncnt[i] + 8, -1);
		X.assign((ncnt[i] + 8) * 3, 0);

		for (int n = 0; n < dims[1]; n++) {
			val[i + n * N] = pts[i + n * N];
		}
		tpts[0] = 0;
		tpts[1] = 0;
		tpts[2] = 0;
		double t = ((val[i]) - offset[0]) / scale[0]
				- floor((val[i] - offset[0]) / scale[0]);
		x[0]=1 - t;
    x[1]=t;
		t = floor((val[i] - offset[0]) / scale[0]);
		px[0] = (int) max<double>(min<double>(t, dim_img[0] - 1), 0);
		px[1] = (int) min<double>(max<double>(t + 1, 0), dim_img[0] - 1);

		t = (val[i + N] - offset[1]) / scale[1]
				- floor((val[i + N] - offset[1]) / scale[1]);

		y[0] =  1 - t;
		y[1] =  t ;
		t = floor((0.5 * (val[i + N] + pts[i + N]) - offset[1]) / scale[1]);
		py[0] = (int) max<double>(min<double>(t, dim_img[1] - 1), 0);
		py[1] = (int) min<double>(max<double>(t + 1, 0), dim_img[1] - 1);

		t = (val[i + 2 * N] - offset[2]) / scale[2]
				- floor((val[i + 2 * N] - offset[2]) / scale[2]);

		z[0] =  1 - t;
    z[1] = t ;
		t = floor((val[i + 2 * N] - offset[2]) / scale[2]);

		pz[0] = (int) max<double>(min<double>(t, dim_img[2] - 1), 0);
		pz[1] = (int) min<double>(max<double>(t + 1, 0), dim_img[2] - 1);
		idx_idx = 0;
		index = 0;

		for (int m = 0; m < dims[1]; m++) {
			diff1[m] = 0;
			diff2[m] = 0;
			diff3[m] = 0;
		}
		for (int j = 0; j < 2; j++) {
			for (int k = 0; k < 2; k++) {
				for (int l = 0; l < 2; l++) {
					idx = px[l] + dim_img[0] * py[k]
							+ dim_img[0] * dim_img[1] * pz[j];
          if(idx_idx==0)idx_x[idx_idx]=idx;
					dfdp[idx_idx] = x[l] * y[k] * z[j];
					index = l + 2 * k + 4 * j;
					dfdx[index] = dx[l] * y[k] * z[j];
					dfdx[index + 8] = x[l] * dy[k] * z[j];
					dfdx[index + 16] = x[l] * y[k] * dz[j];

					for (int m = 0; m < dims[1]; m++) {
						double dd = data[idx
								+ dim_img[0] * dim_img[1] * dim_img[2] * m];
						tpts[m] += dfdp[idx_idx] * dd;
						diff1[m] += dfdx[index] * dd;
						diff2[m] += dfdx[index + 8] * dd;
						diff3[m] += dfdx[index + 16] * dd;

					}

					idx_idx++;
				}
			}
		}
		for (int t_steps = 0; t_steps < (int) steps; t_steps++) {
			//Setup M
			M.assign(9, 0);
			M[0] = 1 + 0.5 * diff1[0]/scale[0];
			M[1] = 0.5 * diff2[0]/scale[1];
			M[2] = 0.5 * diff3[0]/scale[2];

			M[3] = 0.5 * diff1[1]/scale[0];
			M[4] = 1 + 0.5 * diff2[1]/scale[1];
			M[5] = 0.5 * diff3[1]/scale[2];

			M[6] = 0.5 * diff1[2]/scale[0];
			M[7] = 0.5 * diff2[2]/scale[1];
			M[8] = 1 + 0.5 * diff3[2]/scale[2];
   		//Multiply M*X_1
     
			for (int jj = 0; jj < cnt*3; jj++) {
				tmp_mul[0] = M[0] * X[jj * 3] + M[1] * X[jj * 3 + 1]
						+ M[2] * X[jj * 3 + 2];
				tmp_mul[1] = M[3] * X[jj * 3] + M[4] * X[jj * 3 + 1]
						+ M[5] * X[jj * 3 + 2];
				tmp_mul[2] = M[6] * X[jj * 3] + M[7] * X[jj * 3 + 1]
						+ M[8] * X[jj * 3 + 2];
				X[jj * 3] = tmp_mul[0];
				X[jj * 3 + 1] = tmp_mul[1];
				X[jj * 3 + 2] = tmp_mul[2];

      }
      
    
			idx_idx = 0;
			for (int j = 0; j < 2; j++) {
				for (int k = 0; k < 2; k++) {
					for (int l = 0; l < 2; l++) {
						idx_x[cnt] = px[l] + dim_img[0] * py[k]
														+ dim_img[0] * dim_img[1] * pz[j];
												int ii = 0;
												while (ii <= cnt) {
													if (idx_x[ii] == idx_x[cnt]) {
                      
														X[ii * 9] += dfdp[idx_idx] * 0.5;
														X[ii * 9 + 4] += dfdp[idx_idx] * 0.5;
														X[ii * 9 + 8] += dfdp[idx_idx] * 0.5;
														break;
													}
													ii++;
												}
												if (ii == cnt) {
													cnt++;
												}
												idx_idx++;
					}
				}
			}

													
//       for (int n = 0; n < cnt*3; n++) 
//       mexPrintf("%d %f %f %f ",idx_x[(int)n/3],X[n * 3],X[n * 3+1],X[n * 3+2]);
//       mexPrintf("\n");
      double tmpts[3]={val[i]+tpts[0],val[i+N]+tpts[1],val[i+2*N]+tpts[2]};
      dpts[0]=tpts[0];
      dpts[1]=tpts[1];
      dpts[2]=tpts[2];
     for (int o = 0; o < (int) iter; o++) 
      {
       //  mexPrintf("%d %f %f %f %f %f %f %f %f %f \n",o,	dpts[0],	dpts[1],	dpts[2], tpts[0], tpts[1], tpts[2],tmpts[0],tmpts[1],tmpts[2]);
	
        double t=((tmpts[0]-offset[0])/scale[0])-floor((tmpts[0]-offset[0])/scale[0]);
        x[0]=1-t;
        x[1]=t;
        t=floor((tmpts[0]-offset[0])/scale[0]);
        px[0]=(int) max<double>(min<double>(t,dim_img[0]-1),0);
        px[1]=(int) min<double>(max<double>(t+1,0),dim_img[0]-1);

        t=(tmpts[1]-offset[1])/scale[1]-floor((tmpts[1]-offset[1])/scale[1]);

        y[0]=1-t;
        y[1]=t;
        t=floor((tmpts[1]-offset[1])/scale[1]);
        py[0]=(int) max<double>(min<double>(t,dim_img[1]-1),0);
        py[1]=(int) min<double>(max<double>(t+1,0),dim_img[1]-1);

        t=(tmpts[2]-offset[2])/scale[2]-floor((tmpts[2]-offset[2])/scale[2]);

        z[0]=1-t;
        z[1]=t;
        t=floor((tmpts[2]-offset[2])/scale[2]);

        pz[0]=(int) max<double>(min<double>(t,dim_img[2]-1),0);
        pz[1]=(int)min<double>(max<double>(t+1,0),dim_img[2]-1);

        idx_idx=i*8;
        int index=0;
        tpts[0]=0;
        tpts[1]=0;
        tpts[2]=0;
				for (int j = 0; j < 2; j++) {
					for (int k = 0; k < 2; k++) {
						for (int l = 0; l < 2; l++) {
							idx = px[l] + dim_img[0] * py[k]
									+ dim_img[0] * dim_img[1] * pz[j];
							dfdp[idx_idx] = x[l] * y[k] * z[j];
							for (int m = 0; m < dims[1]; m++) {
								double dd = data[idx+ dim_img[0] * dim_img[1] * dim_img[2]* m];
								tpts[m] += dfdp[idx_idx] * dd;
							}
							idx_idx++;
						}
					}
				}
        for(int n=0;n<dims[1];n++)
      {
        tmpts[n]=val[i+n*N]+0.5*(dpts[n]+tpts[n]);
      }
			}
			for (int m = 0; m < dims[1]; m++) {
				diff1[m] = 0;
				diff2[m] = 0;
				diff3[m] = 0;
			}
			{
				idx_idx = 0;
				int index = 0;
				for (int j = 0; j < 2; j++) {
					for (int k = 0; k < 2; k++) {
						for (int l = 0; l < 2; l++) {
							idx = px[l] + dim_img[0] * py[k]
									+ dim_img[0] * dim_img[1] * pz[j];
							dfdx[index] = dx[l] * y[k] * z[j];
							dfdx[index + 8] = x[l] * dy[k] * z[j];
							dfdx[index + 16] = x[l] * y[k] * dz[j];
							for (int m = 0; m < dims[1]; m++) {
								double dd = data[idx
										+ dim_img[0] * dim_img[1] * dim_img[2]
												* m];
								diff1[m] += dfdx[index] * dd;
								diff2[m] += dfdx[index + 8] * dd;
								diff3[m] += dfdx[index + 16] * dd;
							}
							idx_idx++;
						}
					}
				}
			}
			//Solve for M1*X=M*X_1+(B1+B)*0.5;
			//Initialize 3x3 Identity matrix
			inv.assign(9, 0);
			inv[0] = 1;
			inv[4] = 1;
			inv[8] = 1;
			//M*X_1
			//Setup M1
			M.assign(9, 0);
			M1[0] = 1 - 0.5 * diff1[0]/scale[0];
			M1[1] = -0.5 * diff2[0]/scale[1];
			M1[2] = -0.5 * diff3[0]/scale[2];

			M1[3] = -0.5 * diff1[1]/scale[0];
			M1[4] = 1 - 0.5 * diff2[1]/scale[1];
			M1[5] = -0.5 * diff3[1]/scale[2];

			M1[6] = -0.5 * diff1[2]/scale[0];
			M1[7] = -0.5 * diff2[2]/scale[1];
			M1[8] = 1 - 0.5 * diff3[2]/scale[2];

      
			idx_idx = 0;
			for (int j = 0; j < 2; j++) {
				for (int k = 0; k < 2; k++) {
					for (int l = 0; l < 2; l++) {
						idx_x[cnt] = px[l] + dim_img[0] * py[k]
														+ dim_img[0] * dim_img[1] * pz[j];
												int ii = 0;
												while (ii <= cnt) {
													if (idx_x[ii] == idx_x[cnt]) {
                          
														X[ii * 9] += dfdp[idx_idx] * 0.5;
														X[ii * 9 + 4] += dfdp[idx_idx] * 0.5;
														X[ii * 9 + 8] += dfdp[idx_idx] * 0.5;
														break;
													}
													ii++;
												}
												if (ii == cnt) {
													cnt++;
												}
												idx_idx++;
					}
				}
			}
     
			//compute the inverse using cramers rule
			double det =
					1
							/ ((M1[0] * M1[4] * M1[8]) + (M1[1] * M1[5] * M1[6])
									+ (M1[2] * M1[3] * M1[7])
									- (M1[0] * M1[5] * M1[7])
									- (M1[1] * M1[3] * M1[8])
									- (M1[2] * M1[4] * M1[6]));
      //the transpose inverse
// 			inv[0] = (M1[4] * M1[8] - M1[7] * M1[5]) * det;
// 			inv[1] = -(M1[3] * M1[8] - M1[5] * M1[6]) * det;
// 			inv[2] = (M1[3] * M1[7] - M1[4] * M1[6]) * det;
// 			inv[3] = -(M1[1] * M1[8] - M1[2] * M1[7]) * det;
// 			inv[4] = (M1[0] * M1[8] - M1[2] * M1[6]) * det;
// 			inv[5] = -(M1[0] * M1[7] - M1[1] * M1[6]) * det;
// 			inv[6] = (M1[1] * M1[5] - M1[2] * M1[4]) * det;
// 			inv[7] = -(M1[0] * M1[5] - M1[2] * M1[3]) * det;
// 			inv[8] = (M1[0] * M1[4] - M1[1] * M1[3]) * det;

		//the inverse
			      inv[0]=(M1[4]*M1[8]-M1[7]*M1[5])*det;
			      inv[3]=-(M1[3]*M1[8]-M1[5]*M1[6])*det;
			      inv[6]=(M1[3]*M1[7]-M1[4]*M1[6])*det;
			      inv[1]=-(M1[1]*M1[8]-M1[2]*M1[7])*det;
			      inv[4]=(M1[0]*M1[8]-M1[2]*M1[6])*det;
			      inv[7]=-(M1[0]*M1[7]-M1[1]*M1[6])*det;
			      inv[2]=(M1[1]*M1[5]-M1[2]*M1[4])*det;
			      inv[5]=-(M1[0]*M1[5]-M1[2]*M1[3])*det;
			      inv[8]=(M1[0]*M1[4]-M1[1]*M1[3])*det;

			for (int jj = 0; jj < cnt*3; jj++) {
				tmp_mul[0] = inv[0] * X[jj * 3] + inv[1] * X[jj * 3 + 1]
						+ inv[2] * X[jj * 3 + 2];
				tmp_mul[1] = inv[3] * X[jj * 3] + inv[4] * X[jj * 3 + 1]
						+ inv[5] * X[jj * 3 + 2];
				tmp_mul[2] = inv[6] * X[jj * 3] + inv[7] * X[jj * 3 + 1]
						+ inv[8] * X[jj * 3 + 2];
				X[jj * 3] = tmp_mul[0];
				X[jj * 3 + 1] = tmp_mul[1];
				X[jj * 3 + 2] = tmp_mul[2];
			}
			for (int n = 0; n < dims[1]; n++) {
				val[i + n * N] += 0.5 * (dpts[n] + tpts[n]);
			}

		}
		for (int n = 0; n < cnt*3; n++) {
 //     mexPrintf("%d %f %f %f ",idx_x[(int)n/3],X[n * 3],X[n * 3+1],X[n * 3+2]);
			dvdp[idx_x[n]]+= derivs[i] * X[n * 3];
			dvdp[idx_x[n]]+= derivs[i + N] * X[n * 3 + 1];
			dvdp[idx_x[n]]+= derivs[i + 2 * N] * X[n * 3 + 2];
		}


	}
}
;
#endif
