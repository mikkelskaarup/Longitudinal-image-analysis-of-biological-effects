//**************************************************************
//Splineinterpolation_lin.cpp is authored by Sune Darkner and is provided as is
//The file may not be re-distributed without prior permission.
//The auther cannot in any circumstances be held reliable of
//damages, financial or other types of loses cased by the use
//or the use of derivative products from this file. The author
//cannot be held liable in any way under any circumstances.
//**************************************************************
#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <vector>
#include <algorithm>

using namespace std;




void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
        const mxArray *prhs[])
{

  //bool doDerivative = false;
  //if(nlhs>1)
  //    doDerivative = true;
  if(nrhs==0)
    mexPrintf("Spline interpolation takes 4 arguments ");
  if(nrhs<3)
    mexErrMsgTxt("Number of arguments must be 3");
  // mexPrintf("Spline interpolation takes 4 arguments ");
  double* pts = static_cast<double*>(mxGetData(prhs[0]));
  double* data = static_cast<double*>(mxGetData(prhs[1]));
  double* offset = static_cast<double*>(mxGetData(prhs[2]));
  double* scale=static_cast<double*>(mxGetData(prhs[3]));
  double *steps=static_cast<double*>(mxGetData(prhs[4]));
  double *iter=static_cast<double*>(mxGetData(prhs[5]));



  //int* dx = static_cast<double*>(mxGetData(prhs[2]));

  int ndim =(int)mxGetNumberOfDimensions(prhs[1]);
  int* dim_pts =(int*)mxGetDimensions(prhs[0]);
  //mexPrintf("%d",dim_pts[0]);
  int* dim_img=(int*)mxGetDimensions(prhs[1]);
  int* dim_offset=(int*)mxGetDimensions(prhs[2]);
  int* dim_scale=(int*)mxGetDimensions(prhs[3]);
  int N=dim_pts[0];
  //size_t N = mxGetNumberOfElements(prhs[0])/3;
  ////Allocate Tc
  mwSize dims[2];
  mwSize dims2[2];

  dims2[0] = 1;
  dims2[1] = N;

  mwSize dims3[3];
  double x[2];
  double y[2];
  double z[2];
  dims3[0] = (int)steps[0];
  dims3[1] = 3;
  dims3[2] = N;
  dims[0] = N; dims[1] = 1;
  if(ndim>3){
    dims[1] = dim_img[3];
  }

  plhs[0] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
  double* val = static_cast<double*>(mxGetData(plhs[0]));
//   plhs[1] = mxCreateNumericArray(2,dims2,mxINT32_CLASS, mxREAL);
//   int* cnt = static_cast<int*>(mxGetData(plhs[1]));

  double tpts[3];
  double dpts[3];
  int tidx[3]={-1,-1,-1};
  int s=8;
  std::vector<int> idx_x((int)steps[0]*8,0);
  
  int idx_idx=0;
  for(int i=0;i<N;i++)
  {
//     cnt[i]=0;
//      idx_x.assign((int)steps[0]*8,0);
    for(int n=0;n<dims[1];n++)
    {
      tidx[n]=-1;
      val[i+n*N]=pts[i+n*N];
    }
     

    
      tpts[0]=0;
      tpts[1]=0;
      tpts[2]=0;
      double t=((val[i])-offset[0])/scale[0]-floor((val[i]-offset[0])/scale[0]);
      x[0]=1-t;
      x[1]=t;
      //dx[0]=-1;
      //dx[1]=1;
      t=floor((val[i]-offset[0])/scale[0]);
      int px[2]={(int) max<double>(min<double>(t,dim_img[0]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[0]-1)};

      t=(val[i+N]-offset[1])/scale[1]-floor((val[i+N]-offset[1])/scale[1]);

      y[0]=1-t;
      y[1]=t;
      //dy[0]=-1;
      //dy[1]=1;
      
      t=floor((val[i+N]-offset[1])/scale[1]);
      int py[2]={(int) max<double>(min<double>(t,dim_img[1]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[1]-1)};

      t=(val[i+2*N]-offset[2])/scale[2]-floor((val[i+2*N]-offset[2])/scale[2]);

      z[0]=1-t;
      z[1]=t;
      //dz[0]=-1;
      //dz[1]=1;
      
      t=floor((val[i+2*N]-offset[2])/scale[2]);

      int pz[2]={(int) max<double>(min<double>(t,dim_img[2]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[2]-1)};
      idx_idx=i*8;
      int index=0;
      int add=0;
      int idx;
      double dfdp;

      for(int j=0;j<2;j++)
      {
        for(int k=0;k<2;k++)
        {
          for(int l=0;l<2;l++)
          {
            idx=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
            dfdp=x[l]*y[k]*z[j];
            for(int m=0;m<dims[1];m++)
            {
              double dd=data[idx+dim_img[0]*dim_img[1]*dim_img[2]*m];
              tpts[m]+=dfdp*dd;
            }
            idx_idx++;
          }
        }
      }
// 
//       tidx[0]==px[0]? add++ : add;
//       tidx[1]==py[0]? add++ : add;
//       tidx[2]==pz[0]? add++ : add;
//       cnt[i]+=(8-(double)pow(2,add));
//       for(int j=0;j<2;j++)
//       {
//         for(int k=0;k<2;k++)
//         {
//           for(int l=0;l<2;l++)
//           {
//             
//             idx_x[cnt[i]]=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
//             int ii=0;
//             while (ii<cnt[i])
//             {
//               if(idx_x[ii]==idx_x[cnt[i]]){
// 
//               break;
//               }
//               
//               ii++;
//             }
//             
//             ii==cnt[i]? cnt[i]++ : 0 ;
//           }
//         }
//       }
      for(int t_steps=0;t_steps<(int)steps[0];t_steps++)
    {
      double tmpts[3]={val[i]+tpts[0],val[i+N]+tpts[1],val[i+2*N]+tpts[2]};
      dpts[0]=tpts[0];
      dpts[1]=tpts[1];
      dpts[2]=tpts[2];
      for(int o=0;o<(int)iter[0];o++)
      {
  //       mexPrintf("%d %f %f %f %f %f %f %f %f %f \n",o,	dpts[0],	dpts[1],	dpts[2], tpts[0], tpts[1], tpts[2],tmpts[0],tmpts[1],tmpts[2]);
	
        double t=((tmpts[0]-offset[0])/scale[0])-floor((tmpts[0]-offset[0])/scale[0]);
        x[0]=1-t;
        x[1]=t;
        t=floor((tmpts[0]-offset[0])/scale[0]);
        px[0]=(int) max<double>(min<double>(t,dim_img[0]-1),0);
        px[1]=(int) min<double>(max<double>(t+1,0),dim_img[0]-1);

        t=(tmpts[1]-offset[1])/scale[1]-floor((tmpts[1]-offset[1])/scale[1]);

        y[0]=1-t;
        y[1]=t;
        t=floor((tmpts[1]-offset[1])/scale[1]);
        py[0]=(int) max<double>(min<double>(t,dim_img[1]-1),0);
        py[1]=(int) min<double>(max<double>(t+1,0),dim_img[1]-1);

        t=(tmpts[2]-offset[2])/scale[2]-floor((tmpts[2]-offset[2])/scale[2]);

        z[0]=1-t;
        z[1]=t;
        t=floor((tmpts[2]-offset[2])/scale[2]);

        pz[0]=(int) max<double>(min<double>(t,dim_img[2]-1),0);
        pz[1]=(int)min<double>(max<double>(t+1,0),dim_img[2]-1);

        idx_idx=i*8;
        int index=0;
        tpts[0]=0;
        tpts[1]=0;
        tpts[2]=0;
        for(int j=0;j<2;j++)
        {
          for(int k=0;k<2;k++)
          {
            for(int l=0;l<2;l++)
            {
              idx=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
              dfdp=x[l]*y[k]*z[j];
              for(int m=0;m<dims[1];m++)
              {
                double dd=data[idx+dim_img[0]*dim_img[1]*dim_img[2]*m];
                tpts[m]+=dfdp*dd;
              }
              idx_idx++;
            }
          }
        } 
        for(int n=0;n<dims[1];n++)
      {
        tmpts[n]=val[i+n*N]+0.5*(dpts[n]+tpts[n]);
      }
 
      }
//  for(int j=0;j<2;j++)
//       {
//         for(int k=0;k<2;k++)
//         {
//           for(int l=0;l<2;l++)
//           {
//             
//             idx_x[cnt[i]]=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
//             int ii=0;
//             while (ii<cnt[i])
//             {
//               if(idx_x[ii]==idx_x[cnt[i]]){
// 
//               break;
//               }
//               
//               ii++;
//             }
//             
//             ii==cnt[i]? cnt[i]++ : 0 ;
//           }
//         }
//       }

      for(int n=0;n<dims[1];n++)
      {
        val[i+n*N]+=0.5*(dpts[n]+tpts[n]);
          
      }
 //mexPrintf("%d %f %f %f \n",i,val[i] ,val[i+N], val[i+2*N]);
    }
  }
};