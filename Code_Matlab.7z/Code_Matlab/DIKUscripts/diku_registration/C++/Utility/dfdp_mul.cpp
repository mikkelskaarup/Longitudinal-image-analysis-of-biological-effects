
//

#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <cstring>


// #include "tbb/task_scheduler_init.h"
// #include "tbb/parallel_for.h"
// #include "tbb/blocked_range.h"
// #include "tbb/spin_mutex.h"
// using namespace tbb;
// typedef spin_mutex MyMutexType;
// MyMutexType MyMutex;
// class interp
// {
// private:
//     //	mwSize* dims;
//     double* d ;
//     double* dfdp ;
//     double*	dDdP;
//     int* idx ;
//     int N;
//     int Np;
//     
//     
//     
// public:
//     interp(double* vdata,double* vdfdp,double* vdf,int* vidx) {
//         d=vdata;
//         dfdp=vdfdp;
//         df=vdf;
//         idx=vidx;
//         
//         
//     }
//     
//     void run(int start, int end)
//     {
//         
//         
//         int s=64;
//         for(int i=start;i<end;i++)
//         {
//             for(int j=0;j!=s;j++)
//             {
//                 
//                 
//                 
//                 df[idx[i*s+j]]+=dfdp[i*s+j]*data[idx[i*s+j]];
//                 
//                 
//                 
//             }
//         }
//     }
// };




void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
        const mxArray *prhs[])
{
    
    //bool doDerivative = false;
    //if(nlhs>1)
    //    doDerivative = true;
    //mexPrintf("Spline interpolation takes 4 arguments ");
    double* Idata = (double*)(mxGetPr(prhs[0]));
    double* Rdata = (double*)(mxGetPr(prhs[1]));
    double* dfdp =(double*)(mxGetPr(prhs[2]));
    int* idx = (int*)(mxGetPr(prhs[3]));
    
    const mwSize* dim_d =mxGetDimensions(prhs[0]);
    
    mwSize N=dim_d[0];
    // make local copy of data
    //
//         mexPrintf("%d ",N);
//     double* ldata=new double[N];
//     double* ldfdp=new double[N*64];
//     int* lidx=new int[N*64];
    double* ldf=new double[N];
//     memcpy(ldata,Idata,sizeof(double)*N);
//     memcpy(ldfdp,dfdp,sizeof(double)*N*64);
//     memcpy(lidx,idx,sizeof(int)*N*64);
//     
    //mexPrintf("so far so good\n");
    
    for(int i=0;i<N;i++)ldf[i]=0;
    int s=64;
    for(int i=0;i<N;i++)
    {
        for(int j=0;j<s;j++)
        {
            
            
            
            ldf[idx[i*s+j]]+=dfdp[i*s+j]*(Rdata[idx[i*s+j]]-Idata[idx[i*s+j]]);
            //mexPrintf("%f ",ldf[(int)idx[i*s+j]]);
            
            
        }
        //mexPrintf("%f %f %f \n",ldf[(int)idx[i*s]],idx[i],Idata[i]);
    }
    plhs[0] = mxCreateNumericArray(2,dim_d,mxDOUBLE_CLASS, mxREAL);
    double* df = static_cast<double*>(mxGetPr(plhs[0]));
    memcpy(df,ldf,sizeof(double)*N);
//     delete[] lidx;
//     delete[] ldata;
//     delete[] ldfdp;
    delete[] ldf;
    return;
    
    
    
    
};
/*class DfDp{
 *
 * public:
 * Dfdp();
 *
 * void dfdp(double* dDdP, double* ldfdp, int* lidx, double* ld,int numberOfParams, int numberOfPoints int paramDim );
 * for(int i=0;i<3*Np;i++)dDdP[i]=0;
 * int j;
 * //mexPrintf("initialized!!\n");
 * for(int i=0;i<numberOfPoints*paramDim;i++)
 * {
 * j=i>>6;
 * ldDdP[(int)lidx[i]]+=ldfdp[i]*ld[j];
 * ldDdP[(int)lidx[i]+numberOfParams]+=ldfdp[i]*ld[j+numberOfPoints];
 * ldDdP[(int)lidx[i]+2*numberOfParams]+=ldfdp[i]*ld[j+2*numberOfPoints];
 *
 *
 * }
 *
 * }*/
