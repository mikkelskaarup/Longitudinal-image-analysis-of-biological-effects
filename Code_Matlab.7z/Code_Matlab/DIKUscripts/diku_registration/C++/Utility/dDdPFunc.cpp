
//

#include <math.h>
#include <matrix.h>
#include <mex.h>



#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/spin_mutex.h"
using namespace tbb;
typedef spin_mutex MyMutexType;
MyMutexType MyMutex;
class interp
{
private:
	//	mwSize* dims;
	double* d ;
	double* dfdp ;
	double*	dDdP;
    int* idx ;
	int N;
    int Np;
	
	

public:
	interp(double* vd,double* vdfdp,double* vdDdP,int* vidx, int vN, int vNp) {
			d=vd;
			dfdp=vdfdp;
			dDdP=vdDdP;
			idx=vidx;
			N=vN;
            Np=vNp;
		

	}

	void operator()(const blocked_range<int> & r) const
	{

        double* pdDdp=new double[(int)3*Np];
			
		int s=64;
		for(int i=0;i<3*Np;i++)pdDdp[i]=0;
		int j;
		//mexPrintf("initialized!!");
		for(int i=r.begin();i!=r.end();i++)
		{
            j=i>>6;
            
            
                pdDdp[idx[i]]+=dfdp[i]*d[j];
                pdDdp[idx[i]+Np]+=dfdp[i]*d[j+N];
                pdDdp[idx[i]+2*Np]+=dfdp[i]*d[j+2*N];
            
            

        }
        {
            MyMutexType::scoped_lock lock(MyMutex);
            for(int j=0;j<3*Np;j++){
                dDdP[j]=dDdP[j]+pdDdp[j];

            }
        }
        delete pdDdp;
    }
};




	void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
		const mxArray *prhs[])
	{

		//bool doDerivative = false;
		//if(nlhs>1)
		//    doDerivative = true;
		//mexPrintf("Spline interpolation takes 4 arguments ");
		double* d = (double*)(mxGetPr(prhs[0]));
		double* dfdp =(double*)(mxGetPr(prhs[1]));
		double* idx = (double*)(mxGetPr(prhs[2]));
		double* dim_p = (double*)(mxGetPr(prhs[3]));
		
		const mwSize* dim_d =mxGetDimensions(prhs[0]);
		
		mwSize N=dim_d[0];
        	mwSize Np=(mwSize)dim_p[0];
		mwSize dims[2];
		dims[0] = Np; dims[1] = 3;
		// make local copy of data
		//
		double* ld=new double[N*dim_d[1]];
		double* ldfdp=new double[N*64];
		double* lidx=new double[N*64];
		double* ldDdP=new double[Np*3];
		memcpy(ld,d,sizeof(double)*N*dim_d[1]);
		memcpy(ldfdp,dfdp,sizeof(double)*N*64);
		memcpy(lidx,idx,sizeof(double)*N*64);
	
		//mexPrintf("%d %d %d %d\n",dims[0],dims[1],dim_d2[0],dim_d2[1]);

		for(int i=0;i<3*Np;i++)ldDdP[i]=0;
		int s=64;
		mwSize j;
		//mexPrintf("initialized!!\n");
		for(mwSize i=0;i<N*64;i++)
		{
            j=i>>6;
            
// 	if(i%100000==0)mexPrintf("%d %d %d %d %d\n",idx[i],Np,N,j,i);
//      	if(i>39200000&&i<39300000)mexPrintf("%d %d %d %d %d\n",idx[i],Np,N,j,i);
//         
// double a=dfdp[i]*d[j];
// a=dfdp[i]*d[j+N];
// a=dfdp[i]*d[j+2*N];
    
            ldDdP[(int)lidx[i]]+=ldfdp[i]*ld[j];
                ldDdP[(int)lidx[i]+Np]+=ldfdp[i]*ld[j+N];
                ldDdP[(int)lidx[i]+2*Np]+=ldfdp[i]*ld[j+2*N];
            

        }
			plhs[0] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
        		int* dim_d2 =(int*)mxGetDimensions(plhs[0]);
        	//mexPrintf("%d %d %d %d\n",dims[0],dims[1],dim_d2[0],dim_d2[1]);
			double* dDdP = (double*)(mxGetPr(plhs[0]));
			memcpy(dDdP,ldDdP,sizeof(double)*Np*3);
		delete[] lidx;
		delete[] ld;
		delete[] ldfdp;
		delete[] ldDdP;
		return;




	};
/*class DfDp{

public:
	Dfdp();

	void dfdp(double* dDdP, double* ldfdp, int* lidx, double* ld,int numberOfParams, int numberOfPoints int paramDim );
		for(int i=0;i<3*Np;i++)dDdP[i]=0;
		int j;
		//mexPrintf("initialized!!\n");
		for(int i=0;i<numberOfPoints*paramDim;i++)
		{
            		j=i>>6;    
            		ldDdP[(int)lidx[i]]+=ldfdp[i]*ld[j];
                	ldDdP[(int)lidx[i]+numberOfParams]+=ldfdp[i]*ld[j+numberOfPoints];
                	ldDdP[(int)lidx[i]+2*numberOfParams]+=ldfdp[i]*ld[j+2*numberOfPoints];
            

        	}

}*/
