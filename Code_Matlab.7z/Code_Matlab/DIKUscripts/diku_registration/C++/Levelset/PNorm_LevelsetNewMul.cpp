// SplineInterpolation.cpp : Defines the entry point for the console application.
//

#include <math.h>
#include <matrix.h>
#include <mex.h>





void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
const mxArray *prhs[])
{

  if(nrhs==0)
			mexPrintf("PNorm_leveset takes 4 arguments,image data, level set, p including lambda1 and 2, and mu");
		if(nrhs!=4)
			mexErrMsgTxt("Number of arguments must be 4");
		//mexPrintf("Spline interpolation takes 4 arguments ");

		double* dataR = mxGetPr(prhs[0]);
		double* dataI = mxGetPr(prhs[1]);
		double* p = mxGetPr(prhs[2]);
		double* mu = mxGetPr(prhs[3]);

		//double* det = static_cast<double*>(mxGetData(prhs[7]));
		
		int N =(int)mxGetNumberOfElements(prhs[0]);
//*************************Matlab start**************************
		mwSize dims[2];
		mwSize dims2[1];

		dims2[0] = 1; 
		

		
		dims[0] = N; dims[1] = 1;
		
		double* diff1 ;
		bool do_deriv=false;
		if(nlhs>3)do_deriv=true;
		plhs[0] = mxCreateNumericArray(1,dims2,mxDOUBLE_CLASS, mxREAL);
		double* val = static_cast<double*>(mxGetData(plhs[0]));
		plhs[1] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff1 = static_cast<double*>(mxGetData(plhs[1]));
      
//*****************************Matlab end*******************************
		//mexPrintf("P[0]: %f range[0]: %f range[1]: %f\n",p[0],range[0],range[1]);
  double mu0_new = 0.0, mu0_old = mu[0], 
           mu1_new = 0.0, mu1_old = mu[1],mu2_new = 0.0, mu2_old = abs(mu[1]-mu[0])/2, tmp0, tmp1, tmp2 ;
            
        
  
  for(int j=0;j<(int)p[1];j++){
        int n0  = 0, n1  = 0,n2=0;
        mu0_new = 0.0; 
           mu1_new = 0.0; mu2_new = 0.0;
        mexPrintf("P[0]: %f mu2: %f mu1: %f mu0: %f\n",p[0],mu2_old,mu1_old,mu0_old);
        for(int i=0;i<N;i++){
            
                double data_i = dataI[i];
                tmp0 = pow( abs(data_i-mu0_old), p[0] );
                tmp1 = pow( abs(data_i-mu1_old), p[0] );
                tmp2 = pow( abs(data_i-mu2_old), p[0] );

                if( tmp0 < tmp1+p[2] ) {
                    //update mu0, n0
                    if(tmp0<tmp2){
                    mu0_new += data_i;
                    n0 ++;
                    diff1[i] =0;
                    }
                    else{
                    mu2_new += data_i;
                    n2 ++;
                    diff1[i] =2;
                    }
                } else                 {
                     if(tmp1<tmp2){
                         mu1_new += data_i;
                        n1 ++;
                        diff1[i] =1;
                     } 
                     else{
                    mu2_new += data_i;
                    n2 ++;
                    diff1[i] =2;
                    }
                }
                //diff1[i] = ( tmp0 < tmp1+p[2] ) ? 0.0 : 1.0;

                }
          // move mu_new into mu_old
        mu0_old = mu0_new / n0;
        mu1_old = mu1_new / n1;    
        mu2_old = mu2_new / n2;
        }
};
        
