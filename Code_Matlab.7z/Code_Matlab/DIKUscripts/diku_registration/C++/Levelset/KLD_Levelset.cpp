// SplineInterpolation.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <math.h>
#include <matrix.h>
#include <mex.h>
#include "Kroenecker.h"




void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
const mxArray *prhs[])
{

  if(nrhs==0)
			mexPrintf("PNorm takes 6 arguments,pts,ref_data, Image, range, nobins, offset, scale (optional) ");
		if(nrhs<4)
			mexErrMsgTxt("Number of arguments must be 4");
		//mexPrintf("Spline interpolation takes 4 arguments ");
		//double* pts = static_cast<double*>(mxGetData(prhs[0]));
		double* dataR = static_cast<double*>(mxGetData(prhs[0]));
		double* val = static_cast<double*>(mxGetData(prhs[1]));
		double* range = static_cast<double*>(mxGetData(prhs[2]));
		double* no_bins = static_cast<double*>(mxGetData(prhs[3]));
		
		
		//double* det = static_cast<double*>(mxGetData(prhs[7]));
		
		//int ndim =(int)mxGetNumberOfDimensions(prhs[2]);
		int* dim_val=(int*)mxGetDimensions(prhs[0]);
//int N=100;        
int N=dim_val[0];
		//Allocate Tc
 
		mwSize dims[2];
		mwSize dims2[1];

		dims2[0] = 1; 
		

		
		dims[0] = N; dims[1] = 1;
		
		double* diff1 ;
	
	
		plhs[0] = mxCreateNumericArray(1,dims2,mxDOUBLE_CLASS, mxREAL);
		double* vall = static_cast<double*>(mxGetData(plhs[0]));
		plhs[1] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff1 = static_cast<double*>(mxGetData(plhs[1]));
      
		//mexPrintf("P[0]: %d range[0]: %f range[1]: %f\n",N,range[0],range[1]);
        //getchar();
        double* hist=new double[256];
        double* hist1=new double[256];
        double* hist2=new double[256];
          double* log_hist=new double[256];
          double* log_hist1=new double[256];
        double* log_hist2=new double[256];
        for(int i=0;i<256;i++){
        hist1[i]=1e-3;
        hist2[i]=1e-3;
        log_hist1[i]=0;
        log_hist2[i]=0;
        }
        double sum1=0;
        double sum2=0;
        

        
	for(int i=0;i<N;i++){
		//val[i]=0;
		//mexPrintf("%d \n",i);
		diff1[i]=0;
// 		diff2[i]=0;
// 		diff3[i]=0;
 		
        int idxR=(int)floor((dataR[i]));	
		double	t=(dataR[i])-floor(dataR[i]);
		double	t2=t*t;
		double	t3=t2*t;

			double tr_val[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
            double  dt_val[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
		
		double lval=val[i];
			double tmp;
			double dNMIdW=0;			
			int i_val=(int)floor(lval);
								for (int nn=0;nn<4;nn++){
                //mexPrintf("abs(lval-range[0]): %f lval: %f nn: %d idxR: %d ",abs(lval-range[0]),lval,nn,idxR);
                                    if((idxR+nn-1)>0){
									tmp=tr_val[nn]/(6);
									hist1[i_val]+=tmp;
                                    sum1+=tmp;
		                            }
                                    else
                                    {
                                     tmp=tr_val[nn]/(6);
									hist2[i_val]+=tmp;
                                    sum2+=tmp;
		          //                  mexPrintf("tmp: %f ELSE \n",tmp);
                                    }
								}
						
			}
    int cnt1=0;
    int cnt2=0;
    int* idx1=new int[256];
    int* idx2=new int[256];
    double sum_1=0;;
    double sum_2=0;;
    vall[0]=0;
    sum1=0;
    sum2=0;
          for(int i=0;i<256;i++){
           	sum1+=hist1[i];				
                sum2+=hist2[i];				
           
          }
          for(int i=0;i<256;i++){
                hist[i]=hist1[i]+hist2[i];
                hist1[i]=hist1[i]/sum1;
                hist2[i]=hist2[i]/sum2;
                if(hist[i]>0)
                log_hist[i]=log(hist[i]);
                else
                log_hist[i]=0;
                 if(hist1[i]>0){
                log_hist1[i]=log(hist1[i]);
                idx1[cnt1]=i;
                cnt1++;}
                 else
                log_hist1[i]=0;
                if(hist2[i]>0){
                log_hist2[i]=log(hist2[i]);
                idx2[cnt2]=i;
                cnt2++;}
                else
                log_hist2[i]=0;
                vall[0]+=log(hist1[i]/hist2[i])*hist1[i];
                //vall[0]+=-hist2[i]*log_hist2[i];
				sum_1+=hist1[i];				
                sum_2+=hist2[i];				
                //mexPrintf("%1.16f %1.16f %d \n",hist2[i],hist1[i],i);
        }
    //mexPrintf("sum1: %1.15f sum2: %1.15f\n",sum_1,sum_2);
    
    
    
        for(int i=0;i<N;i++){
        diff1[i]=0;
            int idxR=(int)floor((dataR[i]));	
			double t=(dataR[i])-floor(dataR[i]);
			double t2=t*t;
			double t3=t2*t;

			double tr_val[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
            double  dt_val[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
	
			
		double lval=val[i];
			double tmp=0;
			double dNMIdW=0;			
				int i_val=(int)floor(lval);
                
								for (int nn=0;nn<4;nn++){
                //mexPrintf("abs(lval-range[0]): %f lval: %f nn: %d idxR: %d ",abs(lval-range[0]),lval,nn,idxR);
                                    if((idxR+nn-1)>0){
									
									
 									dNMIdW+=(1/(sum1))*(dt_val[nn]/6)*(log(hist1[i_val]/hist2[i_val])+hist1[i_val]);   
                                    for(int kk=0;kk<cnt1;kk++){
                                                         
                                            
                                            dNMIdW+=-dt_val[nn]/(6*sum1)*(hist1[idx1[kk]])*(log(hist1[idx1[kk]]/hist2[idx1[kk]])+hist1[idx1[kk]]);                               
                                       }
//                                    // mexPrintf("tmp: %f IF \n",tmp);
                                    }
                                    else
                                    {
                              		dNMIdW+=(1/(sum2))*(dt_val[nn]/6)*(hist2[i_val]);   
                                    for(int kk=0;kk<cnt2;kk++){
                                                         
                                            
                                            dNMIdW+=-dt_val[nn]/(6*sum2)*(hist2[idx2[kk]])*(hist2[idx2[kk]]);                               
                                    }
                              
//if(i==(int)range[0]) mexPrintf("dt_val[nn]: %f n %d idxR: %d i_val %d loghist %f hist %f val %f sum2 %f data %f\n",dt_val[nn]/6,nn,idxR,i_val,log_hist2[i_val],hist2[i_val],val[i],sum2,dataR[i]);
                                    }
								}
						
			diff1[i]=dNMIdW;
			}

    delete hist2;
    delete hist1;
    delete hist;
    delete log_hist1;
    delete log_hist2;
    delete log_hist;
    
};
        
