// SplineInterpolation.cpp : Defines the entry point for the console application.
//

#include <math.h>
#include <matrix.h>
#include <mex.h>





void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
const mxArray *prhs[])
{

  if(nrhs==0)
			mexPrintf("PNorm_leveset takes 4 arguments,image data, level set, p including lambda1 and 2, and mu");
		if(nrhs!=4)
			mexErrMsgTxt("Number of arguments must be 4");
		//mexPrintf("Spline interpolation takes 4 arguments ");

		double* dataR = mxGetPr(prhs[0]);
		double* dataI = mxGetPr(prhs[1]);
		double* p = mxGetPr(prhs[2]);
		double* mu = mxGetPr(prhs[3]);

		//double* det = static_cast<double*>(mxGetData(prhs[7]));
		
		int N =(int)mxGetNumberOfElements(prhs[0]);
//*************************Matlab start**************************
		mwSize dims[2];
		mwSize dims2[1];

		dims2[0] = 1; 
		
        double shapehist[21]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		
		dims[0] = N; dims[1] = 1;
		
		double* diff1 ;
		bool do_deriv=false;
		if(nlhs>3)do_deriv=true;
		plhs[0] = mxCreateNumericArray(1,dims2,mxDOUBLE_CLASS, mxREAL);
		double* val = static_cast<double*>(mxGetData(plhs[0]));
		plhs[1] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff1 = static_cast<double*>(mxGetData(plhs[1]));
//*****************************Matlab end*******************************
		//mexPrintf("P[0]: %f range[0]: %f range[1]: %f\n",p[0],range[0],range[1]);
		double tr_val[4]={0,0,0,0};
	double dt_val[4]={0,0,0,0};
	double t,t2,t3,tmp,dNMIdW,cut;
	int idxR;
    for(int i=0;i<N;i++){
		diff1[i]=0;
        idxR=(int)floor((dataR[i]));	
		t=(dataR[i])-floor(dataR[i]);
		t2=t*t;
		t3=t2*t;
		tr_val[0]=-t3+3*t2-3*t+1;
		tr_val[1]=3*t3-6*t2+4;
		tr_val[2]-3*t3+3*t2+3*t+1;
		tr_val[3]=t3;
        			for (int nn=0;nn<4;nn++){
									if(abs(idxR+nn-1)<11)
                                        shapehist[idxR+nn+10]+=tr_val[nn]/6;
                        
                                    }
                    }
                                            
    }
	for(int i=0;i<N;i++){
	   idxR=(int)floor((dataR[i]));	
		t=(dataR[i])-floor(dataR[i]);
		t2=t*t;
		t3=t2*t;
		tr_val[0]=-t3+3*t2-3*t+1;
		tr_val[1]=3*t3-6*t2+4;
		tr_val[2]-3*t3+3*t2+3*t+1;
		tr_val[3]=t3;
        dt_val[0]=-3*t2+6*t-3;
		dt_val[1]=9*t2-12*t;
		dt_val[2]=-9*t2+6*t+3;
		dt_val[3]=3*t2;
		dNMIdW=0;			
	
								for (int nn=0;nn<4;nn++){
									if(idxR+nn-1==0)
										//Length of 0th leveset
										val[0]+=p[1]*tr_val[nn]/6;
										dNMIdW+=p[1]*dt_val[nn]/6;
                                    if((idxR+nn-1)>0){
									cut=!(abs(dataI[i]-mu[0])>abs(p[3]-mu[0]))?abs(dataI[i]-mu[0]):abs(p[3]-mu[0]);
                                            tmp=pow(cut,p[0])/(6)*tr_val[nn];
									val[0]+=tmp;
									dNMIdW+=dt_val[nn]*pow(cut,p[0])/(6);
                        
                                    }
                                    else
                                    {
                                            cut=!(abs(dataI[i]-mu[1])>abs(p[3]-mu[1]))?abs(dataI[i]-mu[1]):abs(p[3]-mu[1]);
                                     tmp=pow(cut,p[0])/(6)*tr_val[nn];
									val[0]+=tmp;
									dNMIdW+=dt_val[nn]*pow(cut,p[0])/(6);   
									//Area of inside                
									val[0]+=p[2]*tr_val[nn]/6;
									dNMIdW+=p[2]*dt_val[nn]/6;
                           
                                    }
								}
        
        
            
			diff1[i]=dNMIdW;
			}
};
        
