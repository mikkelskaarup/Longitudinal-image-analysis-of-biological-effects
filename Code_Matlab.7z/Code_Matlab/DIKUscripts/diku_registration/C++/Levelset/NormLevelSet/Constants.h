#ifndef CONSTANTS
#define CONSTANTS


// CONSTANTS
//const ULONG N = 1024*1024*16;
//const ULONG N = 1024*1024*16;
#define N 16777216
#define NUM_THREADS 262144 //131072

#define GPU_EXEC    1

#define WITH_FLOATS 1

#if (WITH_FLOATS)
    typedef float        REAL;
    //typedef unsigned int ULONG;
    #define TILE 16
#else
    #pragma OPENCL EXTENSION cl_khr_fp64: enable
    typedef double         REAL;
    //typedef unsigned long  ULONG;
    #define TILE 8
#endif

typedef unsigned long  ULONG;
typedef unsigned int   UINT;



typedef struct {
    REAL mu0;
    REAL mu1;
    REAL p0;
    REAL p1;
    REAL p2;
} Vect5 __attribute__ ((aligned (16)));



#define logWORKGROUP_SIZE 8
#define WORKGROUP_SIZE  256


// TYPEDEFS


#endif // include CONSTANTS
