//#include "Constants.h"
//#include "SeqC_stub.h"
//#include "GPGPU_stub.h"

#include <cmath>
#include <stdio.h>

#include <time.h>
#include <sys/timeb.h>

using namespace std;

#include "Constants.h"
#include "CPUstub.h"
#include "GPUstub.h"


void initData(REAL* dataI, REAL* dataR, Vect5& mup) {
    mup.mu0 = 0.1;
    mup.mu1 = 0.2;
    mup.p0  = 0.15;
    mup.p1  = 0.30;
    mup.p2  = 0.45;
 
    for(unsigned long long i=0; i<N; i++) {
        dataI[i] = (1.0 / (i+1)) - (i % 5);
        dataR[i] = (1.0 / (i+1)) + (i % 5);
    }
} 

void testRes(REAL* diff, REAL* val) {
    REAL res = 0.0;

    for(unsigned long long i=0; i<N; i++) {
        res += diff[i] / N;
    }

    printf("Averaged result: %f, diff[0]: %f, diff[n/32+3]: %f diff[n-1]: %f, RED_VAL: %f \n", 
            res, diff[0], diff[N/32+3], diff[N-1], val[0]);
}


int main() {

    REAL* dataI = new REAL[N];
    REAL* dataR = new REAL[N];
    REAL* diff1 = new REAL[N];

    Vect5 mup;
    REAL val   [4];

    initData(dataI, dataR, mup);

#if GPU_EXEC == 0
    seq_kernel(dataI, dataR, diff1, mup, &val[0]);
#else
    gpu_kernel(dataI, dataR, diff1, mup, &val[0]);
#endif

    testRes(diff1, &val[0]);

    delete[] dataI;
    delete[] dataR;
    delete[] diff1;
    
}

    
