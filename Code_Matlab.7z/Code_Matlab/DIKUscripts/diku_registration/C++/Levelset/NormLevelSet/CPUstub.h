#include <assert.h>
// TIMING
typedef struct timeb mlfi_timeb;
#define mlfi_ftime ftime

#define mlfi_diff_time(t1,t2) \
  (t1.time - t2.time) * 1000 + (t1.millitm - t2.millitm)

#define WITH_DEBUG_PRINTOUTS



void seq_kernel (
            REAL* dataI, REAL* dataR,  REAL* diff1, 
            Vect5& mup,  REAL* val
) {
    double t,t2,t3,tmp,dNMIdW;
    int idxR;

    REAL tr_val[4];
    REAL dt_val[4];


    mlfi_timeb  t_start, t_end;
    unsigned long int elapsed;
    mlfi_ftime(&t_start);

#if 1
    for(unsigned long long i=0; i<N; i++) {  // PARALLEL
        diff1[i]=0.0;

        idxR = (int)floor(dataR[i]);	

		t    =  dataR[i] - floor(dataR[i]);
		t2   = t  * t;
		t3   = t2 * t;

        tr_val[0] = -t3   + 3*t2 - 3*t + 1; 
        tr_val[1] = 3*t3  - 6*t2 + 4;
        tr_val[2] = -3*t3 + 3*t2 + 3*t + 1;
        tr_val[3] = t3;

        dt_val[0] = -3*t2 + 6*t - 3;
        dt_val[1] =  9*t2 - 12*t;
        dt_val[2] = -9*t2 + 6*t + 3;
        dt_val[3] = 3*t2;

        dNMIdW = 0.0;			
			
        for (int nn=0;nn<4;nn++){
            if(idxR+nn-1==0) 
            {
    			// Length of 0th leveset
                val[0] += mup.p1*tr_val[nn]/6;
				dNMIdW += mup.p1*dt_val[nn]/6; // should this be inside if or outside?
            }

            bool condleq0 = (idxR + nn - 1) <= 0;
            REAL muxy = (condleq0) ? mup.mu1 : mup.mu0;

            tmp = pow( fabs(dataI[i]-muxy), mup.p0 ) / 6;
            //tmp=pow(fabs(dataI[i]-muxy), mup.p0) / (6) * tr_val[nn];
            val[0] += tmp * tr_val[nn];
            dNMIdW += tmp * dt_val[nn];

            if( condleq0 )
            {
                //Area of inside                
                val[0]+=mup.p2*tr_val[nn]/6;
                dNMIdW+=mup.p2*dt_val[nn]/6;
            }
        }

        diff1[i]=dNMIdW;
    } // end DOALL

#else

    for(unsigned long long i=0; i<N; i++) {  // PARALLEL

        REAL curDataI, curDataR, tr_val, dt_val;
        REAL t, t2, t3, tmp, dNMIdW;
        int  idxR;

        curDataR = dataR[i];

        idxR = (int)floor(curDataR);	
		t    =  curDataR - floor(curDataR);
		t2   = t  * t;
		t3   = t2 * t;


        curDataI = dataI[i];
        dNMIdW = 0.0;			
			
        for (int nn=0;nn<4;nn++){
            if     (nn==0) { tr_val = -t3   + 3*t2 - 3*t + 1; dt_val = -3*t2 + 6*t - 3; }
            else if(nn==1) { tr_val = 3*t3  - 6*t2 + 4;       dt_val =  9*t2 - 12*t;    }
            else if(nn==2) { tr_val = -3*t3 + 3*t2 + 3*t + 1; dt_val = -9*t2 + 6*t + 3; }
            else /*nn==3*/ { tr_val = t3;                     dt_val = 3*t2;            }
           

            if(idxR+nn-1==0) {
    			// Length of 0th leveset
                val[0] += mup.p1*tr_val/6;
				dNMIdW += mup.p1*dt_val/6; // should this be inside if or outside?
            }

            bool condleq0 = (idxR + nn - 1) <= 0;
            REAL muxy = (condleq0) ? mup.mu1 : mup.mu0;

            tmp = pow(fabs(curDataI-muxy), mup.p0) / 6;
            //tmp=pow(fabs(dataI[i]-muxy), mup->p0) / (6) * tr_val[nn];
            val[0] += tmp * tr_val;
            dNMIdW += tmp * dt_val;

            if( condleq0 ){
                //Area of inside                
                val[0] += mup.p2*tr_val/6;
                dNMIdW += mup.p2*dt_val/6;
            }
        }

        diff1[i] = dNMIdW;

    }

#endif

    


    mlfi_ftime(&t_end);
    elapsed = mlfi_diff_time(t_end,t_start);
    printf("\n\nCPU Sequential Run Time: %lu !\n\n", elapsed);

}

