#include "SDK_stub.h"


struct oclImageData {
    /* RO scalars */
    cl_mem  mup;  // [5]

    /* RO arrays */
    cl_mem dataI;  // [N]
    cl_mem dataR;  // [N] 

    /* OUTPUT array (WO) */
    cl_mem diff;   // [N]
    cl_mem redv;   // [NUM_THREADS]
    cl_mem vs;     // [NUM_THREADS/(WORKGROUP_SIZE*8)]
};

void makeOclBuffers (
        cl_context          cxGPUContext,
        cl_command_queue&   cqCommandQueue,
        REAL*               dataI,
        REAL*               dataR,
        REAL*               diff,
        Vect5&              mup,
        oclImageData&       ocl_arrs            
) {
    cl_int ciErr;
    cl_int ciErr2;
    unsigned long int cur_size;

    /*********************/
    /*** 1. RO scalars ***/
    /*********************/
    {
        cur_size = sizeof(Vect5);
        ocl_arrs.mup = clCreateBuffer(
                    cxGPUContext, CL_MEM_READ_ONLY, cur_size, NULL, &ciErr2
                );

        ciErr = ciErr2;
        ciErr |= clEnqueueWriteBuffer(cqCommandQueue, ocl_arrs.mup, CL_TRUE, 0,
                                      cur_size, &mup, 0, NULL, NULL);
        oclCheckError(ciErr, CL_SUCCESS);
    }

    /****************************/
    /*** 1. RO and WO Arrays! ***/
    /****************************/
    {
        cur_size = N*sizeof(REAL);

        ocl_arrs.dataI = clCreateBuffer(cxGPUContext, CL_MEM_READ_ONLY, cur_size, NULL, &ciErr2); ciErr = ciErr2;
        ciErr |= clEnqueueWriteBuffer(cqCommandQueue, ocl_arrs.dataI, CL_TRUE, 0, cur_size, dataI, 0, NULL, NULL);
//        CREATE_AND_ENQUEUE_RO_CL_BUFFER(dataI);

        ocl_arrs.dataR = clCreateBuffer(cxGPUContext, CL_MEM_READ_ONLY, cur_size, NULL, &ciErr2); ciErr = ciErr2;
        ciErr |= clEnqueueWriteBuffer(cqCommandQueue, ocl_arrs.dataR, CL_TRUE, 0, cur_size, dataR, 0, NULL, NULL);
//        CREATE_AND_ENQUEUE_RO_CL_BUFFER(dataR);

        CREATE_AND_ENQUEUE_WO_CL_BUFFER(diff);

        cur_size = NUM_THREADS*sizeof(REAL);
        CREATE_AND_ENQUEUE_GPU_ONLY_CL_BUFFER(redv); // the to-be-reduced `v'

        cur_size = (NUM_THREADS / (WORKGROUP_SIZE * 8)) * sizeof(REAL);
        //CREATE_AND_ENQUEUE_GPU_ONLY_CL_BUFFER(vs);
        CREATE_AND_ENQUEUE_WO_CL_BUFFER(vs);
    }

    oclCheckError(ciErr, CL_SUCCESS);

    //shrLog("Before EXITING ALLOC ARRAYS!!! ...\n");
}

void make_kernels (
        cl_command_queue&   cqCommandQueue,
        cl_program          cpProgram,
        oclImageData&       ocl_arrs,
        const unsigned int& CHUNK,
        const unsigned int& REDSZ,
        cl_kernel&          kernel,
        cl_kernel&          red_kernel
) {
    //cl_kernel kernel  = NULL; // OpenCL kernel
    UINT      counter = 0; 
    cl_int    ciErr1, ciErr2;

    { // main kernel
        counter = 0; 
        kernel = clCreateKernel(cpProgram, "run_imageproc", &ciErr1);
        oclCheckError(ciErr1, CL_SUCCESS);

        ciErr1 |= clSetKernelArg( kernel, counter++, sizeof(cl_mem), (void*)&ocl_arrs.mup   ); // RO -- in constant memory
        ciErr1 |= clSetKernelArg( kernel, counter++, sizeof(cl_mem), (void*)&ocl_arrs.dataI ); // RO -- in global   memory
        ciErr1 |= clSetKernelArg( kernel, counter++, sizeof(cl_mem), (void*)&ocl_arrs.dataR ); // RO -- in global   memory
        ciErr1 |= clSetKernelArg( kernel, counter++, sizeof(cl_mem), (void*)&ocl_arrs.diff  ); // WO -- in global   memory
        ciErr1 |= clSetKernelArg( kernel, counter++, sizeof(cl_mem), (void*)&ocl_arrs.redv  ); // WO -- in global   memory
        ciErr1 |= clSetKernelArg( kernel, counter++, sizeof(cl_int), (void*)&CHUNK          ); // RO -- chunk factor
        oclCheckError(ciErr1, CL_SUCCESS);

        //ciErr1 |= clSetKernelArg(ckTridagMatMultX, counter++, sizeof(uint), (void *)NUM_P);
        //const int PRIV_MULT = sizeof(REAL) * 8 * WORKGROUP_SIZE;
        //ciErr1 |= clSetKernelArg(kernel, counter++, PRIV_MULT, NULL); // shared memory for caching!
    }

    

    { // reduce kernel
        counter = 0; 
        red_kernel = clCreateKernel(cpProgram, "reduceQuad", &ciErr1);

        ciErr1 |= clSetKernelArg( red_kernel, counter++, sizeof(cl_mem), (void*)&ocl_arrs.redv );
        ciErr1 |= clSetKernelArg( red_kernel, counter++, sizeof(cl_mem), (void*)&ocl_arrs.vs   );
        ciErr1 |= clSetKernelArg( red_kernel, counter++, sizeof(cl_int), (void*)&REDSZ        );

        const int PRIV_MULT = sizeof(REAL) * WORKGROUP_SIZE;
        ciErr1 |= clSetKernelArg( red_kernel, counter++, PRIV_MULT, NULL);

        oclCheckError(ciErr1, CL_SUCCESS);
    }

}


void release_all_kernels ( cl_kernel& kernel ) {
    clReleaseKernel(kernel);
}

void release_all_GPU_resources(
        cl_command_queue&   cqCommandQueue,
        cl_context&         cxGPUContext,
        cl_program          cpProgram,
        cl_device_id*       cdDevices,
        oclImageData&       ocl_arrs,
        cl_kernel&          kernel,
        cl_kernel&          red_kernel
) {

    shrLog("Release Kernels...\n");
    clReleaseKernel(kernel    );
    clReleaseKernel(red_kernel);

    shrLog("Release CPU buffers and OpenCL objects...\n");
    clReleaseProgram(cpProgram);

    clReleaseMemObject(ocl_arrs.dataI);
    clReleaseMemObject(ocl_arrs.dataR);
    clReleaseMemObject(ocl_arrs.diff );
    clReleaseMemObject(ocl_arrs.redv );
    clReleaseMemObject(ocl_arrs.vs   );

    clReleaseCommandQueue(cqCommandQueue);
    free(cdDevices);
    clReleaseContext(cxGPUContext);
}



void gpu_kernel (
            REAL*  dataI,   // global RO
            REAL*  dataR,   // global RO
            REAL*  diff1,   // global WO
            Vect5& mup,     // RO, constant memory
            REAL*  val      // RW -> reduction
) {
    cl_context       cxGPUContext;                  // OpenCL context
    cl_command_queue cqCommandQueue[16];            // OpenCL command que
    cl_uint nDevice;                                // OpenCL device count
    cl_device_id*    cdDevices;                     // OpenCL device list
    cl_program       cpProgram;                     // OpenCL program
    cl_kernel        kernel;                        // OpenCL-main   kernel
    cl_kernel        red_kernel;                    // OpenCL-reduce kernel
    unsigned int     dev_id = 0;

    oclImageData     ocl_arrs;

    const unsigned int CHUNK = N / NUM_THREADS;
    const unsigned int REDSZ = NUM_THREADS / 4;


    { // check sanity conditions!
        bool valid_input = ((N % NUM_THREADS) == 0);
        valid_input = valid_input && ( (NUM_THREADS % (WORKGROUP_SIZE * 8)) == 0);

        assert(valid_input && "UNDEFINED cSourcePath");
    }

    // making command queue, building program, etc
    build_for_GPU(
            cxGPUContext, cqCommandQueue,
            nDevice, cdDevices, cpProgram, dev_id, "ImageProc"
        );

    // allocate space for the RO and RW arrays on GPU!
    makeOclBuffers (
            cxGPUContext, cqCommandQueue[dev_id], dataI, dataR, diff1, mup, ocl_arrs
        );

    // make all kernels!
    make_kernels( cqCommandQueue[dev_id], cpProgram, ocl_arrs, CHUNK, REDSZ, kernel, red_kernel );

    mlfi_timeb  t_start, t_end;
    unsigned long int elapsed;
    mlfi_ftime(&t_start);


    { // run main kernel!
        cl_int ciErr1;
        size_t  globalWorkSize = NUM_THREADS; //N;
        size_t  localWorkSize  = WORKGROUP_SIZE;

        mlfi_timeb  t_start, t_end;
        unsigned long int elapsed;
        mlfi_ftime(&t_start);


        ciErr1 = clEnqueueNDRangeKernel(  cqCommandQueue[dev_id], kernel, 1, NULL,
                                      &globalWorkSize, &localWorkSize, 0, NULL, NULL   );

        ciErr1 |= clFinish(cqCommandQueue[dev_id]);
        oclCheckError(ciErr1, CL_SUCCESS);

        mlfi_ftime(&t_end);
        elapsed = mlfi_diff_time(t_end,t_start);
        printf("\n\nGPU Run Time Main: %lu !\n\n", elapsed);

        { // copy back to CPU host
            ciErr1 |= clEnqueueReadBuffer (
                            cqCommandQueue[dev_id], ocl_arrs.diff, CL_TRUE, 0, 
                            N*sizeof(REAL), diff1, 0, NULL, NULL
                        );
            oclCheckError(ciErr1, CL_SUCCESS);
        }


#if 0
        // WITH DOUBLE IT IS OK!!!!
        { // copy back temporary reduced array
            REAL* redv = new REAL[NUM_THREADS];
            ciErr1 |= clEnqueueReadBuffer (
                            cqCommandQueue[dev_id], ocl_arrs.redv, CL_TRUE, 0, 
                            NUM_THREADS*sizeof(REAL), &redv[0], 0, NULL, NULL
                        );
            oclCheckError(ciErr1, CL_SUCCESS);

            REAL red = 0.0;
            for(unsigned int i=0; i<NUM_THREADS; i++){
                red += redv[i];
            }
            val[0] = red;
            delete[] redv;
            printf("REDUCED VALUE: %f\n\n", red);
        }

#endif

    }
#if 1
    { // run reduction kernel!
        cl_int ciErr1;
        size_t  globalWorkSize = NUM_THREADS/8; //N;
        size_t  localWorkSize  = WORKGROUP_SIZE;

        mlfi_timeb  t_start, t_end;
        unsigned long int elapsed;
        mlfi_ftime(&t_start);

        ciErr1 = clEnqueueNDRangeKernel(  cqCommandQueue[dev_id], red_kernel, 1, NULL,
                                      &globalWorkSize, &localWorkSize, 0, NULL, NULL   );

        ciErr1 |= clFinish(cqCommandQueue[dev_id]);
        oclCheckError(ciErr1, CL_SUCCESS);

        mlfi_ftime(&t_end);
        elapsed = mlfi_diff_time(t_end,t_start);
        printf("\n\nGPU Run Time REDUCE: %lu !\n\n", elapsed);

        { // copy back to CPU host
            const unsigned int REDLEN= NUM_THREADS / (WORKGROUP_SIZE * 8);
            REAL vs[REDLEN];

            ciErr1 |= clEnqueueReadBuffer (
                            cqCommandQueue[dev_id], ocl_arrs.vs, CL_TRUE, 0, 
                            REDLEN*sizeof(REAL), &vs[0], 0, NULL, NULL
                        );
            oclCheckError(ciErr1, CL_SUCCESS);

            REAL red = 0.0;
            for(unsigned int i=0; i<REDLEN; i++){
                red += vs[i];
            }
            val[0] = red;
        }
    }
#endif
    mlfi_ftime(&t_end);
    elapsed = mlfi_diff_time(t_end,t_start);
    printf("\n\nTotal GPU Run Time, i.e., Both Kernels + Copy Back: %lu !\n\n", elapsed);


    // make clean -- dealocate the GPU buffers
    release_all_GPU_resources(
            cqCommandQueue[dev_id],
            cxGPUContext,
            cpProgram,
            cdDevices,
            ocl_arrs,
            kernel,
            red_kernel
        );    
}

