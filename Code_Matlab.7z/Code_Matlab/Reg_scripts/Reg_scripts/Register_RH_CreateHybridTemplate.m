ipath = '/Users/appelt/Dropbox/Work/Projekter/DTI projekt/DTI data/DIKU-RH/';

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

%
warning off all
patients = {'2'};

for p = 1:length(patients)
    % Loop over studies
    studies = listSubFolders(fullfile(ipath,patients{p}));
    for s = 1:size(studies,1)
        
        dpath = fullfile(ipath,patients{p},studies{s});
        % load data
        load(fullfile(dpath,'brain'));
        N = length(brain);
        
        % Smallest image (in mm)
        imageSizes = S.*dims;
        [~,idxMin] = min(imageSizes(:,3));
        Smin = imageSizes(idxMin,:);
        %Smin = S(2,:).*dims(2,:);
        
        %define center of rotation (mm from corner of img1)
        center= repmat([floor(Smin(1)/2) floor(Smin(2)/2) floor(Smin(3)/2)],N,1);
        centr = zeros(3,N);
        
        boundingBox = zeros(N,6);
        
        for i = 1:N
            id=kmeans(brain(i).img(:),2);
            if id(1) == 2
                id=2-id;
            elseif id(1) == 1
                id=id-1;
            else
                error('Situation not accounted for!');
            end
            cls=reshape(id,size(brain(i).img));
            props=regionprops(cls,'Centroid','BoundingBox');
            %boundingBox(i,:) = props.BoundingBox.*repmat(dims(i,:),1,2);
            c = props.Centroid.*dims(i,:);
            centr(1,i) = c(2);
            centr(2,i) = c(1);
            centr(3,i) = c(3);
        end
        cDiff = centr-center';
        %%
        p3all = zeros(12,N);
        p3all([1 5 9],idxMin) = 1;
        offset = zeros(3);
        comp_vec = 1:N;
        comp_vec(idxMin) = [];
        % Reference scan
        i1 = idxMin;
        for c = 1:numel(comp_vec)
            i2 = comp_vec(c);
%             dimt1 = dims(i1,:);
%             dimt2 = dims(i2,:);
%             img1 = brain(i1).bimg;
%             img2 = brain(i2).bimg;
            
            dimt1 = dims(i2,:);
            dimt2 = dims(i1,:);
            img1 = brain(i2).bimg;
            img2 = brain(i1).bimg;
            
            %setting image-resolution for affine registration to 1mm
            resolution=[1 1 1]*2;
            [X11, X2, X3]=ndgrid(0:resolution(1):Smin(1)-resolution(1),0:resolution(2):Smin(2)-resolution(2),0:resolution(3):Smin(3)-resolution(3));
            pts=[X11(:) X2(:) X3(:)];
            
            pinit=zeros(12,1);
            pinit([1 5 9],:)=1;
            % Initialized with difference in center of mass
            % pinit(10:12) = cDiff(:,i2);
            % Initialize with difference in image extrema
            pinit(10) = boundingBox(i2,2) - boundingBox(i1,2);
            pinit(11) = boundingBox(i2,1) - boundingBox(i1,1);
            pinit(12) = boundingBox(i2,6) - boundingBox(i1,6);
            % Re-sample reference image
            Jtrival=(SplineInterpolation(pts,img2,[0 0 0],dimt2));
            
            %initialize parameters to 0 for affine
            p2=zeros(12,1);
            %using 1-norm
            p2(4)=pinit(10); p2(5)=pinit(11); p2(6)=pinit(12);
            center = center(1,:);
            %perform translation initialization
            p2=minFunc(@cf_rigidNMI_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
            %include rotation
            p2=minFunc(@cf_rigidNMI_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
            
            %include scale
            p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
            
            %full affine
            %change parametrization from angles to.... matrix
            
            [f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
            p3=T(:);
            p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);
            
            p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
            
            %full symmetric affine registration
            %removing translation from the transformation (to the space of I) for creating a common reference space
            offsetI=-p3(10:12);
            p3(10:12)=0;
            offset(:,comp_vec(c)) = offsetI;
            %interpolating I in the new common space
            Itrival=(SplineInterpolation(pts,img1,offsetI,dimt1));
%            p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1), offsetI);
            p3all(:,comp_vec(c)) = p3;
        end
        
        save(fullfile(dpath,'p3all'),'p3all','offset')
    end
end