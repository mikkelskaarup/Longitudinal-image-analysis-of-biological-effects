function M = getMaskFromContour(S,img)

% Assume that img is a ct image as structured in the MDACC data
% Assume that S is a single structure (not a structure set), as structured in the MDACC data
% Outputs mask of same dimensions as image

%M = zeros(size(img.vol));
M = zeros(size(img.X));

% Number of slices in structure
noSlices = S.nc;

% Create vectors of all x, y, and z positions on CT scan
xPos = [img.pos(1):img.dx(1):(img.xn(1)-0.5*img.dx(1))];
yPos = [img.pos(2):img.dx(2):(img.xn(2)-0.5*img.dx(2))];
zPos = [img.pos(3):img.dx(3):(img.xn(3)-0.5*img.dx(3))]; 

% Go through all slices in structure
for i=1:noSlices
    % Find corresponding slice on ct scan
    zi = S.zc(i); % z coordinate of structure slice
    [~,iSlice] = min(abs(zPos - zi)); % Find index of corresponding CT slice
    % ~Get x and y values for all points
    x = S.curve(i).p(:,1);
    y = S.curve(i).p(:,2);
    M(:,:,iSlice) = M(:,:,iSlice) + roipoly(yPos,xPos,img.X(:,:,iSlice),x,y);
end

% Correct for ROI in ROI
M(M==2)=0;
% Convert to logic
M = M~=0;