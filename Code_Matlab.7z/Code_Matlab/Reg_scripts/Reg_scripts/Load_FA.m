FApath = '\\tsclient\L\LovbeskyttetMapper\DTI-project\DIKU-RH\Corrected data from Sune';
patient = patients{j};

niiBaseline = load_nii(fullfile(FApath,patient,'Baseline',strcat(patient,'_Baseline_final_FA.nii')));
niiFU = load_nii(fullfile(FApath,patient,strcat('FU_',num2str(studyJ)),strcat(patient,'_FU_',num2str(studyJ),'_final_FA.nii')));

tempstruct = struct([]);
tempstruct(1).img = double(niiBaseline.img);
tempstruct(1).bimg = double(niiFU.img);

brain = [brain,tempstruct];