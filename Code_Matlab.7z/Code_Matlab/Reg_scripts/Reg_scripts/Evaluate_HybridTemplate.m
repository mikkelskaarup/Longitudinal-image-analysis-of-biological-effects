%ipath = '/Users/appelt/Dropbox/Work/Projekter/DTI projekt/DTI data/DIKU-RH/';

%patient = '5';

% Loop over studies
studies = listSubFolders(fullfile(ipath,patients{j}));
%dpath = fullfile(ipath,patients{j},studies{1});
dpath = fullfile(ipath,patients{j},studies{studyJ});
% load data
load(fullfile(dpath,'brain'));
%load(fullfile(dpath,'brain_CT'));
N = length(brain);%-1;
load(fullfile(dpath,'p3all'));
% Smallest image (in mm)
imageSizes = S.*dims;%S(1:size(S,1)-1,:).*dims(1:size(dims,1)-1,:);%S.*dims;
[~,idxMin] = min(imageSizes(:,3));
Smin = imageSizes(idxMin,:);
center= [floor(Smin(1)/2) floor(Smin(2)/2) floor(Smin(3)/2)];

comp_vec = 1:N;
comp_vec(idxMin) = [];
%setting image-resolution for affine registration to 1mm
resolution=[1 1 1];
[X11, X2, X3]=ndgrid(0:resolution(1):Smin(1)-resolution(1),0:resolution(2):Smin(2)-resolution(2),0:resolution(3):Smin(3)-resolution(3));
pts=[X11(:) X2(:) X3(:)];


im1 = reshape(SplineInterpolation(pts,brain(idxMin).img,[0 0 0],dims(idxMin,:)),size(X11));

pts1 = do_sym_affine(p3all(:,comp_vec(1)),pts,center);
trival = SplineInterpolation(pts1,brain(comp_vec(1)).img,offset(:,comp_vec(1)),dims(comp_vec(1),:));
im2 = reshape(trival,size(X11));

for n=1:size(comp_vec,2)
    pts1 = do_sym_affine(p3all(:,comp_vec(n)),pts,center);
    trival = SplineInterpolation(pts1,brain(comp_vec(n)).img,offset(:,comp_vec(n)),dims(comp_vec(n),:));
    eval(['im' num2str(n+1) '= reshape(trival,size(X11));']);
end

DIKUview