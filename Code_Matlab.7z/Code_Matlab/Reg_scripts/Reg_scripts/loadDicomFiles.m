%%%%% lLOADDICOMFILES
% Function for loading various dicom image files
%
% Edit 21/11/2014 to allow loading mosaic
% Edit 14/03/2016 Changed sorting.

function [struct,dName] = loadDicomFiles(dName,varargin)

if nargin == 0
    dialog_title = 'Select folder containing DICOM files to load.';
    dName = uigetdir('',dialog_title);
    if ~dName % user pressed cancels
        struct = [];
        return
    end
end

% Default properties
convertpixelvalues = 1;
showwaitbar = 1;
precision = 'uint16';
savedcminfo = true;
k = 1;
while k <= length(varargin)
    switch lower(varargin{k})
        case 'convertpixelvalues'
            k = k + 1;
            convertpixelvalues = varargin{k};
        case 'showwaitbar'
            k = k + 1;
            showwaitbar = varargin{k};
        case 'precision'
            k = k + 1;
            precision = varargin{k};
        case 'savedicominfo'
            k = k + 1;
            savedcminfo = varargin{k};
    end
    k = k + 1;
end

fArray = listDicomFiles(dName);
noFiles = length(fArray);

if noFiles == 0
    warndlg('No DICOM files found!')
    return
end

infos = cell(length(fArray),1);

% Read meta data
ignore = zeros(length(fArray),1);
sliceLocations = NaN(length(fArray),1);
acquisitionTimes = NaN(length(fArray),1);
tic;
for i = 1:noFiles
    disp(['Reading files ... Number ' num2str(i) ' of ' num2str(noFiles) '...'])
    infos{i} = dicominfo(fullfile(dName,fArray{i}));
    % Check if image is projection image
    if ~isempty(regexpi(infos{i}.ImageType,'Projection Image')) || ~isempty(regexpi(infos{i}.ImageType,'POSDISP'))
        disp(['Ignoring ' fArray{i} '. Image is a projection image.']);
        ignore(i) = 1;
    end
    % Through slice direction cross(u1,u2)
    n = cross(infos{i}.ImageOrientationPatient(1:3),infos{i}.ImageOrientationPatient(4:6));
    % Determine ImagePatientPosition along n
    sliceLocations(i) = dot(n,infos{i}.ImagePositionPatient);
    if isfield(infos{1},'AcquisitionTime')
        acquisitionTimes(i) = str2double(infos{i}.AcquisitionTime);
    end
end
fArray = fArray(~ignore);
infos = infos(~ignore);
sliceLocations = sliceLocations(~ignore);
acquisitionTimes = acquisitionTimes(~ignore);
clear ignore
timeInfo = toc;
disp(['Read metadata from ' num2str(noFiles) ' dicomfiles in ' sprintf('%.2f',timeInfo) ' seconds.'])
noFiles = length(fArray);

% Does all images belong to the same series?
seriesUids = arrayfun(@(i) infos{i}.SeriesInstanceUID, 1:numel(infos),'UniformOutput',0);
uniqueSeries = unique(seriesUids);
if length(uniqueSeries) > 1
    disp('Images from more than one series is present...')
    tmp = zeros(length(uniqueSeries),1);
    for i = 1:length(uniqueSeries)
        tmpIndexInSeriesUids = strcmp(seriesUids,uniqueSeries{i});
        tmp(i) = sum(tmpIndexInSeriesUids);
        disp(infos{find(tmpIndexInSeriesUids,1,'first')}.SeriesDescription)
    end
    % Save images from most frequent series
    [~,i] = max(tmp);
    usedSeriesUid = uniqueSeries{i};
    infos = infos(strcmp(seriesUids,usedSeriesUid));
    fArray = fArray(strcmp(seriesUids,usedSeriesUid));
    noFiles = length(fArray);
    disp(['Saving images from ' infos{1}.SeriesDescription '.']);
end

nRows = double(infos{1}.Rows);
nCols = double(infos{1}.Columns);
nFrames = numel(unique(sliceLocations));
nTimepoints = numel(unique(acquisitionTimes));
struct.info = infos{1};

% PREALLOCATE
vol = zeros(nRows, nCols, noFiles,'uint16');
X = zeros(nRows, nCols, noFiles,'single');
Y = zeros(nRows, nCols, noFiles,'single');
Z = zeros(nRows, nCols, noFiles,'single');

WindowCenter = NaN(noFiles,1);
WindowWidth = NaN(noFiles,1);

% Read images
if showwaitbar
    h = waitbar(0,'Reading images.....');
end

for frame = 1:noFiles
    % Update waitbar
    if showwaitbar
        waitbar(frame / noFiles)
    end
    
    %Check if PET is corrected for Scatter and Attenuation
    if (strcmpi(infos{frame}.Modality,'PT') || strcmpi(infos{frame}.Modality,'PET'))
        if ~strfind(infos{frame}.CorrectedImage,'ATTN')
            warning('PET:correction','Imported PET is not attenuation corrected!')
        end
        if ~strfind(infos{frame}.CorrectedImage,'SCAT')
            warning('PET:correction','Imported PET is not scatter corrected!')
        end
    end
    
    % Determine direction cosine matrix
    R = zeros(4);
    R(1:3,1) = infos{frame}.ImageOrientationPatient(1:3);
    R(1:3,2) = infos{frame}.ImageOrientationPatient(4:6);
    R(1:3,3) = cross(infos{frame}.ImageOrientationPatient(1:3),infos{frame}.ImageOrientationPatient(4:6));
    R(4,4) = 1;
    
    WindowCenter(frame) = infos{frame}.WindowCenter(1);
    WindowWidth(frame) = infos{frame}.WindowWidth(1);
    
    % Read DICOM image
    tmpImg = dicomread(infos{frame});
    
    % Convert PET pixel intensities to Activity (and SUV if flagged)
    if (strcmpi(infos{frame}.Modality,'PT') || strcmpi(infos{frame}.Modality,'PET'))
        vol(:,:,frame) = correctPET(tmpImg,infos{frame},convertpixelvalues);
        WindowCenter(frame) = correctPET(WindowCenter(frame),infos{frame},convertpixelvalues);
        WindowWidth(frame) = correctPET(WindowWidth(frame),infos{frame},convertpixelvalues);
        % Convert CT images to Hounsfield Units if flagged
    elseif strcmpi(infos{frame}.Modality,'CT') && convertpixelvalues
        vol(:,:,frame) = correctCT(tmpImg,infos{frame});
    else
        vol(:,:,frame) = tmpImg;
    end
    
    % Pixel data
    m = nCols*nRows;
    i = repmat(0:nCols-1,nRows,1); % column indices
    j = repmat((0:nRows-1)',1,nCols); % row indices
    % Transform pixel data to world coordinates
    % M is described in C.7.6.2.1 in PS.03 of the DICOM standard
    M = zeros(4);
    M(1:3,1) = R(1:3,1) * infos{frame}.PixelSpacing(2);
    M(1:3,2) = R(1:3,2) * infos{frame}.PixelSpacing(1);
    M(1:3,4) = infos{frame}.ImagePositionPatient';
    M(:,3) = 0; M(4,4) = 1;
    imageCoordinates = [i(:)'; j(:)'; zeros(1,m); ones(1,m)];
    patientCoordinates = M*imageCoordinates;
    % Save world coordinates per frame
    X(:,:,frame) = reshape(patientCoordinates(1,:),[nRows,nCols]);
    Y(:,:,frame) = reshape(patientCoordinates(2,:),[nRows,nCols]);
    Z(:,:,frame) = reshape(patientCoordinates(3,:),[nRows,nCols]);
    
end

% Save meta
struct.VolumeType = 'Scan';
struct.FrameOfReferenceUID = infos{frame}.FrameOfReferenceUID;

if isfield(struct.info,'SpacingBetweenSlices')
    voxelDimension = [struct.info.PixelSpacing' struct.info.SpacingBetweenSlices];
else
    voxelDimension = [];
end

% Re-order unless Image Type is MOSAIC
if isempty(regexpi(infos{1}.ImageType,'MOSAIC'))
    % sort each slice in ascending order (sort by first column, then second
    % column, i.e. first timepoint, then slicelocation)
    
    if nFrames == numel(sliceLocations)
        [~,sortOrder] = sortrows(sliceLocations);
        nTimepoints = 1;
    else
        % Time series information
        [~,sortOrder] = sortrows([acquisitionTimes,sliceLocations]);
        timeVector = unique(acquisitionTimes);
        struct.time = timeVector-timeVector(1);
    end
    
    % Apply sorting
    vol = vol(:,:,sortOrder);
    X = X(:,:,sortOrder);
    Y = Y(:,:,sortOrder);
    Z = Z(:,:,sortOrder);
    infos = infos(sortOrder);
    
    % Re-shape to volumes
    vol = reshape(vol,nRows, nCols,nFrames,nTimepoints);
    X = reshape(X,nRows, nCols,nFrames,nTimepoints);
    Y = reshape(Y,nRows, nCols,nFrames,nTimepoints);
    Z = reshape(Z,nRows, nCols,nFrames,nTimepoints);
    % Create reference object
    if showwaitbar
        waitbar(1,h,'Creating reference object.....');
    end
    %%%% Re-orient if, image isn't axial
    if R(3,3)<0.8
        %[vol,X,Y,Z,R] = fixVolumeOrientationDICOM(vol,X,Y,Z,R,voxelDimension);
        [vol,X,Y,Z,R] = fixVolumeOrientationDICOM(vol,X,Y,Z,R);
    end
    
    struct.vol = vol;
    struct.X = X(:,:,:,1);
    struct.Y = Y(:,:,:,1);
    struct.Z = Z(:,:,:,1);
    struct.R = R;
    
    struct.ReferenceObject = getRobject(struct,'world');
else
    struct.X = X;
    struct.Y = Y;
    struct.Z = Z;
    struct.vol = vol;
    struct.VolumeType = 'ScanMosaic';
end

struct.VoxelDimension = [
    struct.ReferenceObject.PixelExtentInWorldY;
    struct.ReferenceObject.PixelExtentInWorldX;
    struct.ReferenceObject.PixelExtentInWorldZ];

if savedcminfo
    struct.infos = infos(1:nFrames);
else
    struct.infos = infos;
end

% Average Window-Center and -Width
WindowCenter(:) = deal(nanmean(WindowCenter));
WindowWidth(:) = deal(nanmean(WindowWidth));
struct.WindowCenter = repmat(mean(WindowCenter),size(vol,3),1);
struct.WindowWidth = repmat(mean(WindowWidth),size(vol,3),1);

% Close waitbar
if exist('h','var')
    close(h)
end


% Convert to desired precision
switch precision
    case 'single'
        struct.vol = single(struct.vol);
        struct.X = single(struct.X);
        struct.Y = single(struct.Y);
        struct.Z = single(struct.Z);
    case 'double'
        struct.vol = double(struct.vol);
        struct.X = double(struct.X);
        struct.Y = double(struct.Y);
        struct.Z = double(struct.Z);
        
end

if nargout == 0
    v = version('-release');
    if str2double(v(1:4)) < 2014
        assignin('base', genvarname(info.SeriesDescription), struct);
    else
        Vars = evalin('base','who;');
        name = matlab.lang.makeUniqueStrings(matlab.lang.makeValidName(infos{1}.SeriesDescription),Vars);
        assignin('base', name, struct);
    end
end