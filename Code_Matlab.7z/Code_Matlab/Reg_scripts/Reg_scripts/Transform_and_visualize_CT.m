%% Match images with affine and non-rigid registration

% Depends on 'options' (including path and image names) having been set and
% that rigid registration is loaded as 'p3' and non-rigid registration as
% 'pp4'

%pt_no = '5';

%name_img1 = 'Baseline_FA';
%name_img2 = 'FU1_FA';
%name_img1 = 'Baseline_b0';
name_img2 = 'Baseline_b0';

% Load registration
%load(fullfile(dpath,['\' pt_no '\' name_img2 '_to_' name_img1 '_affine']));
%load(fullfile(dpath,['\' pt_no '\' name_img2 '_to_' name_img1]));

% Load images
MRI1=ct;
MRI2=load_untouch_nii(fullfile(dpath,['\' name_img2 '.nii']));
%img1=double(flip(permute(ct.X(:,:,:),[2 1 3]),2));
img1=double(flip(permute(ct.X(100:350,150:350,50:270),[2 1 3]),2));
img2=double(MRI2.img);

%% 

%get image resolution
dimt1=[ct.dx(2),ct.dx(1),ct.dx(3)];
dimt2=MRI2.hdr.dime.pixdim(2:4);

% Image size [mm]
S1=size(img1).*dimt1;
S2=size(img2).*dimt2;

% Create grid for interpolation of images after transformation
%[X11, X2, X3]=ndgrid(0:dimt1(1):S1(1),0:dimt1(2):S1(2),0:dimt1(3):S1(3));
%org_pts=[X11(:) X2(:) X3(:)];
%[X1, X2, X3]=ndgrid(0:dimt2(1):S2(1),0:dimt2(2):S2(2),0:dimt2(3):S2(3));
%org_pts2=[X1(:) X2(:) X3(:)];

[X11, X21, X31]=ndgrid(0:dimt1(1):S1(1)-dimt1(1),0:dimt1(2):S1(2)-dimt1(2),0:dimt1(3):S1(3)-dimt1(3));
org_pts1=[X11(:), X21(:), X31(:)];
[X12, X22, X32]=ndgrid(0:dimt2(1):S2(1)-dimt2(1),0:dimt2(2):S2(2)-dimt2(2),0:dimt2(3):S2(3)-dimt2(3));
org_pts2=[X12(:), X22(:), X32(:)];
            
n1=SplineInterpolation_lin(org_pts1+repmat(0*dimt1,numel(X11),1),img1,[0 0 0],dimt1);
n11=SplineInterpolation_lin(org_pts2+repmat(0*dimt2,numel(X12),1),img2,[0 0 0],dimt2);

% Interpolate images 
%n1=SplineInterpolation_lin(org_pts+repmat(0.5*dimt1,numel(X11),1),double(flip(permute(ct.X(:,:,80:270),[2 1 3]),2)),[0 0 0],dimt1);
%n11=SplineInterpolation_lin(org_pts2+repmat(0.5*dimt2,numel(X1),1),double(MRI2.img(:,:,:)),[0 0 0],dimt2);

%% Match with affine registration

%img2 matched to img1 by affine
%[pts3, ipts3]=do_sym_affine(p3(:),org_pts,center);
%[pts3, ipts3]=do_sym_affine(p2(:),org_pts,center);
%n3=SplineInterpolation_lin(ipts3+repmat(0.5*dimt2,numel(X11),1),double(MRI2.img(:,:,:)),[0 0 0],dimt2);
[~, ipts3]=do_sym_affine(p3(:),org_pts1,center);
n2=SplineInterpolation_lin(ipts3+repmat(0*dimt2,numel(X11),1),img2,[0 0 0],dimt2);

%img1 matched to img2 by inv affine
%[pts3, ipts3]=do_sym_affine(p3(:),org_pts2,center);
%[pts3, ipts3]=do_sym_affine(p2(:),org_pts2,center);
%n33=SplineInterpolation_lin(pts3+repmat(0.5*dimt1,numel(X1),1),double(flip(permute(ct.X(:,:,:),[2 1 3]),2)),[0 0 0],dimt1);
pts3=do_sym_affine(p3(:),org_pts2,center);
n33=SplineInterpolation_lin(pts3+repmat(0*dimt1,numel(X12),1),img1,[0 0 0],dimt1);

% Back into matrix for visualization
img11 = reshape(n1,size(X11));
img21 = reshape(n11,size(X12));
img12 = reshape(n2,size(X11));
img22 = reshape(n33,size(X12));

%% %% Match images with non-rigid registration

ww=[5 5 5];
offset2=-ww;

%img2 matched to img1 by first inverse affine and then non-rigid transform
[pts3, ipts3]=do_sym_affine(p3(:),org_pts,center);
tic;[inr_pts]=SS_Trap_1st(ipts3,-pp4,offset2,ww,double(40),double(5));toc
n3=SplineInterpolation_lin(inr_pts+repmat(0.5*dimt2,numel(X11),1),double(MRI2.img(:,:,:)),[0 0 0],dimt2);

%img1 matched to img2 by first affine and then non-rigid transform
tic;[nr_pts]=SS_Trap_1st(org_pts2,pp4,offset2,ww,double(40),double(5));toc
[pts3, ipts3]=do_sym_affine(p3(:),nr_pts,center);
n33=SplineInterpolation_lin(pts3+repmat(0.5*dimt1,numel(X1),1),double(MRI1.img(:,:,:)),[0 0 0],dimt1);

% Back into matrix for visualization
img11 = reshape(n1,size(X11));
img21 = reshape(n11,size(X1));
img12 = reshape(n3,size(X11));
img22 = reshape(n33,size(X1));

%% Visualize
MR2slice = 130;

figure(1),imagesc(img11(:,:,MR2slice)), axis image
figure(2),imagesc(img12(:,:,MR2slice)), axis image
figure(4),imagesc(imfuse(img11(:,:,MR2slice),img12(:,:,MR2slice))); axis image  % requires MATLAB ImageProcessing Toolbox
