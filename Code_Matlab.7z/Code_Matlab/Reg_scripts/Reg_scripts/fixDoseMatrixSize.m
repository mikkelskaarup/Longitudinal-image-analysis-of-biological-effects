%Find the biggest matrix size. Denote the target dose matrix (the larger
%matrix) and the change dose matrix (the one to be changed).
Msize = size(pt(i-1).dMC(j).imd);
index_change=1;
index_target=i;
% OBS: If there's more than two different dose matrix sizes, then this
% selection will not work (I think)
if sum(Msize > size(pt(i).dMC(j).imd))==3
    index_change=i;
    index_target=1;
elseif sum(Msize < size(pt(i).dMC(j).imd))==3
    Msize = size(pt(i).dMC(j).imd);
end

pixel0 = double(int8((pt(index_change).dMC(j).x0 - pt(index_target).dMC(j).x0) ./ pt(index_target).dMC(j).dx));
pixeln = double(int8((pt(index_target).dMC(j).xn - pt(index_change).dMC(j).xn) ./ pt(index_target).dMC(j).dx));



%Change the dose matrix
if any(pixeln<0)
    dummy = zeros(Msize(1), Msize(2), Msize(3)+abs(pixeln(3)));
    dummy(:,:,1:end+double(pixeln(3))) = pt(index_target).dMC(j).imd;
    pt(index_target).dMC(j).imd = dummy;
    dummy(:,:,1:end+double(pixeln(3))) = pt(index_target).let(j).imd;
    pt(index_target).let(j).imd = dummy;
    clear dummy
    
    dummy = zeros(Msize(1), Msize(2), Msize(3)+double(abs(pixeln(3))));
    dummy(:,:,1:end+double(pixeln(3))) = pt(index_target).dMC(j).xd;
    for n=1:double(abs(pixeln(3))); dummy(:,:,end+double(pixeln(3))+n) = pt(index_target).dMC(j).xd(:,:,138); end
    pt(index_target).dMC(j).xd = dummy; pt(index_target).let(j).xd = dummy;
    
    dummy = zeros(Msize(1), Msize(2), Msize(3)+double(abs(pixeln(3))));
    dummy(:,:,1:end+double(pixeln(3))) = pt(index_target).dMC(j).yd;
    for n=1:double(abs(pixeln(3))); dummy(:,:,end+double(pixeln(3))+n) = pt(index_target).dMC(j).yd(:,:,138); end
    pt(index_target).dMC(j).yd = dummy; pt(index_target).let(j).yd = dummy;
    
    dummy = zeros(Msize(1), Msize(2), Msize(3)+double(abs(pixeln(3))));
    dummy(:,:,1:end+double(pixeln(3))) = pt(index_target).dMC(j).zd;
    for n=1:double(abs(pixeln(3))); dummy(:,:,end+double(pixeln(3))+n) = pt(index_target).dMC(j).zd(:,:,138)+n*pt(index_target).dMC(j).dx(3); end
    pt(index_target).dMC(j).zd = dummy; pt(index_target).let(j).zd = dummy;
    clear dummy
    
    dummy=zeros(size(pt(index_target).dMC(j).zd1,1)+double(abs(pixeln(3))),1);
    dummy(1:end+double(pixeln(3))) = pt(index_target).dMC(j).zd1;
    for n=1:double(abs(pixeln(3))); dummy(end+double(pixeln(3))+n) = pt(index_target).dMC(j).zd1(138)+n*pt(index_target).dMC(j).dx(3); end
    pt(index_target).dMC(j).zd1 = dummy; pt(index_target).let(j).zd1 = dummy;
    clear dummy
    
    pt(index_target).dMC(j).xn(3) = pt(index_change).dMC(j).xn(3);
    pt(index_target).let(j).xn(3) = pt(index_change).let(j).xn(3);
    pixeln(3) = 0;
    Msize = size(pt(index_target).dMC(j).imd);
    pt(index_target).dMC(j).n = [Msize(2), Msize(1), Msize(3)];
    pt(index_target).let(j).n = [Msize(2), Msize(1), Msize(3)];
    
    newDose = zeros(Msize);
    newLET = zeros(Msize);
    newDose(pixel0(2):size(newDose,1)-pixeln(2)-1, pixel0(1):size(newDose,2)-pixeln(1)-1, pixel0(3):size(newDose,3)-pixeln(3)-1) = pt(index_change).dMC(j).imd;
    pt(index_change).dMC(j).imd = newDose;

    pt(index_change).dMC(j).xd = pt(index_target).dMC(j).xd;
    pt(index_change).dMC(j).yd = pt(index_target).dMC(j).yd;
    pt(index_change).dMC(j).zd = pt(index_target).dMC(j).zd;

    pt(index_change).dMC(j).x0 = pt(index_target).dMC(j).x0;
    pt(index_change).dMC(j).xn = pt(index_target).dMC(j).xn;
    pt(index_change).dMC(j).dx = pt(index_target).dMC(j).dx;

    pt(index_change).dMC(j).zd1 = pt(index_target).dMC(j).zd1;
    pt(index_change).dMC(j).yd1 = pt(index_target).dMC(j).yd1;
    pt(index_change).dMC(j).xd1 = pt(index_target).dMC(j).xd1;

    pt(index_change).dMC(j).n = pt(index_target).dMC(j).n;

%Change the LET matrix
    newLET(pixel0(2):size(newLET,1)-pixeln(2)-1, pixel0(1):size(newLET,2)-pixeln(1)-1, pixel0(3):size(newLET,3)-pixeln(3)-1) = pt(index_change).let(j).imd;
    pt(index_change).let(j).imd = newLET;

    pt(index_change).let(j).xd = pt(index_target).let(j).xd;
    pt(index_change).let(j).yd = pt(index_target).let(j).yd;
    pt(index_change).let(j).zd = pt(index_target).let(j).zd;

    pt(index_change).let(j).x0 = pt(index_target).let(j).x0;
    pt(index_change).let(j).xn = pt(index_target).let(j).xn;
    pt(index_change).let(j).dx = pt(index_target).let(j).dx;

    pt(index_change).let(j).zd1 = pt(index_target).let(j).zd1;
    pt(index_change).let(j).yd1 = pt(index_target).let(j).yd1;
    pt(index_change).let(j).xd1 = pt(index_target).let(j).xd1;

    pt(index_change).let(j).n = pt(index_target).let(j).n;
else
    newDose = zeros(Msize);
    newLET = zeros(Msize);
    newDose(pixel0(2):size(newDose,1)-pixeln(2)-1, pixel0(1):size(newDose,2)-pixeln(1)-1, pixel0(3):size(newDose,3)-pixeln(3)-1) = pt(index_change).dMC(j).imd;
    pt(index_change).dMC(j).imd = newDose;

    pt(index_change).dMC(j).xd = pt(index_target).dMC(j).xd;
    pt(index_change).dMC(j).yd = pt(index_target).dMC(j).yd;
    pt(index_change).dMC(j).zd = pt(index_target).dMC(j).zd;

    pt(index_change).dMC(j).x0 = pt(index_target).dMC(j).x0;
    pt(index_change).dMC(j).xn = pt(index_target).dMC(j).xn;
    pt(index_change).dMC(j).dx = pt(index_target).dMC(j).dx;

    pt(index_change).dMC(j).zd1 = pt(index_target).dMC(j).zd1;
    pt(index_change).dMC(j).yd1 = pt(index_target).dMC(j).yd1;
    pt(index_change).dMC(j).xd1 = pt(index_target).dMC(j).xd1;

    pt(index_change).dMC(j).n = pt(index_target).dMC(j).n;

%Change the LET matrix
    newLET(pixel0(2):size(newLET,1)-pixeln(2)-1, pixel0(1):size(newLET,2)-pixeln(1)-1, pixel0(3):size(newLET,3)-pixeln(3)-1) = pt(index_change).let(j).imd;
    pt(index_change).let(j).imd = newLET;

    pt(index_change).let(j).xd = pt(index_target).let(j).xd;
    pt(index_change).let(j).yd = pt(index_target).let(j).yd;
    pt(index_change).let(j).zd = pt(index_target).let(j).zd;

    pt(index_change).let(j).x0 = pt(index_target).let(j).x0;
    pt(index_change).let(j).xn = pt(index_target).let(j).xn;
    pt(index_change).let(j).dx = pt(index_target).let(j).dx;

    pt(index_change).let(j).zd1 = pt(index_target).let(j).zd1;
    pt(index_change).let(j).yd1 = pt(index_target).let(j).yd1;
    pt(index_change).let(j).xd1 = pt(index_target).let(j).xd1;

    pt(index_change).let(j).n = pt(index_target).let(j).n;
end
clear newLET; clear newDose; clear Msize; clear index_target; clear index_change
clear pixel0; clear pixeln;