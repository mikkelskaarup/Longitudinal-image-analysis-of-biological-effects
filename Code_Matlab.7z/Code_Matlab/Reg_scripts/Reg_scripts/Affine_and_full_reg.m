%% Set options

dpath = 'P:\FIN\Lukkede Mapper\DTI-project\MDA';

pt_no = '21';

name_img1 = 'Baseline_b0';
name_img2 = 'FU2_b0';

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';
options.reg=0.0002;

options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;
options4=options;
options4.MaxIter=100;

%setting scale and offset of img11
scale=[1 1 1];
offset=[1 1 1]*0;

warning off all

nonRigidRes = 3;
rigidRes = 1;

%% Load images and prepare data for registration

MRI1=load_untouch_nii(fullfile(dpath,['\' pt_no '\' name_img1 '.nii']));
MRI2=load_untouch_nii(fullfile(dpath,['\' pt_no '\' name_img2 '.nii']));
img1=double(MRI1.img);
img2=double(MRI2.img);

%get image resolution
dimt1=MRI1.hdr.dime.pixdim(2:4);
dimt2=MRI2.hdr.dime.pixdim(2:4);

% Image size [mm]
S1=size(img1).*dimt1;
S2=size(img2).*dimt2;

% rescale images to conform with 160 bins (good values are between 80 and 256)
img1=img1-min(img1(:));
img2=img2-min(img2(:));
img2=img2/max(img2(:))*160;
img1=img1/max(img1(:))*160;

%define center of rotation (mm from corner of img1)
center=[floor(S1(1)/2) floor(S1(2)/2) floor(S1(3)/2)]

%% Affine registration

% Perform registration

%setting image-resolution for affine registration to image resolution
resolution=dimt1;
[X1, X2, X3]=ndgrid(0:resolution(1):S1(1),0:resolution(2):S1(2),0:resolution(3):S1(3));
pts=[X1(:) X2(:) X3(:)];

%vectorize images in 'resolution' resolution
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));
Itrival=(SplineInterpolation_tbb(pts,img1,[0 0 0],dimt1));

%initialize parameters to 0 for affine
p2=zeros(12,1);
%using 1-norm
%perform translation initialization
p2=minFunc(@cf_rigidPNorm_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
%include rotation
p2=minFunc(@cf_rigidPNorm_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
%include scale
p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full affine 
%change parametrization from angles to.... matrix
[f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
p3=T(:);
p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);
p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full symmetric affine registration
p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1));

% Save registration
save(fullfile(dpath,['\' pt_no '\' name_img2 '_to_' name_img1 '_affine']),'p3','center');

%% Non-rigid registration

% Prepare images and perform non-rigid registration

%resample img1 (1mm resolution) to prepare non-rigid registration
resolution=rigidRes;
[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
ptsresample=[X1(:) X2(:) X3(:)];
[pts3]=do_sym_affine(p3(:),ptsresample,center);
Rtrival=(SplineInterpolation_lin(pts3,img1,[0 0 0],dimt1));
img11=reshape(Rtrival,size(X1));

%setting up non-rigid registration
resolution=nonRigidRes;
[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
pts=[X1(:) X2(:) X3(:)];
Itrival=(SplineInterpolation_tbb(pts,img11,[0 0 0],[1 1 1]));
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));

% extracting positions with information
no=find(Itrival+Jtrival>0);

% initialize to 0
pp4=zeros([30 30 30 3]);
ww=[40 40 40];

%no. of points in deformation grid
grid_size=45;

% set decreasing grid size of deformation field
% pyramidLevels = [40 20 10 5];
pyramidLevels = [32 16 8 4];

for pl=1:length(pyramidLevels)
    if (pl==1 || pl==2)
        curr_options = options2;
    elseif pl == 3
        curr_options = options3;
    elseif pl == 4
        curr_options = options4;
    else
        error('Bummer!!')
    end
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    %resampling deformation field to new resolution
    %resampling deformation field to new resolution
    [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
    tpts=[XX1(:) XX2(:) XX3(:)]*pyramidLevels(pl);
    n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
    %setting scale and offset of img11
    scale=[1 1 1];
    offset=[1 1 1]*0;
    
    %setting size of deformation grid and parametrization
    val=ones([grid_size grid_size grid_size 3]);
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    p4=reshape(n,size(val));
    offset2=-ww;
    
    % Regularisation is in "0.0005" - change to 0.00025
    pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),curr_options,size(p4),(curr_options.reg),pts(no,:),img11,img2,Jtrival(no),Itrival(no),offset2,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);

    pp4=reshape(pp4,size(p4));

end

% Save registration
save(fullfile(dpath,['\' pt_no '\' name_img2 '_to_' name_img1 'reg0.0002']),'pp4');
