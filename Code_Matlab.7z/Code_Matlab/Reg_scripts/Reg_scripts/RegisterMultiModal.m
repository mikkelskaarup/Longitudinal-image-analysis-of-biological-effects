%ipath = '/Volumes/DTI-project/DIKU-RH';
ipath = '/Users/appelt/Dropbox/Work/DTI projekt/DTI data/DIKU-RH';

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

ITER = 3;
%
warning off all

patients = {'2'};

% Loop over patients
p = 1;


% Loop over studies
for st = 2%2:3
    fileNames = [];
    if st == 1
        study = 'Baseline';
    else
        study = ['FU_' num2str(st-1)];
    end
    dpath=fullfile(ipath,patients{p},study);
    %dpath=fullfile(ipath,patients{p});
    % load data
    load(fullfile(dpath,'brain'));
    
    N=length(brain);
    
    
    % Largest image (in mm)
    Smax = max(S.*dims);
    %define center of rotation (mm from corner of img1)
    center = repmat([floor(Smax(1)/2) floor(Smax(2)/2) floor(Smax(3)/2)],N,1);
    
    centr = zeros(3,length(brain));
    
    %bgAvg = zeros(1,length(brain));
    
    for i = 1:length(brain)
        id=kmeans(brain(i).img(:),2);
        if id(1) == 2
            id=2-id;
        elseif id(1) == 1
            id=id-1;
        else
            error('Situation not accounted for!');
        end
        %bgAvg(i) = mean(brain(i).bimg(id==0));
        cls=reshape(id,size(brain(i).img));
        brain(i).mask = zeros(size(brain(i).img));
        for k=1:size(brain(i).img,3)
            brain(i).mask(:,:,k) = activecontour(brain(i).img(:,:,k),cls(:,:,k));
        end
        props=regionprops(cls,'Centroid');
        c = props.Centroid.*dims(i,:);
        centr(1,i) = c(2);
        centr(2,i) = c(1);
        centr(3,i) = c(3);
    end
    
    % Pre-allocate initial affine
    p=zeros(12,N);
    p(1,:)=1;p(5,:)=1;p(9,:)=1;
    
    % Perform initial translokation
    cDiff = centr-center';
    p(10:12,:) = cDiff;

    % Pre-allocate final symmetric affine
    pt = zeros(12,N);
    
    %setting image-resolution for affine registration to 2mm
    resolution=[1 1 1]*2;
    [X11, X21, X31]=ndgrid(0:resolution(2):Smax(1),0:resolution(1):Smax(2),0:resolution(3):Smax(3));
    pts=[X11(:), X21(:), X31(:)];
    
    % for affine template
    Jtrival = zeros(length(pts),N);
    Itrival = Jtrival;
    for j = 1:N
        %I = ones(size(brain(j).bimg)+[0 0 2])*bgAvg(j);
        I = zeros(size(brain(j).bimg)+[0 0 2]);
        %I(2:end-1,2:end-1,2:end-1) = brain(j).bimg.*brain(j).mask;
        I(:,:,2:end-1) = brain(j).bimg.*brain(j).mask;
        Itrival(:,j)=(SplineInterpolation(pts,I,[0 0 0],dims(j,:)));
        Jtrival(:,j)=(SplineInterpolation(pts,I,[0 0 0],dims(j,:)));
        %Itrival(:,j)=(SplineInterpolation(pts,brain(j).bimg,[0 0 0],dims(j,:)));
        %Jtrival(:,j)=(SplineInterpolation(pts,brain(j).bimg,[0 0 0],dims(j,:)));
    end
        
    for k=1:ITER
        %N is the number of images
        tItrival = zeros(length(pts),N);
        parfor i=1:N
            comp_vec=[(1:N)*0+1*i;1:N]';
            comp_vec(i,:)=[];
            % initialize with translation
            pt(:,i)=minFunc(@cf_sym_affine_NMI_MultiModal,p(:,i),options,brain,brain,pts,center(i,:),Itrival,Jtrival,dims,dims,ones(size(pts,1),1),p,p,center,center,comp_vec)
            p3=pt(:,i);
            [pts3]=do_sym_affine(p3(:),pts,center(i,:));
            %tItrival(:,i)=(SplineInterpolation(pts3,brain(i).bimg,[0 0 0],dims(i,:)));
            tItrival(:,i)=(SplineInterpolation(pts3,reshape(Jtrival(:,i),size(X11)),[0 0 0],resolution));
            % tJtrival(:,i)=(SplineInterpolation(pts,brain(i).bimg,[0 0 0],dims(i)));
        end
        pause(52)
        disp(k)
        Itrival=tItrival;
        %Itrival=Itrival - repmat(min(Itrival),size(pts,1),1);
        %Itrival=Itrival./repmat(max(Itrival),size(pts,1),1)*160;
        
        %Jtrival=tJtrival;
        p=pt;
        saveparams(fullfile(dpath,['pt_affine_template_iteration' num2str(k)]),pt);

    end
    saveparams(fullfile(dpath,['pt_affine_template_' num2str(ITER) '_iteration']),pt);
end