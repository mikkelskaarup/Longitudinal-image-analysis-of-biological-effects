%% Resample dose in same frame as baseline imaging

% Plan and beam number for basic properties
pl = 1;
bm = 1;

% Get difference between first voxel on CT and first voxel in dose matrix.
% If you're using the same software as MD Anderson to get your plan.mat
% file, swap the "1" and "2" in pt(1).dMC(1).x0("1"/"2")
pdiff(1) = pt(1).dMC(1).x0(1) - pt(1).ct.x0(1);
pdiff(2) = pt(1).dMC(1).x0(2) - pt(1).ct.x0(2);
pdiff(3) = pt(1).dMC(1).x0(3) - pt(1).ct.x0(3);

% Resample dose to same space as baseline imaging (using offset, etc, from
% CT). Assume offset between dose and CT is saved in pdiff
dimD = pt(pl).dMC(bm).dx;

j=1;
pts1 = do_sym_affine(I_aff(:,size(I_aff,2)),pointsI,Icenter);
oDtrival = (SplineInterpolation(pts1,double(dose.imd),offsetI(:,size(offsetI,2))+pdiff',dimD));
for i=1:nPh
    oDtrival2 = (SplineInterpolation(pts1,double(dosePhase(i).imd),offsetI(:,size(offsetI,2))+pdiff',dimD));
    eval(['dosePhase' num2str(i) ' = reshape(oDtrival2,size(XI1));']);
    oDtrival2 = (SplineInterpolation(pts1,double(dLETPhase(i).imd),offsetI(:,size(offsetI,2))+pdiff',dimD));
    eval(['dLETPhase' num2str(i) ' = reshape(oDtrival2,size(XI1));']);
    oDtrival2 = (SplineInterpolation(pts1,double(dLETDosePhase(i).imd),offsetI(:,size(offsetI,2))+pdiff',dimD));
    eval(['dLETDosePhase' num2str(i) ' = reshape(oDtrival2,size(XI1));']);
end
clear oDtrival2;
doseImg = reshape(oDtrival,size(XI1));