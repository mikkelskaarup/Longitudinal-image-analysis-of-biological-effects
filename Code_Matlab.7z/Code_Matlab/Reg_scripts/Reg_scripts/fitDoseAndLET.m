%% Load the data
studyI = 1;
j=1;

FUs = {};
FUs{1} = [2, 3, 4];
FUs{2} = [1, 2, 3, 4];
FUs{3} = [1, 2, 3];
FUs{4} = [1, 2];
FUs{5} = [1, 2];
FUs{6} = [1, 2];

mask = {}; dose = {}; LET = {};
FABase = {}; T1Base = {}; T2Base = {};
FAFU =  {}; T1FU =  {}; T2FU =  {};
for pt=1:6
    patients = {num2str(pt)};
    mask{pt} = load(['Data\mask' num2str(patients{j}) '.mat']);
    dose{pt} = load(['Data\dose' num2str(patients{j}) '.mat']);
    LET{pt} = load(['Data\LET' num2str(patients{j}) '.mat']);
    FABase{pt} = load(['Data\FABase' num2str(patients{j}) '.mat']);
    T1Base{pt} = load(['Data\T1Base' num2str(patients{j}) '.mat']);
    T2Base{pt} = load(['Data\T2Base' num2str(patients{j}) '.mat']);
    for study=FUs{pt}
        studyJ = study;
        FAFU{studyJ,pt} = load(['Data\FAFU' num2str(patients{j}) '-' num2str(studyJ) '.mat']);
        T1FU{studyJ,pt} = load(['Data\T1FU' num2str(patients{j}) '-' num2str(studyJ) '.mat']);
        T2FU{studyJ,pt} = load(['Data\T2FU' num2str(patients{j}) '-' num2str(studyJ) '.mat']);
    end
end
%% Fit
N_I = [7,7,9,8,7,7];
N_J = zeros(size(FAFU));
N_J(1,:) = [0,6,6,6,6,5];
N_J(2,:) = [6,7,5,6,6,6];
N_J(3,:) = [7,7,6,0,0,0];
N_J(4,:) = [5,6,0,0,0,0];
coefficientsFAa = zeros([16,1]);
coefficientsFAb = zeros([16,1]);
coefficientsFAc = zeros([16,1]);
CI_coefficientsFAa = zeros([16,2]);
CI_coefficientsFAb = zeros([16,2]);
CI_coefficientsFAc = zeros([16,2]);
coefficientsT1a = zeros([16,1]);
coefficientsT1b = zeros([16,1]);
coefficientsT1c = zeros([16,1]);
CI_coefficientsT1a = zeros([16,2]);
CI_coefficientsT1b = zeros([16,2]);
CI_coefficientsT1c = zeros([16,2]);
coefficientsT2a = zeros([16,1]);
coefficientsT2b = zeros([16,1]);
coefficientsT2c = zeros([16,1]);
CI_coefficientsT2a = zeros([16,2]);
CI_coefficientsT2b = zeros([16,2]);
CI_coefficientsT2c = zeros([16,2]);

coefficientsFA = zeros([16,3]);
coefficientsT1 = zeros([16,3]);
coefficientsT2 = zeros([16,3]);

iii = 1;
for pt=1:6
    eval(['FAB = FABase{pt}.imI' num2str(N_I(pt)) '.*mask{pt}.strMask;'])
    T1B = T1Base{pt}.imI1.*mask{pt}.strMask;
    T2B = T2Base{pt}.imI3.*mask{pt}.strMask;
    
    % Find cutoff value for background FA, T1 and T2 values
    [xhist, yhist] = hist(FAB(FAB>0),200);
    f = fit(yhist(1:find(xhist==max(xhist))).',xhist(1:find(xhist==max(xhist))).','a*exp(-((x - b)./c).^2)','StartPoint',[max(xhist),0.1,0.05]);
    cutoffValueFA = f.b+2*f.c;
    
%     [xhist, yhist] = hist(T1B(T1B>0),200);
%     f = fit(yhist(1:find(xhist==max(xhist))).',xhist(1:find(xhist==max(xhist))).','a*exp(-((x - b)./c).^2)','StartPoint',[max(xhist),0.1,0.05]);
%     cutoffValueT1 = f.b+2*f.c;
    cutoffValueT1 = 0;
    
%     [xhist, yhist] = hist(T2B(T2B>0),200);
%     f = fit(yhist(1:find(xhist==max(xhist))).',xhist(1:find(xhist==max(xhist))).','a*exp(-((x - b)./c).^2)','StartPoint',[max(xhist),0.1,0.05]);
%     cutoffValueT2 = f.b+2*f.c;
    cutoffValueT2 = 0;
    
    %Apply restrictions on signal and dose for masks for FA, T1 and T2
    %images
    maskFA = zeros(size(mask{pt}.strMask));
    maskFA(FAB > cutoffValueFA & mask{pt}.strMask.*dose{pt}.doseImg > 41) = 1;
    eval(['FABSignal = FABase{pt}.imI' num2str(N_I(pt)) '(maskFA>0);']);

    maskT1 = zeros(size(mask{pt}.strMask));
    maskT1(T1B > cutoffValueT1) = 1;
    T1BSignal = T1Base{pt}.imI1(maskT1>0);

    maskT2 = zeros(size(mask{pt}.strMask));
    maskT2(T2B > cutoffValueT2) = 1;
    T2BSignal = T2Base{pt}.imI3(maskT2>0);

    %For each FU, fit and plot BSpline
    for studyJ=FUs{pt}
        eval(['FAFUSignal = FAFU{studyJ,pt}.imJ' num2str(N_J(studyJ,pt)) 'NR(maskFA>0);'])
        T1FUSignal = T1FU{studyJ,pt}.imJ1NR(maskT1>0);
        T2FUSignal = T2FU{studyJ,pt}.imJ3NR(maskT2>0);
        
        [pp2FA, CI_pp2FA, pp2splineFA] = residualsFit(FAFUSignal, FABSignal, dose{pt}.doseImg(maskFA>0), LET{pt}.dLETtot(maskFA>0), min(dose{pt}.doseImg(maskFA>0)), max(dose{pt}.doseImg(maskFA>0)), min(LET{pt}.dLETtot(maskFA>0)), max(LET{pt}.dLETtot(maskFA>0)));
        [pp2T1, CI_pp2T1, pp2splineT1] = residualsFit(T1FUSignal, T1BSignal, dose{pt}.doseImg(maskT1>0), LET{pt}.dLETtot(maskT1>0), min(dose{pt}.doseImg(maskT1>0)), max(dose{pt}.doseImg(maskT1>0)), min(LET{pt}.dLETtot(maskT1>0)), max(LET{pt}.dLETtot(maskT1>0)));
        [pp2T2, CI_pp2T2, pp2splineT2] = residualsFit(T2FUSignal, T2BSignal, dose{pt}.doseImg(maskT2>0), LET{pt}.dLETtot(maskT2>0), min(dose{pt}.doseImg(maskT2>0)), max(dose{pt}.doseImg(maskT2>0)), min(LET{pt}.dLETtot(maskT2>0)), max(LET{pt}.dLETtot(maskT2>0)));
%         coefficientsFA(iii,:) = pp2FA.coefs(:,1)';
        coefficientsFAa(iii,:) = pp2FA(1);
        coefficientsFAb(iii,:) = pp2FA(2);
        coefficientsFAc(iii,:) = pp2FA(3);
        CI_coefficientsFAa(iii,:) = CI_pp2FA(1,:);
        CI_coefficientsFAb(iii,:) = CI_pp2FA(2,:);
        CI_coefficientsFAc(iii,:) = CI_pp2FA(3,:);
        coefficientsT1a(iii,:) = pp2T1(1);
        coefficientsT1b(iii,:) = pp2T1(2);
        coefficientsT1c(iii,:) = pp2T1(3);
        CI_coefficientsT1a(iii,:) = CI_pp2T1(1,:);
        CI_coefficientsT1b(iii,:) = CI_pp2T1(2,:);
        CI_coefficientsT1c(iii,:) = CI_pp2T1(3,:);
        coefficientsT2a(iii,:) = pp2T2(1);
        coefficientsT2b(iii,:) = pp2T2(2);
        coefficientsT2c(iii,:) = pp2T2(3);
        CI_coefficientsT2a(iii,:) = CI_pp2T2(1,:);
        CI_coefficientsT2b(iii,:) = CI_pp2T2(2,:);
        CI_coefficientsT2c(iii,:) = CI_pp2T2(3,:);
        
        coefficientsFA(iii,:) = pp2splineFA.coefs(:,1)';
        coefficientsT1(iii,:) = pp2splineT1.coefs(:,1)';
        coefficientsT2(iii,:) = pp2splineT2.coefs(:,1)';
        iii = iii + 1;
    end
end
disp('done')
%% Plots
days = zeros(size(coefficientsFAa));
days(:,1) = [186,304,412,100,219,266,357,95,185,277,85,185,98,189,86,212];
days(:,2) = [186,304,412,100,219,266,357,95,185,277,85,185,98,189,86,212];
days(:,3) = [186,304,412,100,219,266,357,95,185,277,85,185,98,189,86,212];

% MS = 700; FS = 20;
% 
% figure('DefaultAxesFontSize',FS);
% xlim([0, 430]); ylim([-0.035, 0.035])
% hold on
% scatter(reshape(days(1:3,:),1,[]),reshape(coefficientsFA(1:3,:),1,[]),MS,[0, 0.4470, 0.7410],'.') % Patient 1
% scatter(reshape(days(4:7,:),1,[]),reshape(coefficientsFA(4:7,:),1,[]),MS,[0.8500, 0.3250, 0.0980],'.') % Patient 2
% scatter(reshape(days(8:10,:),1,[]),reshape(coefficientsFA(8:10,:),1,[]),MS,[0.9290, 0.6940, 0.1250],'.') % Patient 3
% scatter(reshape(days(11:12,:),1,[]),reshape(coefficientsFA(11:12,:),1,[]),MS,[0.4940, 0.1840, 0.5560],'.') % Patient 4
% scatter(reshape(days(13:14,:),1,[]),reshape(coefficientsFA(13:14,:),1,[]),MS,[0.4660, 0.6740, 0.1880],'.') % Patient 5
% scatter(reshape(days(15:16,:),1,[]),reshape(coefficientsFA(15:16,:),1,[]),MS,[0.3010, 0.7450, 0.9330],'.') % Patient 6
% 
% legend('Patient 1', 'Patient 2', 'Patient 3', 'Patient 4', 'Patient 5', 'Patient 6', 'Location', 'SouthEast')
% legendmarkeradjust(27)
% title('B-spline fit parameters for each patient')
% xlabel('Days since baseline scan')
% ylabel('Piece-wise slope of linear B-spline')
% hold off

combinedFA = zeros(16,1);
err_combinedFA = zeros(16,1);
combinedT1 = zeros(16,1);
err_combinedT1 = zeros(16,1);
combinedT2 = zeros(16,1);
err_combinedT2 = zeros(16,1);
for i=1:16
    combinedFA(i) = mean(coefficientsFA(i,:));
    err_combinedFA(i) = std(coefficientsFA(i,:));
    combinedT1(i) = mean(coefficientsT1(i,:));
    err_combinedT1(i) = std(coefficientsT1(i,:));
    combinedT2(i) = mean(coefficientsT2(i,:));
    err_combinedT2(i) = std(coefficientsT2(i,:));
end

% % Linear fit
% MS = 27; LW = 1; FS = 20;
% figure('DefaultAxesFontSize',FS);
% subplot(3,1,1)
% paramterePlot(days, coefficientsFAa, CI_coefficientsFAa, [50, 430], [-0.05, 2.6],MS,LW,FS,'FA parameters','','a_{FA}')
% subplot(3,1,2)
% paramterePlot(days, coefficientsFAb, CI_coefficientsFAb, [50, 430], [-0.007, 0.007],MS,LW,FS,'','','b_{FA}')
% subplot(3,1,3)
% paramterePlot(days, coefficientsFAc, CI_coefficientsFAc, [0, 430], [-0.002, 0.002],MS,LW,FS,'','Days since baseline scan','c_{FA}')
% legend('Patient 1', 'Patient 2', 'Patient 3', 'Patient 4', 'Patient 5', 'Patient 6', 'Location', 'SouthEast')
% legendmarkeradjust(MS)
% 
% figure('DefaultAxesFontSize',FS);
% subplot(3,1,1)
% paramterePlot(days, coefficientsT1a, CI_coefficientsT1a, [50, 430], [-0.5, 5],MS,LW,FS,'T1 parameters','','a_{T1}')
% subplot(3,1,2)
% paramterePlot(days, coefficientsT1b, CI_coefficientsT1b, [50, 430], [-2, 9],MS,LW,FS,'','','b_{T1}')
% subplot(3,1,3)
% paramterePlot(days, coefficientsT1c, CI_coefficientsT1c, [50, 430], [-2.5, 1.5],MS,LW,FS,'','Days since baseline scan','c_{T1}')
% legend('Patient 1', 'Patient 2', 'Patient 3', 'Patient 4', 'Patient 5', 'Patient 6', 'Location', 'SouthEast')
% legendmarkeradjust(MS)
% 
% figure('DefaultAxesFontSize',FS);
% subplot(3,1,1)
% paramterePlot(days, coefficientsT2a, CI_coefficientsT2a, [50, 430], [-1, 6],MS,LW,FS,'T2 parameters','','a_{T2}')
% subplot(3,1,2)
% paramterePlot(days, coefficientsT2b, CI_coefficientsT2b, [50, 430], [-6, 18],MS,LW,FS,'','','b_{T2}')
% subplot(3,1,3)
% paramterePlot(days, coefficientsT2c, CI_coefficientsT2c, [50, 430], [-2, 3],MS,LW,FS,'','Days since baseline scan','c_{T2}')
% legend('Patient 1', 'Patient 2', 'Patient 3', 'Patient 4', 'Patient 5', 'Patient 6', 'Location', 'SouthEast')
% legendmarkeradjust(MS)

% B-spline fit
MS = 27; LW = 1; FS = 20;
figure('DefaultAxesFontSize',FS);
paramterePlot(days, combinedFA, 1.96*[err_combinedFA,err_combinedFA], [50, 430], [-0.05, 0.05],MS,LW,FS,'B-spline fit to the FA scans','Days since baseline scan','Average slope of the B-Spline')
legend('Patient 1', 'Patient 2', 'Patient 3', 'Patient 4', 'Patient 5', 'Patient 6', 'Location', 'SouthEast')
legendmarkeradjust(MS)

figure('DefaultAxesFontSize',FS);
paramterePlot(days, combinedT1, 1.96*[err_combinedT1,err_combinedT1], [50, 430], [-1000, 1000],MS,LW,FS,'B-spline fit to the T1 scans','Days since baseline scan','Average slope of the B-Spline')
legend('Patient 1', 'Patient 2', 'Patient 3', 'Patient 4', 'Patient 5', 'Patient 6', 'Location', 'SouthEast')
legendmarkeradjust(MS)

figure('DefaultAxesFontSize',FS);
paramterePlot(days, combinedT2, 1.96*[err_combinedT2,err_combinedT2], [0, 430], [-500, 500],MS,LW,FS,'B-spline fit to the T2 scans','Days since baseline scan','Average slope of the B-Spline')
legend('Patient 1', 'Patient 2', 'Patient 3', 'Patient 4', 'Patient 5', 'Patient 6', 'Location', 'SouthEast')
legendmarkeradjust(MS)

