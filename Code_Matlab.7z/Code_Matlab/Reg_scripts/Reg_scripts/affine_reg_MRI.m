function [p3] = affine_reg_MRI(img1,img2,dimt1,dimt2,Smax,center,options)

%% Rigid registration

% Perform registration

% defining grid for resampling and registration
resolution=options.rigidRes;
[X1, X2, X3]=ndgrid(0:resolution:Smax(1),0:resolution:Smax(2),0:resolution:Smax(3));
pts=[X1(:), X2(:), X3(:)];

%vectorize images in 'resolution' resolution
Itrival=(SplineInterpolation_tbb(pts,img1,[0 0 0],dimt1));
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));

%initialize parameters to 0 for affine
p2=zeros(12,1);

% estimate centroid for both scans and initialize registration
[id]=kmeans(img2(:),2);
cls=reshape(id,size(img2));
cls=2-cls;
props2=regionprops(cls,'Centroid');
[id]=kmeans(img1(:),2);
cls=reshape(id,size(img1));
cls=2-cls;
props1=regionprops(cls,'Centroid');
cDiff = props1.Centroid.*dimt1 - props2.Centroid.*dimt2;
            
p2(4)=cDiff(2); p2(5)=cDiff(1); p2(6)=cDiff(3);

%using 1-norm
%include rotation
p2=minFunc(@cf_rigidNMI_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
%include scale
if(options.incl_scale)
    p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
end

%change parametrization from angles to.... matrix
[f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
p3=T(:);
p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);

%full affine 
%p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
%full symmetric affine registration
%p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1));