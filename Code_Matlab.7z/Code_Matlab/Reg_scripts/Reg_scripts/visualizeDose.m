function visualizeDose(img,dose,slice,dim,orient,minDose,maxDose,transLevel,imgColMap,windowLevel)

% Visualizes the dose distribution in 'dose' on top of the image contained
% in 'img'. Assumes that the image and the dose distribution are defined in
% the same frame and using the same grid / voxels.

% 'slice' is the slice number to be displayed
% 'dim' is a three-element vector containing the voxel sizes for the 
% dose/image grid.
% 'orient' is the orientation to be displayed (1=transversal, 2=sagital, 
% 3=coronal).
% 'minDose' is the (absolute) minimum dose level to be visualised in the
% dose distribution. All dose voxels with values below this are set to be
% fully transparant
% 'maxDose' is the (absolute) maximum level of the color scale; everything
% above this is uniformly red
% 'transLevel' is the transparance level (1=fully opaque, 0=fully
% transparant)
% 'imgColMap' is the ColorMap to be used for the background image
% (typically 'bone' or 'gray'
% 'windowLevel' allows for change of window level (standard is 1)

if nargin>9
    windowLevel=1;
end

% Define min and max values for x, y and z axes
x = [0,dim(1)*(size(img,1)-1)];
y = [0,dim(2)*(size(img,2)-1)];
z = [0,dim(3)*(size(img,3)-1)];

% Get colormaps
ctMap = CERRColorMap('graycenter0width300');
doseColorMap;

if orient==1
    figure;
    set(gcf,'InvertHardCopy','off')
    indImg = squeeze(gray2ind((img(:,:,slice)-min(min(img(:,:,slice))))/max(max(img(:,:,slice)))*windowLevel));
    eval(['bg = ind2rgb(indImg,' imgColMap ');']);
    %imagesc(x,y,bg); hold on, axis image
    imagesc(bg); hold on, axis image
    %hold on,
    % Create transparancy map for dose data
    alphaMap = (dose(:,:,slice)>=minDose)*transLevel;
    % Plot dose distribution
    %im = imagesc(x,y,dose(:,:,slice),'AlphaData',alphaMap,[20 70]);
    im = imagesc(dose(:,:,slice),'AlphaData',alphaMap,[20 maxDose]);
    colormap(map);
    colorbar;
elseif orient==2
    figure(1);
    set(gcf,'InvertHardCopy','off')
    indImg = squeeze(gray2ind((img(:,slice,:)-min(min(img(:,slice,:))))/max(max(img(:,slice,:)))*windowLevel));
    eval(['bg = ind2rgb(indImg,' imgColMap ');']);
    imagesc(x,-z,permute(bg,[2 1 3])); hold on, axis image
    %hold on,
    % Create transparancy map for dose data
    alphaMap = squeeze((dose(:,slice,:)>=minDose)*transLevel);
    % Plot dose distribution
    imagesc(x,-z,permute(squeeze(dose(:,slice,:)),[2 1]),'AlphaData',permute(alphaMap,[2 1]),[20 maxDose]);
    colormap(map);
    colorbar;
elseif orient==3
    figure(1);
    set(gcf,'InvertHardCopy','off')
    indImg = squeeze(gray2ind((img(slice,:,:)-min(min(img(slice,:,:))))/max(max(img(slice,:,:)))*windowLevel));
    eval(['bg = ind2rgb(indImg,' imgColMap ');']);
    imagesc(x,-z,permute(bg,[2 1 3])); hold on, axis image
    %hold on,
    % Create transparancy map for dose data
    alphaMap = squeeze((dose(slice,:,:)>=minDose)*transLevel);
    % Plot dose distribution
    imagesc(x,-z,permute(squeeze(dose(slice,:,:)),[2 1]),'AlphaData',permute(alphaMap,[2 1]),[20 maxDose]);
    colormap(map);
    colorbar;
else
    error('Orientation not well-defined (''orient'' variable must be set to 1, 2 or 3)')
end