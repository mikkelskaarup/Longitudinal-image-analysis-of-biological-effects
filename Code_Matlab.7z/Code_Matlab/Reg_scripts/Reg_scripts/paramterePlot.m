function paramterePlot(days, combined, err_combined, xlimit, ylimit, MS, LW, FS,titlelabel, xtitle, ytitle)
xlim(xlimit); ylim(ylimit)
hold on
pt1 = errorbar(days(1:3,1),combined(1:3),err_combined(1:3,1),err_combined(1:3,2)); % Patient 1
pt2 = errorbar(days(4:7,1),combined(4:7),err_combined(4:7,1),err_combined(4:7,2)); % Patient 2
pt3 = errorbar(days(8:10,1),combined(8:10),err_combined(8:10,1),err_combined(8:10,2)); % Patient 3
pt4 = errorbar(days(11:12,1),combined(11:12),err_combined(11:12,1),err_combined(11:12,2)); % Patient 4
pt5 = errorbar(days(13:14,1),combined(13:14),err_combined(13:14,1),err_combined(13:14,2)); % Patient 5
pt6 = errorbar(days(15:16,1),combined(15:16),err_combined(15:16,1),err_combined(15:16,2)); % Patient 6

pt1.Marker = '.'; pt2.Marker = '.'; pt3.Marker = '.'; pt4.Marker = '.'; pt5.Marker = '.'; pt6.Marker = '.';
pt1.MarkerSize = MS; pt2.MarkerSize = MS; pt3.MarkerSize = MS; pt4.MarkerSize = MS; pt5.MarkerSize = MS; pt6.MarkerSize = MS;
pt1.LineWidth = LW; pt2.LineWidth = LW; pt3.LineWidth = LW; pt4.LineWidth = LW; pt5.LineWidth = LW; pt6.LineWidth = LW;
pt1.Color = [0, 0.4470, 0.7410]; pt2.Color = [0.8500, 0.3250, 0.0980]; pt3.Color = [0.9290, 0.6940, 0.1250]; pt4.Color = [0.4940, 0.1840, 0.5560]; pt5.Color = [0.4660, 0.6740, 0.1880]; pt6.Color = [0.3010, 0.7450, 0.9330];
title(titlelabel)
xlabel(xtitle)
ylabel(ytitle)
hold off