% Settings
BsplineOptions.Method='lbfgs';
BsplineOptions.display = 'full';
BsplineOptions.MaxIter=200;
BsplineOptions.MaxFunEvals=500;
BsplineOptions.TolFun=10^(-8);
BsplineOptions.TolX=10^(-8);
BsplineOptions.numDiff=0;
BsplineOptions.DerivativeCheck='off';
BsplineOptions.MaxIter = 30;
BsplineOptions.Corr = 30;
%
warning off all


j = 1;
dpath=fullfile(ipath,patients{j});

%%

followups = dir(fullfile(dpath,'FU*'));

% Loop over studies
for st = 1:length(followups)+1
    fileNames = [];
    if st == 1
        try
            load(fullfile(dpath,'plan.mat'),'pt');
            planExists = true;
        catch
            planExists = false;
        end
        study = dir(fullfile(dpath,'Baseline*'));
        study = study.name;
%         get filenames
        t1s = dir(fullfile(dpath,study,'*T1*'));
        for t1 = 1:length(t1s)
            fileNames{length(fileNames)+1} = fullfile(dpath,study,t1s(t1).name);
        end
        t2s = dir(fullfile(dpath,study,'*T2*'));
        for t2 = 1:length(t2s)
            fileNames{length(fileNames)+1} = fullfile(dpath,study,t2s(t2).name);
        end
%         get nifty-filenames in Baseline/FU-folder.
        nifties = dir(fullfile(dpath,study,'*.nii*'));
        for nifty = 1:length(nifties)
            fileNames{length(fileNames)+1} = fullfile(dpath,study,nifties(nifty).name);
        end
        dummyBaselinefileNames = fileNames;
    else
        study = followups(st-1).name;
        t1s = dir(fullfile(dpath,study,'*T1*'));
        for t1 = 1:length(t1s)
            fileNames{length(fileNames)+1} = fullfile(dpath,study,t1s(t1).name);
        end
        t2s = dir(fullfile(dpath,study,'*T2*'));
        for t2 = 1:length(t2s)
            fileNames{length(fileNames)+1} = fullfile(dpath,study,t2s(t2).name);
        end
%         get nifty-filenames in Baseline/FU-folder.
        nifties = dir(fullfile(dpath,study,'*.nii*'));
        for nifty = 1:length(nifties)
            fileNames{length(fileNames)+1} = fullfile(dpath,study,nifties(nifty).name);
        end
    end
    
%     Create a folder for output data with a similar structure, but titled
%     'DIKU-RH'
    outpath = fileparts(strrep(fileNames{1},'Img data','DIKU-RH'));
    if ~exist(outpath,'file')
        mkdir(outpath)
    end
    
%     Create brain structure, i.e. a single object containing all data from
%     a scan session
    N=length(fileNames);
    brain = struct([]);
    if st==1
%         Check if plan file exists in patient folder. This is a .mat
%         object that contains doseplan, LET-distribution and CT scan. If
%         it exists, make room for the CT scan to be included in the
%         brain.mat file
        if planExists
            dims = zeros(N+1,3);
            S = zeros(N+1,3);
        else
            dims = zeros(N,3);
            S = zeros(N,3);
        end
    else
        dims = zeros(N,3);
        S = zeros(N,3);
    end
    BSplineResolution = 1;
%     read images
    for i = 1:N
%       If the current session is NOT a baseline session AND stored in the .nii format (we stored our FA scans in .nii as compared to dicom
%       images for T1/T2 MRIs). NOTE: ONLY 3D nifty volumes are accepted.
%       In line 101-105 we have a bit of code to select a single volume out
%       of a 4D image structure (because we only needed the first entry).
%       If you need something similar, uncomment line 101-105 and comment
%       line 106.
        if strcmp(fileNames{i}(length(fileNames{i})-3:length(fileNames{i})),'.nii')
            Stemp = load_nii(fileNames{i});
            if length(size(Stemp.img)) == 4
                Stemp.vol = double(Stemp.img(:,:,:,1));
            else
                Stemp.vol = double(Stemp.img);
            end
%             Stemp.vol = double(Stemp.img);
%           Orient .nii-scans similarly to .dcm scans
            Stemp.vol = permute(Stemp.vol,[2 1 3]);
            Stemp.vol = imrotate(Stemp.vol,180);
            Stemp.VoxelDimension = Stemp.hdr.dime.pixdim(2:4);
            brain(i).img = Stemp.vol;
            dims(i,:) = Stemp.VoxelDimension;
            S(i,:) = size(Stemp.vol);
            
%           create bimg, the image to be used for registrations where all
%           intensities have been rebinned to 0 to 160 values. img is then later
%           transformed using the bimg registrations.
            Siztemp=S(i,:)-1;
            [X1, X2, X3]=ndgrid(0:BSplineResolution:Siztemp(1),0:BSplineResolution:Siztemp(2),0:BSplineResolution:Siztemp(3));
            pts=[X1(:) X2(:) X3(:)];
            p=zeros(size(brain(i).img));
            p2=minFunc(@cf_fitBspline,p(:),BsplineOptions,pts,brain(i).img,[0 0 0]+1e-8);
            brain(i).bimg=reshape(p2, size(brain(i).img));
            % rebin to values [0;160]
            brain(i).bimg=brain(i).bimg-min(brain(i).bimg(:));
            brain(i).bimg=brain(i).bimg/max(brain(i).bimg(:))*160;
%       If the scan session is stored in a dicom-format:
        else
            Stemp=loadDicomFiles(fileNames{i},'showwaitbar',0,'precision','double');
            
            brain(i).img = Stemp.vol;
            % fit bspline
            S(i,:)=size(brain(i).img);
            Siztemp=S(i,:)-1;
            [X1, X2, X3]=ndgrid(0:BSplineResolution:Siztemp(1),0:BSplineResolution:Siztemp(2),0:BSplineResolution:Siztemp(3));
            pts=[X1(:) X2(:) X3(:)];
            p=zeros(size(brain(i).img));
            p2=minFunc(@cf_fitBspline,p(:),BsplineOptions,pts,brain(i).img,[0 0 0]+1e-8);
            brain(i).bimg=reshape(p2, size(brain(i).img));
            % rebin to values [0;160]
            brain(i).bimg=brain(i).bimg-min(brain(i).bimg(:));
            brain(i).bimg=brain(i).bimg/max(brain(i).bimg(:))*160;
            % store pixel dimension
            dims(i,:) = Stemp.VoxelDimension;
        end
    end
    % Save CT scan with baseline imaging
    if st==1
        if planExists
            % Load RT plan data
            brain(N+1).img = pt(1).ct.X;
            % Set bspline resolution to lower than for MRIs to prevent memory
            % problems
            BSplineResolution = 1;
            % Rescale to make sure that there are no negative values
            rescaleImg = brain(N+1).img-min(brain(N+1).img(:));
            % Fit bspline
            S(N+1,:)=size(brain(N+1).img);
            Siztemp=S(N+1,:)-1;
            [X1, X2, X3]=ndgrid(0:BSplineResolution:Siztemp(1),0:BSplineResolution:Siztemp(2),0:BSplineResolution:Siztemp(3));
            pts=[X1(:) X2(:) X3(:)];
            p=zeros(size(brain(N+1).img));
            p2=minFunc(@cf_fitBspline,p(:),BsplineOptions,pts,rescaleImg,[0 0 0]+1e-8);
            brain(N+1).bimg=reshape(p2, size(brain(N+1).img));
            % rebin to values [0;160]
            brain(N+1).bimg=brain(N+1).bimg-min(brain(N+1).bimg(:));
            brain(N+1).bimg=brain(N+1).bimg/max(brain(N+1).bimg(:))*160;
            % store pixel dimension
            dims(N+1,:) = pt(1).ct.dx;
        end
    end
    save(fullfile(outpath,'brain'),'brain','dims','S');
end
