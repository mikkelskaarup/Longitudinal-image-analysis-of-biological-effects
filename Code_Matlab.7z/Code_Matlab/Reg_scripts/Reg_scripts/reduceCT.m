% Script to reduce CT scan to smaller volume (to prevent memory problems)

% Number of voxels to reduce scan from "top" and "bottom"
x1 = 0; y1 = 127; z1 = 258;% x1 = 30; y1 = 30; z1 = 200;
x2 = 212; y2 = 128; z2 = 26;% x2 = 30; y2 = 30; z2 = 0;

% Save CT in temp structure
ct = pt(1).ct;

% Reduce actual image
ct.X = ct.X((x1+1):(size(ct.X,1)-x2),(y1+1):(size(ct.X,2)-y2),(z1+1):(size(ct.X,3)-z2));

% Update the remaining settings
ct.pos = [ct.pos(1)+ct.dx(1)*x1,ct.pos(2)+ct.dx(2)*y1,ct.pos(3)+ct.dx(3)*z1];
ct.x0 = [ct.x0(1)+ct.dx(1)*x1,ct.x0(2)+ct.dx(2)*y1,ct.x0(3)+ct.dx(3)*z1];
ct.xn = [ct.xn(1)-ct.dx(1)*x2,ct.xn(2)-ct.dx(2)*y2,ct.xn(3)-ct.dx(3)*z2];
ct.n = size(ct.X);

% Update plan with new CT
pt(1).ct = ct;