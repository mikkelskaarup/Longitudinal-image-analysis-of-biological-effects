% Resample dose in hybrid frame
resample_dose

%Create a doseaveraged LET for analysis (dLETtot)
dLETtot = zeros(size(doseImg));
dosePhaseTot = zeros(size(doseImg));
for i=1:nPh
    eval(['dLETtot = dLETtot + dLETDosePhase' num2str(i) ';'])
    eval(['dosePhaseTot = dosePhaseTot + dosePhase' num2str(i) ';'])
end
dLETtot = dLETtot./dosePhaseTot;

% Define the brain mask
strMask = masks(str).mask;

findFAcutoff;% cutoffValue = 0; %Cut-off based on gaussian fit to the lowest peak in a frequency histogram of voxel values. Voxels above mean + 2 sigma of this fit is considered an FA signal

%Create mask of normal appearing white matter (WM), i.e. the brain mask
%minus the clinically delineated GTV. Additionally, include only voxels above the noise level in
%the FA image as this modality images WM tracts.
strGTV = [9,34,3,34,4,34]; %PT1 = 16    Pt2 = 34    Pt3 = 3    Pt4 = 34    Pt5 = 4    Pt6 = 34
strMaskGTV = masks(strGTV(str2double(patients{1}))).mask;

strMaskWM = zeros(size(strMask));
eval(['strMaskWM(strMask.*imI' num2str(N_I) ' > cutoffValue & strMaskGTV == 0) = 1;']);
% This mask was used to calculate normal appearing WM values by taking the mean of FA, T1 and T2 image values where the mask is non-zero

%Save data for analysis
% save(['Data\mask' num2str(patients{j}) '.mat'], 'strMask')
% save(['Data\dose' num2str(patients{j}) '.mat'], 'doseImg')
% save(['Data\LET' num2str(patients{j}) '.mat'], 'dLETtot')
% save(['Data\FABase' num2str(patients{j}) '.mat'], ['imI' num2str(N_I)'])
% save(['Data\FAFU' num2str(patients{j}) '-' num2str(studyJ-1) '.mat'], ['imJ' num2str(N_J) 'NR'])
% save(['Data\T1Base' num2str(patients{j}) '.mat'], 'imI1')
% save(['Data\T1FU' num2str(patients{j}) '-' num2str(studyJ-1) '.mat'], 'imJ1NR')
% save(['Data\T2Base' num2str(patients{j}) '.mat'], 'imI4')
% save(['Data\T2FU' num2str(patients{j}) '-' num2str(studyJ-1) '.mat'], 'imJ3NR')
