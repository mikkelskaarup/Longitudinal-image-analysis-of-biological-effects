function [dosePhase,dLETPhase,dLETDosePhase,nFr,nB,nPh] = PhaseDose(pt,model,ab)

%%  Function detail

% Function for correcting dose with LET-dependent RBE to get equivalent photon dose
% Note that dose provided by MDACC MC calculations (and TPS) is CGE, i.e.
% physical dose multiplied by 1.1. Thus dose distributions need to be 
% corrected with a factor 1/1.1 to get the physical dose

% Input are "pt" object which contains the treatment plan object as
% provided by MDACC, and the model to be used:
%   0 = no model (use standard RBE=1.1). This is the default option.
%   1 = Carabe et al (2012)
%   2 = Wedenberg et al (2013)
%   3 = McNamara et al (2015)
% (Missing! 2017 MDACC model)
% ab represents the alpha/beta value of the tissue in question and is
% currently the only variable parameter for input.

% Output are 
%   doseTot = total dose with standard RBE of 1.1
%   doseTotCorr = total dose corrected for variable RBE
% which are all "image" objects containing the relevant dose distributions
% Additional outputs "dLET" and "dose" contain dose and LET information per
% beam and per phase for nPh phases of nF fractions with nB beams delivered

% For alpha/beta, suggested value for brainstem is 2.1; 
% See Giantsoudi et al, where alpha ~0.0425 Gy(-1) and beta ~0.0203 Gy(-2)

%% Models

switch model
    case 1 % Carabel et al
        p0 = 0.843;
        p1 = 0.154;
        p2 = 2.686;
        p3 = 1.09;
        p4 = 0.006;
        RBEmax = @(x)(p0 + x*p1*p2/ab);
        RBEmin = @(x)(p3 + x*p4*p2/ab);
    case 2 % Wedenberg et al
        p2 = 0.434;
        RBEmax = @(x)(1 + x*p2/ab);
        RBEmin = @(x)(1);
    case 3 % McNamara et al
        p0 = 0.99064;
        p1 = 0.35605;
        p2 = 1.1012;
        p3 = -0.0038703;
        RBEmax = @(x)(p0 + x*p1/ab);
        RBEmin = @(x)(p2 + x*p3*sqrt(ab));
    otherwise
        RBEmax = @(x)(1.1);
        RBEmin = @(x)(1.1);
end

% LET model from MDACC cell data
%LETmodel = @(b,x)(b(1)*x.^b(2)+1);
%LETmodel = @(b,x)(b(1)*exp(b(2)*x)+1);
%alphaModel = LETmodel;
%betaModel= LETmodel;
% Set model parameters
%b = [0.013,0.3];
% Note that adding a multiplicative constant of 1.132 to the LET model
% ensures that RBE=1.1 at low LET (~1), for alphabeta=2.1, at 1.82 Gy / fr
%const = 1.132;
%LETmodel = @(b,x)(const*(b(1)*exp(b(2)*x)+1));
%alphaModel = LETmodel;
%betaModel= LETmodel;

% RBE (dose correction) formula
RBEmodel = @(fr,dose,LET)(-fr.*0.5*ab./dose+(fr./dose).*sqrt(0.25.*ab.^2+ab.*RBEmax(LET).*dose./fr+(RBEmin(LET)).^2.*(dose./fr).^2));

% EQDx (equivalent dose in X Gray per fraction) formula
X = 2;
EQDx = @(fr,dose,LET)(dose.*(ab.*RBEmax(LET)+(dose./fr).*(RBEmin(LET)).^2)./(ab+X));

%% Dose correction

% Get number of phases (primary, boost, etc) to plan
nPh = size(pt,2);
% Get number of fractions for each phase
for i=1:nPh
    nFr(i) = pt(i).plan.nFr;
end
% Get number of beams per phase
for i=1:nPh
    nB(i) = size(pt(i).plan.beam,2);
end

% if patients{1} == '1'
%    nB=[2 2 2 2];
% end

% Save dose for each beam in seperate structure
% Divide by factor 1.1 to get physical dose from CGE
for i=1:nPh
    if i > 1 && sum(size(pt(1).dMC(1).imd) ~= size(pt(i).dMC(1).imd)) > 0
        for j=1:nB(i)
            fixDoseMatrixSize; %Standardise dose matrix size if multiple phases
        end
    end
end
dose = zeros([nPh,max(nB),size(pt(1).dMC(1).imd)]);
for i=1:nPh
    for j=1:nB(i)
%         dose(i,j,:,:,:) = (1/1.1)*pt(i).dMC(j).imd;% <- RBE corrected dose
        dose(i,j,:,:,:) = pt(i).dMC(j).imd;% <- Physical dose
    end
end

% Save LET for each beam in seperate structure
let = zeros([nPh,max(nB),size(pt(1).dMC(1).imd)]);
for i=1:nPh
    for j=1:nB(i)
        let(i,j,:,:,:) = pt(i).let(j).imd;
%         ddLET(:,:,:) = sum(let(i,j,:,:,:).*dose(i,j,:,:,:),2)./sum(dose(i,j,:,:,:),2);
    end
end

% Calculate dose averaged LET for each plan phase
dLET = zeros([nPh,size(pt(1).dMC(1).imd)]);

for i=1:nPh
    dLET(i,:,:,:) = sum(let(i,:,:,:,:).*dose(i,:,:,:,:),2)./sum(dose(i,:,:,:,:),2);
end

% Correct dose matrix for each phase (with type of correction depending on
% doseOut input)
for i=1:nPh
    dosePhase(i).imd = squeeze(sum(dose(i,:,:,:,:),2));
    dLETPhase(i).imd = squeeze(dLET(i,:,:,:));
    dLETDosePhase(i).imd = dLETPhase(i).imd.*dosePhase(i).imd;
end

