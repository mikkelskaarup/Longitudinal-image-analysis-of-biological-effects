eval(['FA = imI' num2str(N_I) '.*strMask;']);
[xhist, yhist] = hist(FA(FA>0),200);
f = fit(yhist(1:find(xhist==max(xhist))).',xhist(1:find(xhist==max(xhist))).','a*exp(-((x - b)./c).^2)','StartPoint',[max(xhist),0.1,0.05]);
cutoffValue = f.b+2*f.c;
% plot(f,yhist(1:26).',xhist(1:26).')
% xhisttemp = xhist;
% xhisttemp = xhisttemp - f.a*exp(-((yhist-f.b)./f.c).^2);
% figure;
% plot(f,yhist.',xhist.')
% hold on
% plot(yhist.',xhisttemp.','g-')
% plot([f.b+f.c, f.b+f.c],[0,40000],'k-')
% plot([f.b+2*f.c, f.b+2*f.c],[0,40000],'k-')
% plot([f.b+3*f.c, f.b+3*f.c],[0,40000],'k-')
% f
% f.b+sqrt(f.c)/2
% f.b+2*sqrt(f.c)/2
% hold off