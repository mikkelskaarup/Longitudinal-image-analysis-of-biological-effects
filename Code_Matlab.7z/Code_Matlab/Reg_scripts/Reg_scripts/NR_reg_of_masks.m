N_CT = idxMinI;

for ii = 1:length(masks)
    ptsI_hybridAff = do_sym_affine(I_aff(:,N_CT),pointsI,Icenter);
    masks(ii).mask = reshape(SplineInterpolation(ptsI_hybridAff,masks(ii).mask,offsetI(:,N_CT),scaleI(N_CT,:)),size(XI1));
end