% Evaluate Hybrid template registration
%clear all;close all;
ipath = '/Users/appelt/Dropbox/Work/Projekter/DTI projekt/DTI data/DIKU-RH/';
patient = '2';
studies = listSubFolders(fullfile(ipath,patient));

studyI = 1;
studyJ = 3;
warpSize = 10;
resolution=[1 1 1];
%% Load global affine
load(fullfile(ipath,patient,['aff_global_' num2str(studyJ) '_to_' num2str(studyI)]))
if ~exist('aff_global','var')
    aff_global = p3;
end
if ~exist('center_global','var')
    center_global = center;
end
%% Load scan I
load(fullfile(ipath,patient,studies{studyI},'brain.mat'))
load(fullfile(ipath,patient,studies{studyI},'p3all.mat'))
HTI = brain;
N_I = length(brain);
offsetI = offset;
I_aff = p3all;
scaleI = dims;
imageSizes = S.*dims;
[~,idxMinI] = min(imageSizes(:,3));
S2 = imageSizes(idxMinI,:);
%define center of rotation (mm from corner of img1)
Icenter=[floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)];
[XI1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsI=[XI1(:) X2(:) X3(:)];

if N_I>0
    % Transform points from image to hybridTemplate I
    ptsI_hybridAff = do_sym_affine(I_aff(:,1),pointsI,Icenter);
    % Interpolate image in hybridTemplate I frame
    imI1 = reshape(SplineInterpolation(ptsI_hybridAff,HTI(1).bimg,offsetI(:,1),scaleI(1,:)),size(XI1));
end
if N_I>1
    % Transform points from image to hybridTemplate I
    ptsI_hybridAff = do_sym_affine(I_aff(:,2),pointsI,Icenter);
    % Interpolate image in hybridTemplate I frame
    imI2 = reshape(SplineInterpolation(ptsI_hybridAff,HTI(2).bimg,offsetI(:,2),scaleI(2,:)),size(XI1));
end
if N_I>2
    % Transform points from image to hybridTemplate I
    ptsI_hybridAff = do_sym_affine(I_aff(:,3),pointsI,Icenter);
    % Interpolate image in hybridTemplate I frame
    imI3 = reshape(SplineInterpolation(ptsI_hybridAff,HTI(3).img,offsetI(:,3),scaleI(3,:)),size(XI1));
end
if N_I>3
    % Transform points from image to hybridTemplate I
    ptsI_hybridAff = do_sym_affine(I_aff(:,4),pointsI,Icenter);
    % Interpolate image in hybridTemplate I frame
    imI4 = reshape(SplineInterpolation(ptsI_hybridAff,HTI(4).img,offsetI(:,4),scaleI(4,:)),size(XI1));
end
if N_I>4
    % Transform points from image to hybridTemplate I
    ptsI_hybridAff = do_sym_affine(I_aff(:,5),pointsI,Icenter);
    % Interpolate image in hybridTemplate I frame
    imI5 = reshape(SplineInterpolation(ptsI_hybridAff,HTI(5).img,offsetI(:,5),scaleI(5,:)),size(XI1));
end

%% Load scan J
load(fullfile(ipath,patient,studies{studyJ},'brain.mat'))
load(fullfile(ipath,patient,studies{studyJ},'p3all.mat'))
if exist(fullfile(ipath,patient,['NR_warp_' num2str(studyJ) '_to_' num2str(studyI) '.mat']),'file')
    load(fullfile(ipath,patient,['NR_warp_' num2str(studyJ) '_to_' num2str(studyI) '_warpsize_' num2str(warpSize) '.mat']))
end
HTJ = brain;
N_J = length(brain);
offsetJ = offset;
J_aff = p3all;
scaleJ = dims;
imageSizes = S.*dims;
[~,idxMinJ] = min(imageSizes(:,3));
S2 = imageSizes(idxMinJ,:);
%define center of rotation (mm from corner of img1)
Jcenter= [floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)];

ww = [warpSize warpSize warpSize];
%ww=[40 40 40];
offset2 = -ww;

[XJ1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsJ=[XJ1(:) X2(:) X3(:)];

if N_J>0
    % Transform points from image to hybridTemplate I
    ptsJ_hybridAff = do_sym_affine(J_aff(:,1),pointsJ,Jcenter);
    % Interpolate image in hybridTemplate I frame
    imJ1 = reshape(SplineInterpolation(ptsJ_hybridAff,HTJ(1).bimg,offsetJ(:,1),scaleJ(1,:)),size(XJ1));
end
if N_J>1
    % Transform points from image to hybridTemplate I
    ptsJ_hybridAff = do_sym_affine(J_aff(:,2),pointsJ,Jcenter);
    % Interpolate image in hybridTemplate I frame
    imJ2 = reshape(SplineInterpolation(ptsJ_hybridAff,HTJ(2).bimg,offsetJ(:,2),scaleJ(2,:)),size(XJ1));
end
if N_J>2
    % Transform points from image to hybridTemplate I
    ptsJ_hybridAff = do_sym_affine(J_aff(:,3),pointsJ,Jcenter);
    % Interpolate image in hybridTemplate I frame
    imJ3 = reshape(SplineInterpolation(ptsJ_hybridAff,HTJ(3).img,offsetJ(:,3),scaleJ(3,:)),size(XJ1));
end
if N_J>3
    % Transform points from image to hybridTemplate I
    ptsJ_hybridAff = do_sym_affine(J_aff(:,4),pointsJ,Jcenter);
    % Interpolate image in hybridTemplate I frame
    imJ4 = reshape(SplineInterpolation(ptsJ_hybridAff,HTJ(4).img,offsetJ(:,4),scaleJ(4,:)),size(XJ1));
end
if N_J>4
    % Transform points from image to hybridTemplate I
    ptsJ_hybridAff = do_sym_affine(J_aff(:,5),pointsJ,Jcenter);
    % Interpolate image in hybridTemplate I frame
    imJ5 = reshape(SplineInterpolation(ptsJ_hybridAff,HTJ(5).img,offsetJ(:,5),scascaleJleI(5,:)),size(XJ1));
end

% Transform points I through to Hybrid J
% Non-rigid
ptsI_NR = SS_Trap_1st(pointsI,pp4,offset2,ww,double(40),double(5));
ptsI_NR_globalAff = do_sym_affine(aff_global,ptsI_NR,center_global);
% Affine only
ptsI_globalAff = do_sym_affine(aff_global,pointsI,center_global);

if N_J>0
    ptsI_NR_globalAff_hybridAff = do_sym_affine(J_aff(:,1),ptsI_NR_globalAff,Jcenter);
    ptsI_globalAff_hybridAff = do_sym_affine(J_aff(:,1),ptsI_globalAff,Jcenter);
    imJ1NR = reshape(SplineInterpolation(ptsI_NR_globalAff_hybridAff,HTJ(1).img,offsetJ(:,1),scaleJ(1,:)),size(XI1));
    imJ1aff = reshape(SplineInterpolation(ptsI_globalAff_hybridAff,HTJ(1).img,offsetJ(:,1),scaleJ(1,:)),size(XI1));
end
if N_J>1
    ptsI_NR_globalAff_hybridAff = do_sym_affine(J_aff(:,2),ptsI_NR_globalAff,Jcenter);
    ptsI_globalAff_hybridAff = do_sym_affine(J_aff(:,2),ptsI_globalAff,Jcenter);
    imJ2NR = reshape(SplineInterpolation(ptsI_NR_globalAff_hybridAff,HTJ(2).img,offsetJ(:,2),scaleJ(2,:)),size(XI1));
    imJ2aff = reshape(SplineInterpolation(ptsI_globalAff_hybridAff,HTJ(2).img,offsetJ(:,2),scaleJ(2,:)),size(XI1));
end
if N_J>2
    ptsI_NR_globalAff_hybridAff = do_sym_affine(J_aff(:,3),ptsI_NR_globalAff,Jcenter);
    ptsI_globalAff_hybridAff = do_sym_affine(J_aff(:,3),ptsI_globalAff,Jcenter);
    imJ3NR = reshape(SplineInterpolation(ptsI_NR_globalAff_hybridAff,HTJ(3).img,offsetJ(:,3),scaleJ(3,:)),size(XI1));
    imJ3aff = reshape(SplineInterpolation(ptsI_globalAff_hybridAff,HTJ(3).img,offsetJ(:,3),scaleJ(3,:)),size(XI1));
end
if N_J>3
    ptsI_NR_globalAff_hybridAff = do_sym_affine(J_aff(:,4),ptsI_NR_globalAff,Jcenter);
    ptsI_globalAff_hybridAff = do_sym_affine(J_aff(:,4),ptsI_globalAff,Jcenter);
    imJ4NR = reshape(SplineInterpolation(ptsI_NR_globalAff_hybridAff,HTJ(4).img,offsetJ(:,4),scaleJ(4,:)),size(XI1));
    imJ4aff = reshape(SplineInterpolation(ptsI_globalAff_hybridAff,HTJ(4).img,offsetJ(:,4),scaleJ(4,:)),size(XI1));
end
if N_J>4
    ptsI_NR_globalAff_hybridAff = do_sym_affine(J_aff(:,5),ptsI_NR_globalAff,Jcenter);
    ptsI_globalAff_hybridAff = do_sym_affine(J_aff(:,5),ptsI_globalAff,Jcenter);
    imJ5NR = reshape(SplineInterpolation(ptsI_NR_globalAff_hybridAff,HTJ(5).img,offsetJ(:,5),scaleJ(5,:)),size(XI1));
    imJ5aff = reshape(SplineInterpolation(ptsI_globalAff_hybridAff,HTJ(5).img,offsetJ(:,5),scaleJ(5,:)),size(XI1));
end

DIKUview('imI1','imJ1aff')
