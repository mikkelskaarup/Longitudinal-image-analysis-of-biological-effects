% Settings
options.Method='lbfgs';
options.display = 'full';
options.MaxIter=400;
options.MaxFunEvals=700;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

%
warning off all
studies = listSubFolders(fullfile(ipath,patients{j}));

%% Define scan I
load(fullfile(ipath,patients{j},studies{studyI},'brain.mat'))
load(fullfile(ipath,patients{j},studies{studyI},'p3all.mat'))

N = length(brain);
imageSizes = S.*dims;
HTI = brain;
scaleI = dims;
offsetI = offset;
I_aff = p3all;
[~,idxMinI] = min(imageSizes(:,3));

% Smallest image (in mm)
Smin = imageSizes(idxMinI,:);
% Define center of rotation
Icenter= repmat([floor(Smin(1)/2) floor(Smin(2)/2) floor(Smin(3)/2)],N,1);

% Create resolution grid
resolution=[1 1 1]*2;
[XI1, X2, X3]=ndgrid(0:resolution(1):Smin(1)-resolution(1),0:resolution(2):Smin(2)-resolution(2),0:resolution(3):Smin(3)-resolution(3));
pointsI=[XI1(:) X2(:) X3(:)];

%Perform timepoint I affine registration
Itrival = zeros(size(pointsI,1),size(HTI,2));
for k=size(HTI,2)
    ptsI = do_sym_affine(I_aff(:,k),pointsI,Icenter(k,:));
    Itrival(:,k) = (SplineInterpolation(ptsI,HTI(k).bimg,offsetI(:,k),scaleI(k,:)));
end

%% Define scan J
load(fullfile(ipath,patients{j},studies{studyJ},'brain.mat'))
load(fullfile(ipath,patients{j},studies{studyJ},'p3all.mat'))

N = length(brain);
imageSizes = S.*dims;
HTJ = brain;
scaleJ = dims;
offsetJ = offset;
J_aff = p3all;
[~,idxMinJ] = min(imageSizes(:,3));
Smin = imageSizes(idxMinJ,:);
% Define center of rotation
Jcenter= repmat([floor(Smin(1)/2) floor(Smin(2)/2) floor(Smin(3)/2)],N,1);

resolution=[1 1 1]*2;
[XJ1, X2, X3]=ndgrid(0:resolution(1):Smin(1)-resolution(1),0:resolution(2):Smin(2)-resolution(2),0:resolution(3):Smin(3)-resolution(3));
pointsJ=[XJ1(:) X2(:) X3(:)];

%Perform timepoint J affine registration
Jtrival = zeros(size(pointsJ,1),size(HTJ,2));
for k=size(HTJ,2)
    ptsJ = do_sym_affine(J_aff(:,k),pointsJ,Jcenter(k,:));
    Jtrival(:,k) = (SplineInterpolation(ptsJ,HTJ(k).bimg,offsetJ(:,k),scaleJ(k,:)));
end

%% T2 (or T1) timepoint 1 to T2 (or T1) timepoint 2, followed by full multimodal registration

% Choose image index for initial registration (for most patients in our setup: n=1: T1, n=3: T2)
% Alternatively, make sure to pick the smallest image at the two timepoints
nI = idxMinI; nJ=idxMinJ;

%Setting various parameters
dimt1 = scaleI(nI,:);
dimt2 = scaleJ(nJ,:);
img1 = HTI(nI).bimg;
img2 = HTJ(nJ).bimg;

Jval=(SplineInterpolation(pointsJ,img2,[0 0 0],dimt2));
T2orig = reshape(Jval,size(XJ1));

%initialize parameters to 0 for affine
p2=zeros(12,1);
%using 1-norm
center = Jcenter(idxMinJ,:);
%perform translation initialization
p2=minFunc(@cf_rigidNMI_3dPW_NR,p2(:),options,img1,pointsJ,center,Jval,dimt1,ones(size(pointsJ,1),1));
%include rotation
p2=minFunc(@cf_rigidNMI_3dPW,p2(:),options,img1,pointsJ,center,Jval,dimt1,ones(size(pointsJ,1),1));

%change parametrization from angles to.... matrix
[f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pointsJ,center,Jval,dimt1,ones(size(pointsJ,1),1));
p3=T(:);
p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);
    
p(1:9) = [1 0 0 0 1 0 0 0 1];
p(10:12) = - p3(10:12);

%Perform final affine registrations (this time between timepoints, as a
%basis for the deformable registration to come in "Register_RH_Hybrid_NR")
detI = ones(size(pointsI,1),1);
detJ = ones(size(pointsJ,1),1);
center = Jcenter(idxMinJ,:);
comp_vec = [idxMinI idxMinJ];
pGlobalInit=minFunc(@cf_sym_affine_NMI_MultiModal3,p',options, HTI, HTJ,pointsI, pointsJ,center, Itrival,Jtrival,scaleI,scaleJ,detI,detJ,I_aff,J_aff,Icenter,Jcenter,offsetI,offsetJ,comp_vec);
save(fullfile(ipath,patients{j},studies{studyJ},'pInit_toBaseline'),'pGlobalInit')

[~,pts3] = do_sym_affine(pGlobalInit,pointsJ,center);
Jval=(SplineInterpolation(pts3,img1,[0 0 0],dimt1));
T2trans = reshape(Jval,size(XJ1));

[Ii, Jj]=ndgrid(1:size(HTI,2),1:size(HTJ,2));
comp_vec=[Ii(:) Jj(:)];
p3=minFunc(@cf_sym_affine_NMI_MultiModal3,pGlobalInit,options, HTI, HTJ,pointsI, pointsJ,center, Itrival,Jtrival,scaleI,scaleJ,detI,detJ,I_aff,J_aff,Icenter,Jcenter,offsetI,offsetJ,comp_vec);

center_global = center;
aff_global = p3;
save(fullfile(ipath,patients{j},studies{studyJ},'pGlobal_toBaseline'),'aff_global','center_global')
