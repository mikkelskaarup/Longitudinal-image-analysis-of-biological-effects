%ipath = '/Volumes/DTI-project/Img Data';
ipath = '/Users/appelt/Dropbox/Work/Projekter/DTI projekt/DTI data/Img Data';

BsplineOptions.Method='lbfgs';
BsplineOptions.display = 'full';
BsplineOptions.MaxIter=200;
BsplineOptions.MaxFunEvals=500;
BsplineOptions.TolFun=10^(-8);
BsplineOptions.TolX=10^(-8);
BsplineOptions.numDiff=0;
BsplineOptions.DerivativeCheck='off';
BsplineOptions.MaxIter = 30;
BsplineOptions.Corr = 30;
%
warning off all

patients = {'2'};

j = 1;
dpath=fullfile(ipath,patients{j});

%%

followups = dir(fullfile(dpath,'FU*'));

% Loop over studies
for st = 1:length(followups)+1
    fileNames = [];
    if st == 1
        study = dir(fullfile(dpath,'Baseline*'));
        study = study.name;
        % get filenames
        f = dir(fullfile(dpath,study,'*T1*iso*'));
        fileNames{1} = fullfile(dpath,study,f(1).name);
        
        %t2s = dir(fullfile(dpath,study,'*t2*tra*'));
        t2s = dir(fullfile(dpath,study,'*T2*'));
        
        for t2 = 1:length(t2s)
            fileNames{length(fileNames)+1} = fullfile(dpath,study,t2s(t2).name);
        end
    else
        study = followups(st-1).name;
        f = dir(fullfile(dpath,study,'*T1*gd*'));
        if isempty(f)
            f = dir(fullfile(dpath,study,'*T1*iso*'));
        end
        fileNames{1} = fullfile(dpath,study,f(1).name);
        %t2s = dir(fullfile(dpath,study,'*t2*tra*'));
        t2s = dir(fullfile(dpath,study,'*T2*'));

        for t2 = 1:length(t2s)
            fileNames{length(fileNames)+1} = fullfile(dpath,study,t2s(t2).name);
        end
    end
    
    outpath = fileparts(strrep(fileNames{1},'Img Data','DIKU-RH'));
    if ~exist(outpath,'file')
        mkdir(outpath)
    end
    
    N=length(fileNames);
    brain = struct([]);
    dims = zeros(N,3);
    S = zeros(N,3);
    BSplineResolution = 1;
    % read images
    for i = 1:N
        Stemp=loadDicomFiles(fileNames{i},'showwaitbar',0,'precision','double');
        brain(i).img = Stemp.vol;
        % fit bspline
        S(i,:)=size(brain(i).img);
        Siztemp=S(i,:)-1;
        [X1, X2, X3]=ndgrid(0:BSplineResolution:Siztemp(1),0:BSplineResolution:Siztemp(2),0:BSplineResolution:Siztemp(3));
        pts=[X1(:) X2(:) X3(:)];
        p=zeros(size(brain(i).img));
        p2=minFunc(@cf_fitBspline,p(:),BsplineOptions,pts,brain(i).img,[0 0 0]+1e-8);
        brain(i).bimg=reshape(p2, size(brain(i).img));
        % rescale to [0;160]
        brain(i).bimg=brain(i).bimg-min(brain(i).bimg(:));
        brain(i).bimg=brain(i).bimg/max(brain(i).bimg(:))*160;
        % store pixel dimension
        dims(i,:) = Stemp.VoxelDimension;
    end
    save(fullfile(outpath,'brain'),'brain','dims','S');
end
