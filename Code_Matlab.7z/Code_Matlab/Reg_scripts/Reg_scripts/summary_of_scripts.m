% All commands and scripts for image registration and data analysis

%% Images - affine registration

% Set patient and follow-up
patients = {'2'}; j=1; studyI = 1; studyJ = 2;

% Create single object containing all data (except dose plan) from a single time point,
% including b-spline interpolated version of image data. 'ipath' will load
% all scans placed in folders with 'T1' or 'T2' in the folder name (folder contains all the dicom files for that scan).
% For different sequences/modalities, name them similarly and copy+modify the part of
% the code finds filenames to load (line 25 to 65 in DIKUfitBsplineAndSave_CT). 
% nifty-files can also be loaded if placed directly the the Baseline/FU folder.
ipath = '\Path\to\folders\containing\images\'; % Image-folder structure in this folder: A separate folder for each patient named 1,2,3,4,..,n. Sub-fodlers in each patient folder named Baseline and FU_1,FU_2,...
DIKUfitBsplineAndSave_CT

%Create hybrid template at each time point (internal registrations in the
%timepoint). This folder is created by DIKUfitBsplineAndSave_CT, and it is
%placed in the same folder as ipath
ipath = '\Path\to\folders\containing\images\..\DIKU-RH'; % Same folder-setup again, used to load the brain.mat files created above
Register_RH_CreateHybridTemplate_CT

% Evaluate one hybrid template (uses 'studyI' to pick study)
% Not currently in use
% Evaluate_HybridTemplate

% Register the two templates (studyI and studyJ), using affine hybrid registration
Register_RH_Hybrid_AA
% disp('done')
%% Evaluate the affine registration between timepoints

clear;
close all;
ipath = '\Path\to\DIKU-RH';
% Set patient and follow-up
patients = {'2'}; j=1; studyI = 1; studyJ = 2;

Evaluate_RegistrationOfHybridTemplates
%Use DIKUview to visualise registrations
DIKUview

%% Plan and structures

ipath = '\Path\to\DIKU-RH';
% Set patient and follow-up
patients = {'2'}; j=1; studyI = 1; studyJ = 2;

studies = listSubFolders(fullfile(ipath,patients{j}));
load(fullfile(ipath,patients{j},studies{studyI},'brain.mat'))
load(fullfile(ipath,patients{j},studies{studyI},'p3all.mat'))
offsetI = offset;
scaleI = dims;
I_aff = p3all;
imageSizes = S.*dims;
[~,idxMinI] = min(imageSizes(:,3)); 
S2 = imageSizes(idxMinI,:);
%define center of rotation (mm from corner of img1)
Icenter=[floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)];
resolution=[1 1 1]*1;
[XI1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsI=[XI1(:) X2(:) X3(:)];

% Set path for plan file
dpath = '\Path\to\plan.mat-file\';
% Load plan
load(fullfile(dpath,patients{j},'plan.mat'),'pt')

% If the CT is too large (>300 slices for example), it can be reduced here
% by un-commenting
% if patients{j} == '1' 
%     reduceCT
% end

% Plan and beam number for basic properties
pl = 1;
bm = 1;

% Interpolate masks for all structures
ct = pt(pl).ct;
pts1 = do_sym_affine(I_aff(:,size(I_aff,2)-2),pointsI,Icenter);
masks = createAndResampleStructuresAsMasks(pt(pl).rs,ct,offsetI,scaleI,pts1,XI1);
save(fullfile(ipath,patients{j},studies{studyI},'masks'),'masks','-v7.3')
% clear all

%%
% Register between timepoints using non-rigid registration
% (Can be based on masks at both time point, in which case needs resampled masks to work)
clear;% close all
ipath = '\Path\to\DIKU-RH';

patients = {'2'}; j=1; studyI = 1; studyJ = 2;

% Perform the deformable registration between two timepoints
Register_RH_Hybrid_NR

% Evaluate non-rigid registration
Evaluate_RegistrationOfHybridTemplates_NR

% disp('done')
%% Dose
%Load plan and masks
dpath = '\Path\to\plan.mat-file\';
%This section assumes Evaluate_RegistrationOfHybridTemplates_NR has been
%run in the previous section (NOTE: not necessarily Register_RH_Hybrid_NR as
%Evaluate_RegistrationOfHybridTemplates_NR can be run to simply load the
%saved registration parameters and apply them to the sessions in question)
j=1;
load(fullfile(dpath,patients{j},'plan.mat'),'pt');
load(fullfile(ipath,patients{j},studies{studyI},'masks'));

% If the CT is too large (>300 slices for example), it can be reduced here
% by un-commenting
% if patients{j} == '1'
%     reduceCT
% end

% Dose resampling in baseline hybrid frame
% Dose (total dose or some other dose distr)
% totDose = getTotalDose(pt);
[doseTot,doseTotCorr,dLET,doseOrig,nFr,nB,nPh] = correctDoseDistr(pt,0,2.1,2);
[dosePhase,dLETPhase,dLETDosePhase,nFr,nB,nPh] = PhaseDose(pt,0,2.1);

% Create dose distribution within mask only
% Set structure no (for brain: pt 1 = 18; pt 2 = 14; pt 3 = 15; pt 4 = 15; pt 5 = 15; pt 6 = 15;
strBrain = [18,14,15,15,15,15]; %for brain: pt 1 = 18; pt 2 = 14; pt 3 = 15; pt 4 = 15; pt 5 = 15; pt 6 = 15;
str = strBrain(str2num(patients{j}));

dose = doseTot;% doseTot / doseTotCorr / doseDiff. Change this, depending on the dose distribution to be displayed
DoseAndFAInMask;

%Use DIKUview to visualise registrations and dose/LET distributions
DIKUview