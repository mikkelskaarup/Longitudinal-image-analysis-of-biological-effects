clear all; close all; 

load petmap
load dosemap

fDir = '/Volumes/Windows/DicomFiles';
subject = '2310550011';

% List Studies
studies = listSubfolders(fullfile(fDir,subject));

% List Scans in study 1
CTfile = listSubfolders(fullfile(fDir,subject,studies{1},'*CT*'));
PETfile = listSubfolders(fullfile(fDir,subject,studies{1},'*FET*'));
MRfile = listSubfolders(fullfile(fDir,subject,studies{1},'*MRT1*'));

% List dose and structure filenames
RDfile = dir(fullfile(fDir,subject,studies{1},'RD*.dcm'));
RSfile = dir(fullfile(fDir,subject,studies{1},CTfile{1},'RS*.dcm'));

% List filename of DICOM registration - MR to CT
regFileMRtoCT = dir(fullfile(fDir,subject,studies{1},'RE*'));

% Read structures
RS = loadRTStructures(fullfile(fDir,subject,studies{1},CTfile{1},RSfile.name));
% Read dose
RD = loadRTDose(fullfile(fDir,subject,studies{1},RDfile.name));

% Read DICOM files (assuming non-oblique image acquisition)
PET = loadDicomFiles(fullfile(fDir,subject,studies{1},PETfile{1}));
CT = loadDicomFiles(fullfile(fDir,subject,studies{1},CTfile{1}));
MR = loadDicomFiles(fullfile(fDir,subject,studies{1},MRfile{1}));
% Load DICOM registration
[MRtoCT,regInfoMRCT] = loadDicomRegistration(fullfile(fDir,subject,studies{1},regFileMRtoCT.name),CT);

roi1 = 'PTV';
roi2 = 'CTV';
% Create Mask based on GTV
PTV = createMaskFromROI(RS.(roi1),CT,size(CT.vol));
CTV = createMaskFromROI(RS.(roi2),CT,size(CT.vol));

%% Estimate DICE
d = calculateDICE(GTV,CTV)
%% Transform MR to CT
MRtransCT = affineTransformation(MR,CT,MRtoCT);

%% Reslice Dose Matrix to CT 
RDtransCT = affineTransformation(RD,CT);

%%
[optimizer,metric] = imregconfig('multimodal');
optimizer.InitialRadius = 0.004;
optimizer.MaximumIterations = 300;
rigid = imregtform(MR.vol,MR.ReferenceObject,CT.vol,CT.ReferenceObject,'rigid',optimizer,metric);


%%
aspect = [CT.info.PixelSpacing' CT.info.SliceThickness]
D=bwdistsc(CTV,aspect);

PTVtoCTVdist = D.*PTV;
max(PTVtoCTVdist(:))

%%
[gx,gy,gz] = gradient(D);
%% Visualize
slice = 41;
x = CT.X(1,:,slice); 
y = CT.Y(:,1,slice);
z = CT.Z(1,1,slice);

% ROI's
[CTVx,CTVy] = getROIFromSlice(RS.(roi2),z);


figure(1)
imagesc(x,y,CT.vol(:,:,slice)); axis image, colormap bone
hold on,
plot(CTVx,CTVy,'Color',RS.(roi2).DisplayColor,'LineWidth',2)

figure(2)
imagesc(x,y,CTV(:,:,slice)); axis image
hold on
plot(CTVx,CTVy,'Color',RS.(roi2).DisplayColor,'LineWidth',2)
%%
figure(3)
imagesc(x,y,PTVtoCTVdist(:,:,slice)); axis image
hold on,colormap jet
plot(GTVx,GTVy,'Color',RS.(roi).DisplayColor,'LineWidth',2)
%%
figure(4)
set(gcf,'InvertHardCopy','off')
bg = ind2rgb(CT.vol(:,:,slice),bone(64));
imagesc(x,y,bg),hold on,axis image;
h = imagesc(x,y,RDtransCT.vol(:,:,slice),[5 60]);
% Alpha-map kan v�re konstant, eller variere hen over billedet
alphamap = 0.65; % her konstant
alphamap = (RDtransCT.vol(:,:,slice)~=0)*0.65; % her kun hvor dosismap er forskellig fra 0
set(h,'AlphaData',alphamap)
colormap(dosemap);
hold on,
plot(GTVx,GTVy,'w-')