%Settings
options.Method='lbfgs';
options.display = 'full';
options.MaxIter=50;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

options2=options;
options2.MaxIter=50;
options3=options;
options3.MaxIter=50;
options4=options;
options4.MaxIter=50;

warning off all

patient = patients{j};
studies = listSubFolders(fullfile(ipath,patient));

%% DEFINE SCAN I (TEMPLATE)
load(fullfile(ipath,patient,studies{studyI},'brain.mat'))
load(fullfile(ipath,patient,studies{studyI},'p3all.mat'))

%Define data for the I-timepoint
HTI = brain;
scaleI = dims;
offsetI = offset;
I_aff = p3all;
N = length(brain);
imageSizes = S.*dims;
[~,idxMinI] = min(imageSizes(:,3));

S2 = imageSizes(idxMinI,:);

%define center of rotation (mm from corner of img1)
Icenter= repmat([floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)],N,1);

%Grid resolution
resolution=[1 1 1]*2;
[XI1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsI=[XI1(:) X2(:) X3(:)];

%Apply affine registration
ptsI = do_sym_affine(I_aff(:,1),pointsI,Icenter(1,:));
Itrival(:,1) = (SplineInterpolation(ptsI,HTI(1).bimg,offsetI(:,1),scaleI(1,:)));

imI1 = reshape(Itrival(:,1),size(XI1));

for k=3:size(HTI,2)
    ptsI = do_sym_affine(I_aff(:,k),pointsI,Icenter(k,:));
    Itrival(:,k) = (SplineInterpolation(ptsI,HTI(k).bimg,offsetI(:,k),scaleI(k,:)));
end

% DEFINE SCAN J (TEMPLATE)
load(fullfile(ipath,patient,studies{studyJ},'brain.mat'))
load(fullfile(ipath,patient,studies{studyJ},'p3all.mat'))

%Define data for the J-timepoint
HTJ = brain;
offsetJ = offset;
J_aff = p3all;
scaleJ = dims;
N = length(brain);
imageSizes = S.*dims;
[~,idxMinJ] = min(imageSizes(:,3));


S2 = imageSizes(idxMinJ,:);

%define center of rotation (mm from corner of img1)
Jcenter= repmat([floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)],N,1);

resolution=[1 1 1]*2;
[XJ1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsJ=[XJ1(:) X2(:) X3(:)];

ptsJ = do_sym_affine(J_aff(:,1),pointsJ,Jcenter(1,:));
Jtrival(:,1) = (SplineInterpolation(ptsJ,HTJ(1).bimg,offsetJ(:,1),scaleJ(1,:)));

imJ1 = reshape(Jtrival(:,1),size(XJ1));

for k=3:size(HTJ,2)
    ptsJ = do_sym_affine(J_aff(:,k),pointsJ,Jcenter(k,:));
    Jtrival(:,k) = (SplineInterpolation(ptsJ,HTJ(k).bimg,offsetJ(:,k),scaleJ(k,:)));
end

%% Create initial Global T2 timepoint 1 to T2 timepoint 2, if doesnt exist
if exist(fullfile(ipath,patient,studies{studyJ},'pGlobal_toBaseline.mat'),'file')~=0
    load(fullfile(ipath,patient,studies{studyJ},'pGlobal_toBaseline'))
elseif exist(fullfile(ipath,patient,studies{studyJ},['pGlobal_' num2str(studyI) '_to_' num2str(studyJ) '_init.mat']),'file')~=0
    load(fullfile(ipath,patient,studies{studyJ},['pGlobal_' num2str(studyI) '_to_' num2str(studyJ) '_init']))
else
    
    dimt1 = scaleI(idxMinI,:);
    dimt2 = scaleJ(idxMinJ,:);
    img1 = HTI(idxMinI).bimg;
    img2 = HTJ(idxMinJ).bimg;
    
    Jval=(SplineInterpolation(pointsJ,img2,[0 0 0],dimt2));
    T2orig = reshape(Jval,size(XJ1));
    %initialize parameters to 0 for affine
    p2=zeros(12,1);
    %using 1-norm
    center = Jcenter(1,:);
    %perform translation initialization
    p2=minFunc(@cf_rigidNMI_3dPW_NR,p2(:),options,img1,pointsJ,center,Jval,dimt1,ones(size(pointsJ,1),1));
    %include rotation
    p2=minFunc(@cf_rigidNMI_3dPW,p2(:),options,img1,pointsJ,center,Jval,dimt1,ones(size(pointsJ,1),1));
    
    %include scale
    p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pointsJ,center,Jval,dimt1,ones(size(pointsJ,1),1));
    
    %full affine
    %change parametrization from angles to.... matrix
    
    [f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pointsJ,center,Jval,dimt1,ones(size(pointsJ,1),1));
    p3=T(:);
    p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);
    
    p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pointsJ,center,Jval,dimt1,ones(size(pointsJ,1),1));
    
    Ival=(SplineInterpolation(pointsJ,img1,[0 0 0],dimt1));
    p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pointsJ,center,Ival,Jval,dimt1,dimt2,ones(size(pointsJ,1),1), [0 0 0]);

    pGlobalInit = p3;
    save(fullfile(ipath,patient,studies{studyJ},['pGlobal_' num2str(studyI) '_to_' num2str(studyJ) '_init']),'pGlobalInit','center')
    
    center_global = center;
    aff_global = pGlobalInit;
end
if ~exist('center_global')
    center_global = center;
end
if ~exist('aff_global')
    aff_global = pGlobalInit;
end

[Ii, Jj]=ndgrid(1:size(HTI,2),1:size(HTJ,2));
comp_vec=[Ii(:) Jj(:)];

detI = ones(size(pointsI,1),1);
detJ = ones(size(pointsJ,1),1);

% initializ to 0
pp4=zeros([30 30 30 3]);

%no. of points in deformation grid
grid_size=45;
% set decreasing grid size of deformation field
pyramidLevels = [40 20 10];
% 
mu = 0.005;

tic
for pl=1:length(pyramidLevels)
    if pl==1
        curr_options = options;
    elseif pl==2
        curr_options = options2;
    elseif pl == 3
        curr_options = options3;
    elseif pl == 4
        curr_options = options4;
    else
        error('Bummer!!')
    end
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    %resampling deformation field to new resolution
    [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
    tpts=[XX1(:) XX2(:) XX3(:)]*pyramidLevels(pl);
    n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
    
    
    %setting size of deformation grid and parametrization
    val=ones([grid_size grid_size grid_size 3]);
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    warp_offset = -ww;
    warp_scale = ww;
    p4=reshape(n,size(val));

    %Perform deformable registration
    pp4=minFunc(@cf_sym_svf_NMI_MultiModal_Fast,p4(:),options,size(p4),mu,warp_offset,warp_scale, HTI,HTJ,pointsI, pointsJ, Itrival,Jtrival,scaleI,scaleJ,detI,detJ,I_aff,J_aff,Icenter,Jcenter,offsetI,offsetJ,comp_vec,aff_global, center_global);

    pp4=reshape(pp4,size(p4));
end

save(fullfile(ipath,patient,studies{studyJ},['NR_global_' num2str(studyI) '_to_' num2str(studyJ)]),'pp4');
