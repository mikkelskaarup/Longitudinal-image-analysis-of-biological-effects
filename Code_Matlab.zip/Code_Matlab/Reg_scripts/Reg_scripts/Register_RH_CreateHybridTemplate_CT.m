% Settings
options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

warning off all

for p = 1:length(patients)
    % Loop over studies
    studies = listSubFolders(fullfile(ipath,patients{p}));

    for s = 1:size(studies,1)
        dpath = fullfile(ipath,patients{p},studies{s});
        % load data
        if s==1
            load(fullfile(dpath,'brain'));
        else
            load(fullfile(dpath,'brain'));
        end
        
        % Find index of smallest resolution image (in mm)
        N = length(brain);
        imageSizes = S.*dims;
        [~,idxMin] = min(imageSizes(:,3));
        Smin = imageSizes(idxMin,:);
        
        %define center of rotation (mm from corner of img1)
        center= repmat([floor(Smin(1)/2) floor(Smin(2)/2) floor(Smin(3)/2)],N,1);
        centr = zeros(3,N);
        
        boundingBox = zeros(N,6);
        
        for i = 1:N
            if (imageSizes(i,1)>300)&&(imageSizes(i,2)>300) % Special case if image is large (assumed to be CT scan)
                id = kmeans(brain(i).img(:),4);
                % Find cluster with fewest points
                [~,minCls]=min([sum(id==1),sum(id==2),sum(id==3),sum(id==4)]);
                id=(id==minCls)*1;
            else
                id=kmeans(brain(i).img(:),2);
                if id(1) == 2
                    id=2-id;
                elseif id(1) == 1
                    id=id-1;
                else
                    error('Situation not accounted for!');
                end
            end
            cls=reshape(id,size(brain(i).img));
            props=regionprops(cls,'Centroid','BoundingBox');
            boundingBox(i,:) = props.BoundingBox.*repmat(dims(i,:),1,2);
            c = props.Centroid.*dims(i,:);
            centr(1,i) = c(2);
            centr(2,i) = c(1);
            centr(3,i) = c(3);
        end
        cDiff = centr-center';
        %%
%       Define parameters for the internal rigid registrations
        p3all = zeros(12,N);
        p3all([1 5 9],idxMin) = 1;
        offset = zeros(3,N);
        comp_vec = 1:N;
        comp_vec(idxMin) = [];
        % Reference scan
        i1 = idxMin;
        for c = 1:numel(comp_vec)
            i2 = comp_vec(c);
            
            dimt1 = dims(i2,:);
            dimt2 = dims(i1,:);
            img1 = brain(i2).bimg;
            img2 = brain(i1).bimg;
            
            %setting image-resolution for affine registration to 2mm
            resolution=[1 1 1]*2;
            [X11, X2, X3]=ndgrid(0:resolution(1):Smin(1)-resolution(1),0:resolution(2):Smin(2)-resolution(2),0:resolution(3):Smin(3)-resolution(3));
            pts=[X11(:) X2(:) X3(:)];
            
            % Re-sample reference image
            Jtrival=(SplineInterpolation(pts,img2,[0 0 0],dimt2));
            
            pinit=zeros(12,1);
            pinit([1 5 9],:)=1;
            
            %initialize parameters to 0 for affine
            p2=zeros(12,1);

            % For CT scan registration, initialize with difference in image extrema
            if (imageSizes(i2,1)>300)&&(imageSizes(i2,2)>300)
                pinit(10:11) = cDiff(1:2,i2);
                pinit(12) = boundingBox(i2,6) - boundingBox(i1,6);
                %using 1-norm
                p2(4)=pinit(10); p2(5)=pinit(11); p2(6)=pinit(12);
            end
            center = center(1,:);
        
            %perform translation initialization
            p2=minFunc(@cf_rigidNMI_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
            %include rotation
            p2=minFunc(@cf_rigidNMI_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
 
            %full affine
            %change parametrization from angles to.... matrix
            [f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
            p3=T(:);
            p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);
            
            %full symmetric affine registration
            %removing translation from the transformation (to the space of I) for creating a common reference space
            offsetI=-p3(10:12);
            p3(10:12)=0;

            %full symmetric affine registration
            offset(:,comp_vec(c)) = offsetI;
            p3all(:,comp_vec(c)) = p3;
        end
        save(fullfile(dpath,'p3all'),'p3all','offset')
    end
end