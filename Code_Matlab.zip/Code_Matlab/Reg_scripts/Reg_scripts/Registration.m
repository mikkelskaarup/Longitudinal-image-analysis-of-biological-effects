%% Set options

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';
options.reg=0.0002;

options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;
options4=options;
options4.MaxIter=100;

%setting scale and offset of img11
options.scale=[1 1 1];
options.offset=[1 1 1]*0;

options.incl_scale = true;

warning off all

options.nonRigidRes = 3;
options.rigidRes = 1;

%% Patient specific settings

%dpath = 'P:\FIN\Lukkede Mapper\DTI-project\MDA';
dpath = '/Volumes/DTI-project/Img data';

pt_no = '0';

% Define box for ct scan (to limit registration to relevant part of scan)
xmin = 100;
xmax = 350;
ymin = 150;
ymax = 350;
zmin = 50;
zmax = 270;

%% Load images and find center for rotations

load([dpath '/' pt_no '/plan.mat'],'ct')
MRI_T2=load_untouch_nii(fullfile(dpath,[pt_no '/baseline_T2.nii']));
MRI_b0 = load_untouch_nii(fullfile(dpath,[pt_no '/baseline_b0.nii']));
% If 'inverse' z axis (happens sometimes with Siemens DTI), flip image
MRI_b0.img = flip(MRI_b0.img,3);
CT = flip(permute(ct.X(xmin:xmax,ymin:ymax,zmin:zmax),[2 1 3]),2);

imgct=double(CT);
imgT2=double(MRI_T2.img);
imgb0=double(MRI_b0.img);

% rescale images to conform with 160 bins (good values are between 80 and 256)img1=img1-min(img1(:));
imgct=imgct-min(imgct(:));
imgct=imgct/max(imgct(:))*160;
imgT2=imgT2-min(imgT2(:));
imgT2=imgT2/max(imgT2(:))*160;
imgb0=imgb0-min(imgb0(:));
imgb0=imgb0/max(imgb0(:))*160;

%get image resolution
dimtct=[ct.dx(2),ct.dx(1),ct.dx(3)];
dimtT2=MRI_T2.hdr.dime.pixdim(2:4);
dimtb0=MRI_b0.hdr.dime.pixdim(2:4);

% Image size [mm]
S_ct=size(imgct).*dimtct;
S_T2=size(imgT2).*dimtT2;
S_b0=size(imgb0).*dimtb0;
Smax=max(S_ct,S_T2);
Smax=max(Smax,S_b0);

%define center of rotation (mm from corner of largest image)
center=[floor(Smax(1)/2) floor(Smax(2)/2) floor(Smax(3)/2)]


%% Register baseline T2 MRI to CT

% Perform rigid registration
p3_t2_ct = rigid_reg_CT(imgct,imgT2,dimtct,dimtT2,Smax,center,options)
center_t2_ct = center;

% Save registration
save(fullfile(dpath,['\' pt_no '\T2_to_CT_rigid']),'p3_t2_ct','center_t2_ct');

% Transform original images using the registration
[img_ct_orig,img_ct_t2_rigid,img_T2_orig,img_T2_ct_rigid] = transform_and_resample(p3_t2_ct,CT,MRI_T2.img,dimtct,dimtT2,S_ct,S_T2,center,options);

%% Register baseline b0 to baseline T2

incl_scale = false;

% Perform registration
p3_b0_t2 = affine_reg_MRI(imgT2,imgb0,dimtT2,dimtb0,Smax,center,options)
center_b0_t2 = center;

% Save registration
save(fullfile(dpath,['\' pt_no '\b0_to_T2_rigid']),'p3_b0_t2','center_b0_t2');

% Transform original images using the registration
[img_T2_orig,img_T2_b0_rigid,img_b0_orig,img_b0_T2_rigid] = transform_and_resample(p3_b0_t2,MRI_T2.img,MRI_b0.img,dimtT2,dimtb0,S_T2,S_b0,center,options);

%% Use results to register baseline b0 to CT

% Combine the two above transformations:
T_1 = [[p3_t2_ct(1:3);0],[p3_t2_ct(4:6);0],[p3_t2_ct(7:9);0],[p3_t2_ct(10:12);1]];
T_2 = [[p3_b0_t2(1:3);0],[p3_b0_t2(4:6);0],[p3_b0_t2(7:9);0],[p3_b0_t2(10:12);1]];
T_12 = T_1*T_2;
p3_b0_ct = [T_12(1:3,1);T_12(1:3,2);T_12(1:3,3);T_12(1:3,4)];

% Transform b0 to CT using the combined registration above
[img_ct_orig,img_ct_b0_rigid,img_b0_orig,img_b0_ct_rigid] = transform_and_resample(p3_b0_ct,CT,MRI_b0.img,dimtct,dimtb0,S_ct,S_b0,center,options);

%% Resample dose in the CT space

% Load dose and permute to ensure same orientation as CT and MR
load([dpath '\' pt_no '\plan.mat'],'doseMCtot');
dose = double(flip(permute(doseMCtot.dose.imd,[2 1 3]),2));
% Set dimentions and size
dimdose = [doseMCtot.dose.dx(2),doseMCtot.dose.dx(1),doseMCtot.dose.dx(3)];
S_dose=size(dose).*dimdose;
% Create rigid transformation from dose to ct space
dose_x0 = doseMCtot.dose.x0;
ct_x0_ny = (ct.x0+[xmin,ymin,zmin].*[dimtct(2),dimtct(1),dimtct(3)]);
dose_trans = [dose_x0(1)-ct_x0_ny(2),-dose_x0(2)+ct_x0_ny(1),dose_x0(3)-ct_x0_ny(3)];
p_dose = [1;0;0;0;1;0;0;0;1;dose_trans(1);dose_trans(2);dose_trans(3)];
% Resample dose
[~,~,~,dose_ct] = transform_and_resample(p_dose,CT,dose,dimtct,dimdose,S_ct,S_dose,center,options);