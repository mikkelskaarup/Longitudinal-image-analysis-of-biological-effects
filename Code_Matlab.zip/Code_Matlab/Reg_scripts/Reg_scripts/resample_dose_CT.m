% Resample dose in CT space

% Load plan
load('/Users/appelt/Documents/DTI data/Img data/5/plan.mat','pt');

% Set plan number
pl = 1;
% Set beam number
bm = 1;

% Get image / dose dimensions
dims(1,:) = pt(pl).ct.dx;
dims(2,:) = pt(pl).dMC(bm).dx;

% Get image / dose matric sizes
S(1,:)=size(pt(pl).ct.X);
S(2,:)=size(pt(pl).dMC(bm).imd);
imageSizes = S.*dims;

% Create points for interpolation of dose
%[X11, X2, X3]=ndgrid(0:dims(1,1):imageSizes(1,1)-dims(1,1),0:dims(1,2):imageSizes(1,2)-dims(1,2),0:dims(1,3):imageSizes(1,3)-dims(1,3));
%pts=[X11(:) X2(:) X3(:)];

% Alternative interpolation (as the above will usually fail due to lack of
% memory
resolution = [1.5 1.5 1.5];
[X11, X2, X3]=ndgrid(0:resolution(1):imageSizes(1,1)-resolution(1),0:resolution(2):imageSizes(1,2)-resolution(2),0:resolution(3):imageSizes(1,3)-resolution(3));
pts=[X11(:) X2(:) X3(:)];

% Get difference between first voxel on CT and first voxel in dose matrix.
% NB! x and y coordinates appears to be switched in dose matrix???
pdiff(1) = pt(pl).dMC(1).x0(2) - pt(1).ct.x0(1);
pdiff(2) = pt(pl).dMC(1).x0(1) - pt(1).ct.x0(2);
pdiff(3) = pt(pl).dMC(1).x0(3) - pt(1).ct.x0(3);

% Get total dose
totDose = getTotalDose(pt);

% Interpolate dose
%trival = SplineInterpolation(pts,double(pt(1).dMC(1).imd),pdiff,dims(2,:));
trival = SplineInterpolation(pts,double(totDose.imd),pdiff,dims(2,:));
tDoseImg = reshape(trival,size(X11));

% Interpolate CT
trival = SplineInterpolation(pts,double(pt(1).ct(1).X),[0 0 0],dims(1,:));
ctImg = reshape(trival,size(X11));

% Interpolate mask, if wanted
s = 14; % Set structure no
mask = getMaskFromContour(pt(1).rs(s),ct);
trival = SplineInterpolation(pts,double(mask),[0 0 0],dims(1,:));
maskImg = reshape(trival,size(X11));

%%

% To transform points in structure, e.g.
strTest(:,1) = pt(1).rs(14).curve(1).p(:,1) - pt(1).ct.x0(1);
strTest(:,2) = pt(1).rs(14).curve(1).p(:,2) - pt(1).ct.x0(2);
strTest(:,3) = pt(1).rs(14).curve(1).p(:,3) - pt(1).ct.x0(3);
pts1 = do_sym_affine(p3all(:,1),strTest,center);
