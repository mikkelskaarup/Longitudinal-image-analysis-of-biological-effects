%% Set options

dpath = 'P:\FIN\Lukkede Mapper\DTI-project\Img data\Pt_0\Baseline';

%pt_no = '0';

name_img2 = 'Baseline_T2';

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;
options4=options;
options4.MaxIter=100;

%setting scale and offset of img11
scale=[1 1 1];
offset=[1 1 1]*0;

warning off all

% Resolutions
nonRigidRes = 3;
rigidRes = 2;


%% Load images and prepare data for registration

load('P:\FIN\Lukkede Mapper\DTI-project\Img data\Pt_0\Plan_data\data_1-28-15.mat','ct')

MRI1=ct;
%MRI2=ct;
MRI2=load_untouch_nii(fullfile(dpath,['\' name_img2 '.nii']));
%MRI1=load_untouch_nii(fullfile(dpath,['\' name_img2 '.nii']));
%img1=double(flip(permute(ct.X(:,:,:),[2 1 3]),2));
img1=double(flip(permute(ct.X(100:350,150:350,50:270),[2 1 3]),2));
%img2=double(flip(permute(ct.X(100:350,150:350,50:270),[2 1 3]),2));
img2=double(MRI2.img);
%img1=double(MRI1.img);

%get image resolution
dimt1=[ct.dx(2),ct.dx(1),ct.dx(3)];
dimt2=MRI2.hdr.dime.pixdim(2:4);
%dimt2=[ct.dx(2),ct.dx(1),ct.dx(3)];
%dimt1=MRI1.hdr.dime.pixdim(2:4);

% Image size [mm]
S1=size(img1).*dimt1;
S2=size(img2).*dimt2;
Smax=max(S1,S2);

% rescale images to conform with 160 bins (good values are between 80 and 256)img1=img1-min(img1(:));
img2=img2-min(img2(:));
img2=img2/max(img2(:))*160;
img1=img1-min(img1(:));
img1=img1/max(img1(:))*160;

%define center of rotation (mm from corner of largest image)
%center=[floor(S1(1)/2) floor(S1(2)/2) floor(S1(3)/2)]
center=[floor(Smax(1)/2) floor(Smax(2)/2) floor(Smax(3)/2)]

%% Affine registration

% Perform registration

% defining grid for resampling and registration
%resolution=dimt1;
resolution=rigidRes;
%[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
%[X12, X22, X32]=ndgrid(0:resolution:S2(1),0:resolution:S2(2),0:resolution:S2(3));
%pts=[X1(:) X2(:) X3(:)];
%pts2=[X12(:) X22(:) X32(:)];
[X11, X21, X31]=ndgrid(0:resolution:Smax(1),0:resolution:Smax(2),0:resolution:Smax(3));
pts=[X11(:), X21(:), X31(:)];

%vectorize images in 'resolution' resolution
Itrival=(SplineInterpolation_tbb(pts,img1,[0 0 0],dimt1));
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));

%initialize parameters to 0 for affine
p2=zeros(12,1);

% estimate centroid for both scans and initialize registration
[id]=kmeans(img2(:),2);
cls=reshape(id,size(img2));
cls=2-cls;
props2=regionprops(cls,'Centroid');
[id]=kmeans(img1(:),2);
cls=reshape(id,size(img1));
cls=2-cls;
props1=regionprops(cls,'Centroid');
cDiff = props1.Centroid.*dimt1 - props2.Centroid.*dimt2;
            
p2(4)=cDiff(2); p2(5)=cDiff(1); p2(6)=cDiff(3);

%using 1-norm
%perform translation initialization
%p2=minFunc(@cf_rigidPNorm_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
%include rotation
%p2=minFunc(@cf_rigidPNorm_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
p2=minFunc(@cf_rigidNMI_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
%include scale
%p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%change parametrization from angles to.... matrix
[f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
p3=T(:);
p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);

%full affine 
%p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full symmetric affine registration
%p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1));

% Save registration
save(fullfile(dpath,['\' name_img2 '_to_CT_rigid']),'p3','center');
%save(fullfile(dpath,['\CT_to_' name_img2 '_affine']),'p3','center');

%% Non-rigid registration

% Prepare images and perform non-rigid registration

%resample img1 to prepare non-rigid registration
resolution=rigidRes;
[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
ptsresample=[X1(:) X2(:) X3(:)];
[pts3]=do_sym_affine(p3(:),ptsresample,center);
Rtrival=(SplineInterpolation_lin(pts3,img1,[0 0 0],dimt1));
img11=reshape(Rtrival,size(X1));

%setting up non-rigid registration
resolution=nonRigidRes;
[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
pts=[X1(:) X2(:) X3(:)];
Itrival=(SplineInterpolation_tbb(pts,img11,[0 0 0],[1 1 1]));
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));

% extracting positions with information
no=find(Itrival+Jtrival>0);

% initialize to 0
pp4=zeros([30 30 30 3]);
ww=[40 40 40];

%no. of points in deformation grid
grid_size=45;

% set decreasing grid size of deformation field
pyramidLevels = [40 20 10 5];

for pl=1:length(pyramidLevels)
    if (pl==1 || pl==2)
        curr_options = options2;
    elseif pl == 3
        curr_options = options3;
    elseif pl == 4
        curr_options = options4;
    else
        error('Bummer!!')
    end
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    %resampling deformation field to new resolution
    %resampling deformation field to new resolution
    [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
    tpts=[XX1(:) XX2(:) XX3(:)]*pyramidLevels(pl);
    n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
    %setting scale and offset of img11
    scale=[1 1 1];
    offset=[1 1 1]*0;
    
    %setting size of deformation grid and parametrization
    val=ones([grid_size grid_size grid_size 3]);
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    p4=reshape(n,size(val));
    offset2=-ww;

    pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),curr_options,size(p4),(0.0005),pts(no,:),img11,img2,Jtrival(no),Itrival(no),offset2,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);

    pp4=reshape(pp4,size(p4));

end

% Save registration
save(fullfile(dpath,['\' pt_no '\' name_img2 '_to_' name_img1]),'pp4');
