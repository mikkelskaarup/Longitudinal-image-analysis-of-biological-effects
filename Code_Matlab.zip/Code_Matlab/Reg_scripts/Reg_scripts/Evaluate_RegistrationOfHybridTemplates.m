% Evaluate Hybrid template registration
studies = listSubFolders(fullfile(ipath,patients{j}));

% Load global affine
load(fullfile(ipath,patients{j},studies{studyJ},'pGlobal_toBaseline'));
if ~exist('aff_global','var')
    aff_global = p3;
end
if ~exist('center_global','var')
    center_global = center;
end
% Load scan I
load(fullfile(ipath,patients{j},studies{studyI},'brain.mat'))
load(fullfile(ipath,patients{j},studies{studyI},'p3all.mat'))
HTI = brain;
imageSizes = S.*dims;
[~,idxMinI] = min(imageSizes(:,3));
offsetI = offset;
I_aff = p3all;
scaleI = dims;
N = length(brain);
S2 = imageSizes(idxMinI,:);
%define center of rotation (mm from corner of img1)
Icenter=[floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)];
resolution=[1 1 1]*2;
[XI1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsI=[XI1(:) X2(:) X3(:)];

%Apply registration for I-template
for n=1:size(HTI,2)
    pts1 = do_sym_affine(I_aff(:,n),pointsI,Icenter);
    trival = SplineInterpolation(pts1,HTI(n).img,offsetI(:,n),scaleI(n,:));
    eval(['imI' num2str(n) '= reshape(trival,size(XI1));']);
end

%% Load scan J
load(fullfile(ipath,patients{j},studies{studyJ},'brain.mat'))
load(fullfile(ipath,patients{j},studies{studyJ},'p3all.mat'))
HTJ = brain;
imageSizes = S.*dims;
[~,idxMinJ] = min(imageSizes(:,3));
scaleJ = dims;
N = length(brain);
offsetJ = offset;
J_aff = p3all;

S2 = imageSizes(idxMinJ,:);
%define center of rotation (mm from corner of img1)
Jcenter= [floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)];

resolution=[1 1 1]*2;
[XJ1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsJ=[XJ1(:) X2(:) X3(:)];

a = aff_global;
[pts1,pts1_inv] = do_sym_affine(a,pointsI,center_global);

%Apply registration for J-template
for n=1:size(HTJ,2)
    pts2 = do_sym_affine(J_aff(:,n),pts1,Jcenter);
    tJtrival = SplineInterpolation(pts2,HTJ(n).img,offsetJ(:,n),scaleJ(n,:));
    eval(['imJ' num2str(n) '= reshape(tJtrival,size(XI1));']);
end