function masks = createAndResampleStructuresAsMasks(rs,ct,offset,scale,pts,X1)

for i=1:size(rs,2)
    mask = getMaskFromContour(rs(i),ct);
    trival = SplineInterpolation(pts,double(mask),offset(:,size(offset,2)-2),scale(size(scale,1)-2,:));
    maskImg = reshape(trival,size(X1));
    maskImg = (maskImg>0.5)*1;
    masks(i).mask = maskImg;
    masks(i).strName = rs(i).label;
end



