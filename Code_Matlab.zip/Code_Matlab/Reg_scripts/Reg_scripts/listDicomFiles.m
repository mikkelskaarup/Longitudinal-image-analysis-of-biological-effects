function fArray = listDicomFiles(dName)

% List dicom files in folder
list = dir([dName filesep '*dcm']);
fArray = {list(:).name}';
% If no DICOM files - look for Siemens IMA
if isempty(fArray)
    list = dir([dName filesep '*IMA']);
    fArray = {list(:).name}';
    if isempty(fArray)
        list = dir(dName);
        list = list(~[list.isdir]&~strncmpi('.', {list.name}, 1));
        fArray = {list(:).name}';
    end
end