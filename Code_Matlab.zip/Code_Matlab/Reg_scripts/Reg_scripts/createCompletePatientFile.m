clear;
close all

ipath = 'L:\LovbeskyttetMapper\DTI-project\DIKU-RH\';

patients = {'8'};
