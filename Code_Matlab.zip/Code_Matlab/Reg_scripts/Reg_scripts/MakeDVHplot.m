origStr = str;
if patients{j} == '1'
    masklist = [8 11 14 16 17 18 19 26];
elseif patients{j} == '2'
    masklist = [2 4 10 13 14 24 25 34 35];
elseif patients{j} == '3'
    masklist = [2 3 5 11 14 15 25 26];
elseif patients{j} == '4'
    masklist = [2 5 11 14 15 25 26];
elseif patients{j} == '5'
    masklist = [2 3 4 5 11 14 15 25 26];
elseif patients{j} == '6'
    masklist = [2 3 5 11 14 15 25 26];
else
    masklist = [2 4 10 13 14 24 25 34 35];
end
figure;
hold on
for i=1:length(masklist)
    str = masklist(i);
    strMask = masks(str).mask;
%     maskDoseImg = strMask.*doseImg;
    maskDose = doseImg(strMask>0);
    if patients{j} == '1'; dosemax = pt(1).dMC(1).dmax + pt(1).dMC(2).dmax;
    else; dosemax = max(maskDose(:));
    end

    dosebins = linspace(0,dosemax,100);
    DVHval = zeros(1,length(dosebins));
    for ii=1:length(dosebins)
        nOver = length(maskDose(maskDose>dosebins(ii)));
        DVHval(ii) = nOver/(length(maskDose))*100;
    end
    plot(dosebins, DVHval)
end
plot([36,36],[0,100],'k--')
legend(masks(masklist(1)).strName,masks(masklist(2)).strName,masks(masklist(3)).strName,masks(masklist(4)).strName,masks(masklist(5)).strName,masks(masklist(6)).strName,masks(masklist(7)).strName,masks(masklist(8)).strName,'Planned dose')
hold off
str = origStr;
strMask = masks(str).mask;
% maskDoseImg = strMask.*doseImg;
maskDose = doseImg(strMask>0);