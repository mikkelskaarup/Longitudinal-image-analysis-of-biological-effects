function plot_dose_on_MR(doseImg, T2img)
figure;
ax1 = axes;
imagesc(T2img);
colormap(ax1,'gray');
ax2 = axes;
imagesc(ax2,doseImg,'alphadata',0.35%max(doseImg(:))/2)
colormap(ax2,'jet')
caxis(ax2,[5 54]); %PT2 and PT5
% caxis(ax2,[59.4/2 59.4]); %PT3
% caxis(ax2,[24/2 24]); %PT4 and PT6
ax2.Visible = 'off';
linkprop([ax1 ax2],'Position');
colorbar;
