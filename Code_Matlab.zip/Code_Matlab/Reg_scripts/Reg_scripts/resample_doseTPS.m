%% Resample dose in same frame as baseline imaging

% Load plan
%load(fullfile('/Users/appelt/Dropbox/Work/Projekter/DTI projekt/DTI data/Img data/',patients{j},'plan.mat'),'pt')
%load(fullfile(dpath,patients{j},'plan.mat'),'pt')

% Plan and beam number for basic properties
%pl = 1;
%bm = 1;

% Get difference between first voxel on CT and first voxel in dose matrix.
% NB! x and y coordinates appears to be switched in dose matrix???
pdiff(1) = pt(1).dTPS(1).x0(2) - pt(1).ct.x0(1);
pdiff(2) = pt(1).dTPS(1).x0(1) - pt(1).ct.x0(2);
pdiff(3) = pt(1).dTPS(1).x0(3) - pt(1).ct.x0(3);

% Get total dose
%totDose = getTotalDose(pt);

% Resample dose to same space as baseline imaging (using offset, etc, from
% CT). Assume offset between dose and CT is saved in pdiff
dimD = pt(pl).dTPS(bm).dx;
%dose = totDose; %Change this, depending on the dose distribution to be displayed
pts1 = do_sym_affine(I_aff(:,size(I_aff,2)),pointsI,Icenter);
oDtrival = (SplineInterpolation(pts1,double(dose.imd),offsetI(:,size(offsetI,2))+pdiff',dimD));
doseImg = reshape(oDtrival,size(XI1));