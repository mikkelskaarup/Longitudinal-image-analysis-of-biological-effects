function [pp2, CI_pp2, pp2spline] = residualsFit(FAFU, FABase, dose, LET, minDose, maxDose, minLET, maxLET)
LW = 1; MS = 50;

DiffFA = FAFU-FABase;

XX = zeros(length(FABase),1);
XX(:,1) = FABase;
% XX(:,2) = dose;
[pp2noLET, CI_pp2noLET] = regress(FAFU,[XX(:,1)]);
% ff = @(F,XX) F(1)*XX(:,1);% + F(2)*XX(:,2);
% [FAdoseFitnoLET,residuals,J,CovB,MSE,ErrorModelInfo] = nlinfit(XX,FAFU,ff,[1]);
% disp(['Fit = ',num2str(FAdoseFitnoLET)])
% disp(['Err = ',num2str(sqrt(diag(CovB))')])
% figure; scatter(FABase,FAFU, MS, '.');
% xlim([min(FABase), max(FABase)]); ylim([0, 1])
% xlabel('FA_{Baseline}')
% ylabel('FA_{Follow-up}')
% hold on
% plot([0,1],[0,1]*FAdoseFitnoLET(1),'-r', 'LineWidth', 2*LW)
% legend('measured','interpolant');
% hold off

XX = zeros(length(FABase),3);
XX(:,1) = FABase;
XX(:,2) = dose;
XX(:,3) = LET;
% b = regress(FAFU,[ones(size(XX(:,1))), XX(:,1), XX(:,2), XX(:,2).*XX(:,3)])
[pp2, CI_pp2] = regress(FAFU,[XX(:,1), XX(:,2), XX(:,2).*XX(:,3)]);
% ff = @(F,XX) F(1)*XX(:,1) + F(2)*XX(:,2) + F(3)*XX(:,2).*XX(:,3);
% [FAdoseFit,residuals,J,CovB,MSE,ErrorModelInfo] = nlinfit(XX,FAFU,ff,[1,1,1]);

% figure; scatter(FABase+dose+dose.*LET,FAFU, MS, '.');
% Limits = [min(FAFU+dose+dose.*LET), max(FAFU+dose+dose.*LET)];
% xlim(Limits); ylim([0, 1])
% xlabel('FA_{Baseline} + Dose + Dose*LET')
% ylabel('FA_{Follow-up}')
% hold on
% plot(Limits,[min(FAFU*FAdoseFit(1)+dose*FAdoseFit(2)+dose.*LET*FAdoseFit(2)), max(FAFU*FAdoseFit(1)+dose*FAdoseFit(2)+dose.*LET*FAdoseFit(2))],'-r', 'LineWidth', 2*LW)
% legend('measured','interpolant');
% hold off

% disp(['Fit = ',num2str(FAdoseFit)])
% disp(['Err = ',num2str(sqrt(diag(CovB))')])

% figure; histogram(residuals)
% figure; scatter(dose,residuals, MS, '.');
% xlim([minDose, maxDose]); ylim([-0.2, 0.2])
% hold on
% plot([minDose, maxDose],[0,0],'k-', 'LineWidth', LW)
% hold off
% % 
% figure; scatter(LET,residuals, MS, '.');
% xlim([minLET, maxLET]); ylim([-0.2, 0.2])
% hold on
% plot([minLET, maxLET],[0,0],'k-', 'LineWidth', LW)
% hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
% B SPLINE - The new function
% pp2spline = splinefit(dose,DiffFA,3,2);
pp2spline = splinefit(dose+dose.*LET,FAFU-FABase*pp2noLET(1),3,2);
% disp(pp2.breaks)
% disp(pp2.coefs)
y2 = ppval(pp2spline,pp2spline.breaks);
% figure; scatter(dose,FAFU-FABase*pp2noLET(1),MS,'.');
% hold on
% plot(pp2spline.breaks,y2,'r-','LineWidth',LW)
% hold off
% %
% residuals = (DiffFA) - ppval(pp2,dose);%sp2.evalAt(dose+dose.*LET);
% % 
% figure; scatter(dose,residuals, MS, '.');
% xlim([minDose, maxDose]); ylim([-0.2, 0.2])
% hold on
% plot([minDose, maxDose],[0,0],'k-', 'LineWidth', LW)
% hold off
% % % 
% figure; scatter(LET,residuals, MS, '.');
% xlim([minLET, maxLET]); ylim([-0.2, 0.2])
% hold on
% plot([minLET, maxLET],[0,0],'k-', 'LineWidth', LW)
% hold off
%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
% B SPLINE - Only dose term

% stepSize = (maxDose-minDose)/10;
% x_fine = minDose:stepSize:maxDose;
% % y_fine = zeros([1,length(x_fine)]);
% 
% [doseSorted, idxSort] = sort(dose);
% % FAFUSorted = FAFU(idxSort);
% % FABaseSorted = FABase(idxSort);
% % DiffFASorted = DiffFA(idxSort);%FAFUSorted - FABaseSorted;
% % LETSorted = LET(idxSort);
% % for ii=2:length(x_fine)
% %     y_fine(ii) = mean(FAFU(dose>x_fine(ii-1) & dose<=x_fine(ii))) - FAdoseFit(1)*mean(FABase(dose>x_fine(ii-1) & dose<=x_fine(ii)));
% % end
% 
% 
% knots = [minDose,x_fine(4),x_fine(8),maxDose];%[minDose,x_fine,maxDose];
% sp1 = fastBSpline.lsqspline(knots,1,dose,FAFU-FABase*FAdoseFitnoLET(1));
% % sp1.knots
% sp1.weights
% sp1.getBasis(maxDose)
% %
% % sp1 = fastBSpline.pspline(knots,3,dose,DiffFA,0.7);
% % % TheSpline = Bspline(y_fine,1);
% % % FAdose_BSpline = TheSpline(doseSorted);
% % % FAdose_BSpline = bspline(x_fine);
% 
% figure; scatter(dose,FAFU-FABase*FAdoseFitnoLET(1), MS, '.');
% xlim([minDose, maxDose]); ylim([-0.2, 0.2])
% xlabel('Fraction corrected dose (Not RBE=1.1 corrected) [Gy]')
% ylabel('Difference in ...')
% hold on
% plot(doseSorted,sp1.evalAt(doseSorted),'-r', 'LineWidth', 2*LW)
% % plot(doseSorted,fnval(FAdose_BSpline,doseSorted),'-r', 'LineWidth', 2*LW)
% legend('measured','interpolant');
% hold off
% 
% residuals = (FAFU-FABase*FAdoseFitnoLET(1)) - sp1.evalAt(dose);
% 
% figure; scatter(dose,residuals, MS, '.');
% xlim([minDose, maxDose]); ylim([-0.2, 0.2])
% xlabel('Fraction corrected dose (Not RBE=1.1 corrected) [Gy]')
% ylabel('Residuals')
% hold on
% plot([minDose, maxDose],[0,0],'k-', 'LineWidth', LW)
% hold off
% % 
% figure; scatter(LET,residuals, MS, '.');
% xlim([minLET, maxLET]); ylim([-0.2, 0.2])
% xlabel('LET')
% ylabel('Residuals')
% hold on
% plot([minLET, maxLET],[0,0],'k-', 'LineWidth', LW)
% hold off
% %%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%
% % B SPLINE - Dose and dose*LET term
% maxDoseLET = max(dose+dose.*LET);
% minDoseLET = min(dose+dose.*LET);
% stepSize = (maxDoseLET-minDoseLET)/10;
% x_fine = minDoseLET:stepSize:maxDoseLET;
% knots = [minDoseLET,minDoseLET,x_fine(4),x_fine(8),maxDoseLET,maxDoseLET];%[minDoseLET,x_fine,maxDoseLET];
% 
% [doseLETSorted, idxSort] = sort(dose+dose.*LET);
% 
% sp2 = fastBSpline.lsqspline(knots,1,dose+dose.*LET,FAFU-FABase*FAdoseFitnoLET(1));
% % sp2 = fastBSpline.pspline(knots,1,dose,DiffFA,0.7);
% % sp2.dx.knots
% % sp2.weights
% %
% figure; scatter(dose+dose.*LET,FAFU-FABase*FAdoseFitnoLET(1), MS, '.');
% xlim([min(dose+dose.*LET), max(dose+dose.*LET)]); ylim([-0.2, 0.2])
% hold on
% plot(doseLETSorted,sp2.evalAt(doseLETSorted),'-r', 'LineWidth', 2*LW)
% % % plot(doseSorted,fnval(FAdose_BSpline,doseSorted),'-r', 'LineWidth', 2*LW)
% legend('measured','interpolant');
% hold off
% % 
% residuals = (FAFU-FABase*FAdoseFitnoLET(1)) - sp2.evalAt(dose+dose.*LET);
% % 
% figure; scatter(dose,residuals, MS, '.');
% xlim([minDose, maxDose]); ylim([-0.2, 0.2])
% hold on
% plot([minDose, maxDose],[0,0],'k-', 'LineWidth', LW)
% hold off
% % % 
% figure; scatter(LET,residuals, MS, '.');
% xlim([minLET, maxLET]); ylim([-0.2, 0.2])
% hold on
% plot([minLET, maxLET],[0,0],'k-', 'LineWidth', LW)
% hold off
% 
end