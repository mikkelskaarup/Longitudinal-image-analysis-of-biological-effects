% Evaluate Hybrid template registration
patient = patients{j};
studies = listSubFolders(fullfile(ipath,patient));

warpSize = 10;
resolution=[1 1 1]*1;
%% Load global affine
if exist(fullfile(ipath,patient,studies{studyJ},'pGlobal_toBaseline.mat'),'file')~=0
    load(fullfile(ipath,patient,studies{studyJ},'pGlobal_toBaseline'))
else exist(fullfile(ipath,patient,studies{studyJ},['pGlobal_' num2str(studyI) '_to_' num2str(studyJ) '_init.mat']),'file')~=0
    load(fullfile(ipath,patient,studies{studyJ},['pGlobal_' num2str(studyI) '_to_' num2str(studyJ) '_init']))
end
if ~exist('aff_global','var')
    try
        aff_global = p3;
    end
    try
        aff_global = pGlobalInit;
    end
end
if ~exist('center_global','var')
    center_global = center;
end
%% Load scan I
load(fullfile(ipath,patient,studies{studyI},'brain.mat'))
load(fullfile(ipath,patient,studies{studyI},'p3all.mat'))
% Apply CT NR-registration to mask structures


HTI = brain;
imageSizes = S.*dims;
[~,idxMinI] = min(imageSizes(:,3));

N_I = length(brain);
offsetI = offset;
I_aff = p3all;
scaleI = dims;

S2 = imageSizes(idxMinI,:);
%define center of rotation (mm from corner of img1)
Icenter=[floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)];
[XI1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsI=[XI1(:) X2(:) X3(:)];

for i=1:N_I
    % Transform points from image to hybridTemplate I
    ptsI_hybridAff = do_sym_affine(I_aff(:,i),pointsI,Icenter);
    % Interpolate image in hybridTemplate I frame
    eval(['imI' num2str(i) ' = reshape(SplineInterpolation(ptsI_hybridAff,HTI(i).img,offsetI(:,i),scaleI(i,:)),size(XI1));']);
end

%% Load scan J
load(fullfile(ipath,patient,studies{studyJ},'brain.mat'))
load(fullfile(ipath,patient,studies{studyJ},'p3all.mat'))
if exist(fullfile(ipath,patient,studies{studyJ},['NR_warp_' num2str(studyJ) '_to_' num2str(studyI) '_warpsize_' num2str(warpSize) '.mat']),'file')
    load(fullfile(ipath,patient,studies{studyJ},['NR_warp_' num2str(studyJ) '_to_' num2str(studyI) '_warpsize_' num2str(warpSize) '.mat']))
else
    load(fullfile(ipath,patient,studies{studyJ},['NR_global_' num2str(studyI) '_to_' num2str(studyJ) '.mat']))
end

HTJ = brain;
imageSizes = S.*dims;
[~,idxMinJ] = min(imageSizes(:,3));
N_J = length(brain);
offsetJ = offset;
J_aff = p3all;
scaleJ = dims;

S2 = imageSizes(idxMinJ,:);
%define center of rotation (mm from corner of img1)
Jcenter= [floor(S2(1)/2) floor(S2(2)/2) floor(S2(3)/2)];

ww = [warpSize warpSize warpSize];
%ww=[40 40 40];
offset2 = -ww;

[XJ1, X2, X3]=ndgrid(0:resolution(1):S2(1)-resolution(1),0:resolution(2):S2(2)-resolution(2),0:resolution(3):S2(3)-resolution(3));
pointsJ=[XJ1(:) X2(:) X3(:)];

% Transform points I through to Hybrid J
% Non-rigid
ptsI_NR = SS_Trap_1st(pointsI,pp4,offset2,ww,double(40),double(5));
ptsI_NR_globalAff = do_sym_affine(aff_global,ptsI_NR,center_global);
% Affine only
ptsI_globalAff = do_sym_affine(aff_global,pointsI,center_global);

for j=1:N_J
    ptsI_NR_globalAff_hybridAff = do_sym_affine(J_aff(:,j),ptsI_NR_globalAff,Jcenter);
    ptsI_globalAff_hybridAff = do_sym_affine(J_aff(:,j),ptsI_globalAff,Jcenter);
    eval(['imJ' num2str(j) 'NR = reshape(SplineInterpolation(ptsI_NR_globalAff_hybridAff,HTJ(j).img,offsetJ(:,j),scaleJ(j,:)),size(XI1));']);
    eval(['imJ' num2str(j) 'aff = reshape(SplineInterpolation(ptsI_globalAff_hybridAff,HTJ(j).img,offsetJ(:,j),scaleJ(j,:)),size(XI1));']);
end

% imFAdiff = imI7 - imJ6NR;
DIKUview('imI1','imJ1aff')
