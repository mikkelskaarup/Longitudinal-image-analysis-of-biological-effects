function [img1orig,img1rigid,img2orig,img2rigid] = transform_and_resample(p3,img1,img2,dimt1,dimt2,S1,S2,center,options)

% Create grid for interpolation of images after transformation
[X11, X21, X31]=ndgrid(0:dimt1(1):S1(1)-dimt1(1),0:dimt1(2):S1(2)-dimt1(2),0:dimt1(3):S1(3)-dimt1(3));
org_pts1=[X11(:), X21(:), X31(:)];
[X12, X22, X32]=ndgrid(0:dimt2(1):S2(1)-dimt2(1),0:dimt2(2):S2(2)-dimt2(2),0:dimt2(3):S2(3)-dimt2(3));
org_pts2=[X12(:), X22(:), X32(:)];

% Interpolate images
n1=SplineInterpolation_lin(org_pts1+repmat(0*dimt1,numel(X11),1),img1,[0 0 0],dimt1);
n2=SplineInterpolation_lin(org_pts2+repmat(0*dimt2,numel(X12),1),img2,[0 0 0],dimt2);

%img2 matched to img1 by affine
[pts3, ipts3]=do_sym_affine(p3(:),org_pts1,center);
n21=SplineInterpolation_lin(ipts3+repmat(0*dimt2,numel(X11),1),double(img2),[0 0 0],dimt2);

%img1 matched to img2 by inv affine
pts3=do_sym_affine(p3(:),org_pts2,center);
n12=SplineInterpolation_lin(pts3+repmat(0*dimt1,numel(X12),1),double(img1),[0 0 0],dimt1);

% Back into matrix
img1orig = reshape(n1,size(X11));
img2orig = reshape(n2,size(X12));
img2rigid = reshape(n21,size(X11));
img1rigid = reshape(n12,size(X12));