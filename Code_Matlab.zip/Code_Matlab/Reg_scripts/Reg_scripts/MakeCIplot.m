% if patients{j} == '1'; dosemax = pt(1).dMC(1).dmax + pt(1).dMC(2).dmax;
% else; dosemax = max(maskDose(:));
% end
dosemin = min(maskDoseImg(maskDoseImg>0));
dosemax = max(maskDoseImg(maskDoseImg>0));
% dosemin = min(maskDose);
% dosemax = max(maskDose);
dosebins = linspace(dosemin,dosemax,100);
FAbins = struct([]); PETbins = struct([]); T1bins = struct([]);
FAmean = zeros(1,length(dosebins)); FAstd = zeros(1,length(dosebins));
FAupper = zeros(1,length(dosebins)); FAlower = zeros(1,length(dosebins));
PETmean = zeros(1,length(dosebins)); PETstd = zeros(1,length(dosebins));
PETupper = zeros(1,length(dosebins)); PETlower = zeros(1,length(dosebins));
T1mean = zeros(1,length(dosebins)); T1std = zeros(1,length(dosebins));
T1upper = zeros(1,length(dosebins)); T1lower = zeros(1,length(dosebins));
figure(21); subplot(1,2,1);
hold on
for ii=2:length(dosebins)
    FAbins(ii-1).values = maskDiffFA(find(maskDose>dosebins(ii-1) & maskDose <= dosebins(ii)));
    if isempty(FAbins(ii-1).values); FAbins(ii-1).values = 0; end
    FAmean(ii) = mean(FAbins(ii-1).values);%FAbins(ii-1).mean = mean(FAbins(ii-1).values);
    FAstd(ii) = std(FAbins(ii-1).values);%FAbins(ii-1).std = std(FAbins(ii-1).values);
    FAupper(ii) = FAmean(ii-1) + FAstd(ii-1);%FAbins(ii-1).upperCI = FAbins(ii-1).mean + 2*FAbins(ii-1).std;
    FAlower(ii) = FAmean(ii-1) - FAstd(ii-1);%FAbins(ii-1).lowerCI = FAbins(ii-1).mean - 2*FAbins(ii-1).std;
    
    T1bins(ii-1).values = maskDiffT1(find(maskDose>dosebins(ii-1) & maskDose <= dosebins(ii)));
    if isempty(T1bins(ii-1).values); T1bins(ii-1).values = 0; end
    T1mean(ii) = mean(T1bins(ii-1).values);%FAbins(ii-1).mean = mean(FAbins(ii-1).values);
    T1std(ii) = std(T1bins(ii-1).values);%FAbins(ii-1).std = std(FAbins(ii-1).values);
    T1upper(ii) = T1mean(ii-1) + T1std(ii-1);%FAbins(ii-1).upperCI = FAbins(ii-1).mean + 2*FAbins(ii-1).std;
    T1lower(ii) = T1mean(ii-1) - T1std(ii-1);%FAbins(ii-1).lowerCI = FAbins(ii-1).mean - 2*FAbins(ii-1).std;
    
    if patients{j} == '2' && (studyJ == 3 || studyJ == 4)
        PETbins(ii-1).values = maskPET(find(maskDose>dosebins(ii-1) & maskDose <= dosebins(ii)));
        if isempty(PETbins(ii-1).values); PETbins(ii-1).values = 0; end
        PETmean(ii) = mean(PETbins(ii-1).values);
        PETstd(ii) = std(PETbins(ii-1).values);
        PETupper(ii) = PETmean(ii-1) + PETstd(ii-1);
        PETlower(ii) = PETmean(ii-1) - PETstd(ii-1);
    end
    if ii < length(dosebins); scatter(FAbins(ii-1).values,T1bins(ii-1).values,1,maskDose(find(maskDose>dosebins(ii-1) & maskDose <= dosebins(ii))),'filled'); end
end
title('Follow-up (FU) after 6 months with constant RBE = 1.1')
% title('Follow-up (FU) after 6 months with McNamara model')
ylabel('T1_{FU at 6 months} - T1_{Baseline}')
ylim([-100, 800])
xlabel('FA_{FU at 6 months} - FA_{Baseline}')
xlim([-0.2, 0.2])
colorbar
hold off

% figure(1); subplot(2,1,1);
% if patients{j} == '2' && (studyJ == 3 || studyJ == 4)
%     yyaxis left
%     plot(dosebins,FAmean,'color',[0.2 0.6 1.0],'LineWidth',5,'LineStyle','-')
%     hold on
%     ciplot(FAlower+FAstd,FAupper-FAstd,dosebins,'g')
%     ciplot(FAlower,FAupper,dosebins,[0.2 0.6 1.0])
%     yyaxis right
%     plot(dosebins,PETmean,'color',[1.0 0.6 0.0],'LineWidth',5,'LineStyle','-')
%     ciplot(PETlower,PETupper,dosebins,[1.0 0.6 0.0])
%     
%     title('Follow-up (FU) after 9 months with constant RBE = 1.1')
% %     legend('Mean difference of FA signal','1 standard deviation (\sigma_{FA})');%,'Mean of PET signal','1 standard deviation (\sigma_{PET})')
% %     xlabel('Fraction-size and RBE corrected EQD2 [Gy]')
% else
%     yyaxis left
%     plot(dosebins,FAmean,'color',[0.2 0.6 1.0],'LineWidth',3,'LineStyle','-')
%     hold on
%     ciplot(FAlower,FAupper,dosebins,[0.2 0.6 1.0])
%     yyaxis right
%     plot(dosebins,T1mean,'color',[1.0 0.6 0.0],'LineWidth',3,'LineStyle','-')
% %     hold on
%     ciplot(T1lower,T1upper,dosebins,[1.0 0.6 0.0])
%     
%     title('Follow-up (FU) after 9 months with constant RBE = 1.1')%('Follow-up (FU) after 9 months with McNamara model')%('Follow-up (FU) after 9 months with constant RBE = 1.1')
% %     legend('Mean difference of FA signal','1 standard deviations (\sigma_{FA})','Mean of T1 signal','1 standard deviations (\sigma_{T1})')
% %     xlabel('Fraction-size and RBE corrected EQD2 [Gy]')
% end