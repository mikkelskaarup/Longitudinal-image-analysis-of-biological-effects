diffPET3 = maskPET(maskPET>=2);
diffDose3 = maskDose(maskPET>=2);
diffFA3 = maskDiffFA(maskPET>=2);
diffT13 = maskDiffT1(maskPET>=2);
diffFA2 = maskDiffFA(maskPET>=1 & maskPET<2);
diffT12 = maskDiffT1(maskPET>=1 & maskPET<2);
diffDose2 = maskDose(maskPET>=1 & maskPET<2);
diffPET2 = maskPET(maskPET>=1 & maskPET<2);
diffT11 = maskDiffT1(maskPET<1);
diffFA1 = maskDiffFA(maskPET<1);
diffPET1 = maskPET(maskPET<1);
diffDose1 = maskDose(maskPET<1);

figure;
for off=1:3
    eval(['z=off*500+zeros(size(diffDose' num2str(off) '));']);
    eval(['scatter3(diffDose' num2str(off) ',diffFA' num2str(off) ',z,10,diffT1' num2str(off) ');']);
    hold on
end
colorbar
hold off