function [f df]=cf_rigidNMI_3dpw(p, HTI, HTJ,pointsI, pointsJ,center, Itrival,Jtrival,scaleI,scaleJ,detI,detJ,I_aff,J_aff,I_center,J_center,offsetI,offsetJ,comp_vec)



df=zeros(numel(p),1);




%Affine matrices
R=[p(1) p(2) p(3);p(4) p(5) p(6); p(7) p(8) p(9)];
%inverse of of affine matrices 
[invR, dinvR]=inv3x3(R);
dR1=[1 0 0; 0 0 0 ;0 0 0];
dR2=[0 1 0; 0 0 0 ;0 0 0];
dR3=[0 0 1; 0 0 0 ;0 0 0];
dR4=[0 0 0; 1 0 0 ;0 0 0];
dR5=[0 0 0; 0 1 0 ;0 0 0];
dR6=[0 0 0; 0 0 1 ;0 0 0];
dR7=[0 0 0; 0 0 0 ;1 0 0];
dR8=[0 0 0; 0 0 0 ;0 1 0];
dR9=[0 0 0; 0 0 0 ;0 0 1];

%translation
t1=zeros(3,1);t1(1)=p(10);t1(2)=p(11);t1(3)=p(12);

%application of derived affine matrices and inverses
size_pointsI=size(pointsI,1);
pts=(pointsI-repmat(center,size_pointsI,1))*R+repmat(t1',[size_pointsI 1])+repmat(center,size_pointsI,1);

size_pointsJ=size(pointsJ,1);

invpts=(pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*invR+repmat(center,size_pointsJ,1);

%allocating space for results and image-functional (NMI) derivatives
d=zeros([ size(pts) size(comp_vec,1)]);
invd=zeros([ size(invpts) size(comp_vec,1)]);
res=zeros(size(comp_vec,1),1);
invres=zeros(size(comp_vec,1),1);
%looping over combinations of images
for k=1:size(comp_vec,1)
%getting indices
j=comp_vec(k,2);
i=comp_vec(k,1);

%for image I(i)
%get image specific affine transformation
J_rig=J_aff(:,j);    
%apply image specific affine transformation
[pts_, invRJ]=do_affine_inv(J_rig(:),pts,J_center(j,:));    

%compute similarity    
[res(k), d1, d2, d3]=NMI(pts_,squeeze(Itrival(:,i))+2,HTJ(j).bimg+2,offsetJ(:,j)',scaleJ(j,:),detI);
%correct gradients for image specific affine transformation
d(:,:,k)=[d1 d2 d3]*invRJ ;


%for image J(j)
%get image specific affine transformation
I_rig=I_aff(:,i);    
%apply image specific affine transformation
[invpts_, invRI]=do_affine_inv(I_rig(:),invpts,I_center(i,:));  

%compute similarity    
[invres(k), idl1, idl2, idl3]=NMI(invpts_,squeeze(Jtrival(:,j))+2,HTI(i).bimg+2,offsetI(:,i)',scaleI(i,:),detJ);
%correct gradients for image specific affine transformation
invd(:,:,k)=[idl1 idl2 idl3]*invRI;
end
%sum similarity both ways
res=sum(res);
invres=sum(invres);

%sum derivatives
d=sum(d,3);
invd=sum(invd,3);
%and correct for global inverse affine
id=invd*invR';
 
%compute symmetric derivatives for global affine
df(10)=sum(d(:,1))-sum(id(:,1));
df(11)=sum(d(:,2))-sum(id(:,2));
df(12)=sum(d(:,3))-sum(id(:,3));

df(1)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR1.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(1,:,:)).*invd,2));
df(2)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR2.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(4,:,:)).*invd,2));
df(3)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR3.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(7,:,:)).*invd,2));
df(4)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR4.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(2,:,:)).*invd,2));
df(5)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR5.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(5,:,:)).*invd,2));
df(6)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR6.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(8,:,:)).*invd,2));
df(7)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR7.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(3,:,:)).*invd,2));
df(8)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR8.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(6,:,:)).*invd,2));
df(9)=sum(sum((pointsI-repmat(center,size_pointsI,1))*dR9.*d,2))+sum(sum((pointsJ-repmat(center,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*squeeze(dinvR(9,:,:)).*invd,2));



disp([res invres p']);
%p=p';
f=4*(size(comp_vec,1))-(res+invres);
