function doseTot = getTotalDose(pt)

% Calculates total dose distribution from plan structure with dose saved
% for individual beams (possibly also from individual phases, e.g. primary
% and boost plan). Input data structure assumed to be MDACC plan structure
% Assumes that all dose matrices are defined on the same grid

% Get number of phases (primary, boost, etc) to plan
nPh = size(pt,2);
%nPh = 1;
% Get number of fractions for each phase
for i=1:nPh
    nFr(i) = pt(i).plan.nFr;
end
% Get number of beams per phase
for i=1:nPh
    nB(i) = size(pt(i).plan.beam,2);
end

% Save dose for each beam in seperate structure
for i=1:nPh
    for j=1:nB(i)
        dose(i,j) = pt(i).dMC(j);
    end
end

% Use first beam dose as template for total dose structure
doseTot = dose(1,1);
% Initial dose as zero
doseTot.imd = zeros(size(doseTot.imd));

% Sum dose from all beams
for i=1:nPh
    for j=1:nB(i)
        if isempty(dose(i,j).imd); continue; end
        doseTot.imd = doseTot.imd+dose(i,j).imd;
    end
end
doseTot.dmax = max(doseTot.imd(:));