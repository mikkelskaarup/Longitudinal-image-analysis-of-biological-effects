


if( strcmp(computer,'PCWIN64'))
% if(debug)
%    mex('.\..\..\..\C++\Regularization\EigenDerivN.cpp','-g', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib_db], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization\debug')
%    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbb.cpp','-g', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib_db], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization\debug')
%    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbbFast.cpp','-g', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib_db], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization\debug')
%    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbbFastOgden.cpp','-g', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib_db], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization\debug')
% 
% end
% if(~debug)
    mex('.\..\..\..\C++\Regularization\EigenDerivN.cpp', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization')
    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbb.cpp', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization')
    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbbFast.cpp', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization')
    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbbFastOgden.cpp', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization')
% end
else
% if(debug)
%    mex('.\..\..\..\C++\Regularization\EigenDerivN.cpp','-g', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib_db], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization\debug')
%    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbb.cpp','-g', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib_db], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization\debug')
%    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbbFast.cpp','-g', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib_db], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization\debug')
%    mex('.\..\..\..\C++\Regularization\EigenDerivN_tbbFastOgden.cpp','-g', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib_db], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', '.\..\..\..\Matlab\Regularization\debug')
% 
% end
% if(~debug)
    mex('./../../../C++/Regularization/EigenDerivN.cpp', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', './../../../Matlab/Regularization')
    mex('./../../../C++/Regularization/EigenDerivN_tbb.cpp', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', './../../../Matlab/Regularization')
    mex('./../../../C++/Regularization/EigenDerivN_tbbFast.cpp', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', './../../../Matlab/Regularization')
    mex('./../../../C++/Regularization/EigenDerivN_tbbFastOgden.cpp', ['-I' vxl_include_core], [ '-I' vxl_include_vcl], ['-I' vxl_include_platform_core], ['-I' vxl_include_platform_vcl], ['-L' vxl_lib], ['-L' tbb_lib],['-I' tbb_include], '-ltbb', '-ltbbmalloc', '-lvnl', '-lvnl_algo', '-lv3p_netlib' , '-outdir', './../../../Matlab/Regularization')
% end
end

%mex EigenDerivN.cpp -IC:\libs\vxl-1.14.0\vxl-1.14.0\core  -IC:\libs\vxl-1.14.0\vxl-1.14.0\vcl -IC:\libs\vxlbin\win64\core -IC:\libs\vxlbin\win64\vcl -LC:\libs\vxlbin\win64\lib\MinSizeRel -LC:\libs\tbb\tbb30_20100406oss\lib\intel64\vc9 -IC:\libs\tbb\tbb30_20100406oss\include -ltbb -ltbbmalloc -lvnl -lvnl_algo -lv3p_netlib