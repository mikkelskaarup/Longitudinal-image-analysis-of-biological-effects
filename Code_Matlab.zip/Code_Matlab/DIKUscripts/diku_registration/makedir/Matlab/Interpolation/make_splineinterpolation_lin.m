tbb_lib='C:\libs\tbb\tbb30_20100406oss\lib\intel64\vc9'
tbb_include='C:\libs\tbb\tbb30_20100406oss\include'
if( strcmp(computer,'PCWIN64'))
if(debug)
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_lin_tbb.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_lin.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_tbb.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_tbb_compact.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Interpolations\debug')
end
if(~debug)
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_lin_tbb.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir', '.\..\..\..\Matlab\Interpolations')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_lin.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , '.\..\..\..\Matlab\Interpolations')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_tbb.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , '.\..\..\..\Matlab\Interpolations')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation_tbb_compact.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , '.\..\..\..\Matlab\Interpolations')
    mex('.\..\..\..\C++\Interpolation\SplineInterpolation.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir' , '.\..\..\..\Matlab\Interpolations')
end
end