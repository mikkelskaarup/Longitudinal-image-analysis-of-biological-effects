tbb_lib='C:\libs\tbb\tbb30_20100406oss\lib\intel64\vc9'
tbb_include='C:\libs\tbb\tbb30_20100406oss\include'
if( strcmp(computer,'PCWIN64'))
if(debug)
    mex('.\..\..\..\C++\Similarity\NMI3D_DET_PVPW_LINPW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\NMI3D_DET_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\PNorm3D.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\PNorm3D_LIN.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
end
if(~debug)
    mex('.\..\..\..\C++\Similarity\NMI3D_DET_PVPW_LINPW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\NMI3D_DET_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\PNorm3D.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\PNorm3D_LIN.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
end
end
%mex NMI3D_DET_PVPW_LINPW.cpp -g -LC:\libs\tbb\tbb30_20100406oss\lib\intel64\vc9 -IC:\libs\tbb\tbb30_20100406oss\include -ltbb -ltbbmalloc
