mex NMI3D_DET_PW3.cpp -g -LC:\libs\tbb\tbb30_20100406oss\lib\intel64\vc9 -IC:\libs\tbb\tbb30_20100406oss\include -ltbb -ltbbmalloc
mex MI3D_DET_PW3.cpp -g -LC:\libs\tbb\tbb30_20100406oss\lib\intel64\vc9 -IC:\libs\tbb\tbb30_20100406oss\include -ltbb -ltbbmalloc
