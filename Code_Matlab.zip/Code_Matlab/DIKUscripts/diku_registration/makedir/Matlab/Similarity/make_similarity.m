
if( strcmp(computer,'PCWIN64'))
if(debug)
    mex('.\..\..\..\C++\Similarity\NMI3D_DET_PVPW_LINPW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\NMI3D_DET_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\PNorm3D.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\PNorm3D_LIN.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\PNorm_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\HuberNorm_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\HingePNorm_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\Cauchy_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\Forsyth_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    mex('.\..\..\..\C++\Similarity\TurkyBeaton_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
    
end
if(~debug)
    mex('.\..\..\..\C++\Similarity\NMI3D_DET_PVPW_LINPW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\NMI3D_DET_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\PNorm3D.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\PNorm3D_LIN.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
     mex('.\..\..\..\C++\Similarity\PNorm_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\HuberNorm_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\HingePNorm_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\Cauchy_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\Forsyth_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
    mex('.\..\..\..\C++\Similarity\TurkyBeaton_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
  
end
else
if(debug)
    mex('./../../../C++/Similarity/NMI3D_DET_PVPW_LINPW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    mex('./../../../C++/Similarity/NMI3D_DET_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    mex('./../../../C++/Similarity/PNorm3D.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    mex('./../../../C++/Similarity/PNorm3D_LIN.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
     mex('./../../../C++/Similarity/PNorm_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    mex('./../../../C++/Similarity/HuberNorm_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    mex('./../../../C++/Similarity/HingePNorm_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    mex('./../../../C++/Similarity/Cauchy_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    mex('./../../../C++/Similarity/Forsyth_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    mex('./../../../C++/Similarity/TurkyBeaton_PW.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
    

end
if(~debug)
    mex('./../../../C++/Similarity/NMI3D_DET_PVPW_LINPW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/NMI3D_DET_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
  mex('./../../../C++/Similarity/NMI3D_DET_PW_TEST.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
   mex('./../../../C++/Similarity/NMI3D_DET_PW_LIN3.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/PNorm3D.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/PNorm3D_LIN.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/PNorm_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/HuberNorm_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/HingePNorm_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/Cauchy_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/Forsyth_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    mex('./../../../C++/Similarity/TurkyBeaton_PW.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
    

end

end
%mex NMI3D_DET_PVPW_LINPW.cpp -g -LC:\libs\tbb\tbb30_20100406oss\lib\intel64\vc9 -IC:\libs\tbb\tbb30_20100406oss\include -ltbb -ltbbmalloc
