
if( strcmp(computer,'PCWIN64'))
if(debug)
    mex('.\..\..\..\C++\Utility\dDdPFunc.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity\debug')
end
if(~debug)
    mex('.\..\..\..\C++\Utility\dDdPFunc.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','.\..\..\..\Matlab\Similarity')
end
else
if(debug)
    mex('./../../../C++/Utility/dDdPFunc.cpp','-g', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity/debug')
end
if(~debug)
    mex('./../../../C++/Utility/dDdPFunc.cpp', ['-L' tbb_lib],['-I' tbb_include], '-ltbb' ,'-ltbbmalloc','-outdir','./../../../Matlab/Similarity')
end

end
%mex NMI3D_DET_PVPW_LINPW.cpp -g -LC:\libs\tbb\tbb30_20100406oss\lib\intel64\vc9 -IC:\libs\tbb\tbb30_20100406oss\include -ltbb -ltbbmalloc
