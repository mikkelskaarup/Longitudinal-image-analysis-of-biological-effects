// SplineInterpolation.cpp : Defines the entry point for the console application.
//

#include <math.h>
#include <matrix.h>
#include <mex.h>





void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
const mxArray *prhs[])
{

  if(nrhs==0)
			mexPrintf("PNorm_leveset takes 4 arguments,image data, level set, p including lambda1 and 2, and mu");
		if(nrhs!=4)
			mexErrMsgTxt("Number of arguments must be 4");
		//mexPrintf("Spline interpolation takes 4 arguments ");

		double* dataR = mxGetPr(prhs[0]);
		double* dataI = mxGetPr(prhs[1]);
		double* p = mxGetPr(prhs[2]);
		double* mu = mxGetPr(prhs[3]);

		//double* det = static_cast<double*>(mxGetData(prhs[7]));
		
		int N =(int)mxGetNumberOfElements(prhs[0]);
//*************************Matlab start**************************
		mwSize dims[2];
		mwSize dims2[1];

		dims2[0] = 1; 
		

		
		dims[0] = N; dims[1] = 1;
		
		double* diff1 ;
		bool do_deriv=false;
		if(nlhs>3)do_deriv=true;
		plhs[0] = mxCreateNumericArray(1,dims2,mxDOUBLE_CLASS, mxREAL);
		double* val = static_cast<double*>(mxGetData(plhs[0]));
		plhs[1] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff1 = static_cast<double*>(mxGetData(plhs[1]));
      
//*****************************Matlab end*******************************
		//mexPrintf("P[0]: %f range[0]: %f range[1]: %f\n",p[0],range[0],range[1]);
  int cls=(int)p[2];
        double mu_new[cls];
  double mu_old[cls]; 
  double tmp[cls];
  int n[cls];
  
        for (int l=0;l<cls;l++){
           mu_old[l]=((double)l/p[2])*abs(mu[1]-mu[0]);
       
        }
     
  
  for(int j=0;j<(int)p[1];j++){
        
      for (int l=0;l<cls;l++){
           mu_new[l]=0;
           n[l]=0;
           mexPrintf("mu %d: %f   ",l,mu_old[l]);
        }
      mexPrintf("\n");
      //  mexPrintf("P[0]: %f mu2: %f mu1: %f mu0: %f\n",p[0],mu2_old,mu1_old,mu0_old);
        for(int i=0;i<N;i++){
            
                double data_i = dataI[i];
                tmp[0] = pow( abs(data_i-mu_old[0]), p[0] );
                diff1[i]=0.0;
                
                for (int k=1;k<cls;k++){
                    tmp[k] = pow( abs(data_i-mu_old[k]), p[0] );       
                    if(tmp[0]>tmp[k])
                    diff1[i]=(double)k;
                    }
                    n[(int) diff1[i]]+=1;
                    mu_new[(int) diff1[i]]+=data_i;
                }
                
                
          // move mu_new into mu_old
       for (int l=0;l<cls;l++){
           if(n[l]>0)
           mu_old[l]=mu_new[l]/n[l];  
        }
        }
};
        
