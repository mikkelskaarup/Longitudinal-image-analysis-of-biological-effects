//**************************************************************
//Splineinterpolation_lin.cpp is authored by Sune Darkner and is provided as is
//The file may not be re-distributed without prior permission.
//The auther cannot in any circumstances be held reliable of
//damages, financial or other types of loses cased by the use
//or the use of derivative products from this file. The author
//cannot be held liable in any way under any circumstances.
//**************************************************************
#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <assert.h>
#include <vector>
#include <algorithm>
#include "SVF_trap.h"
using namespace std;




void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
        const mxArray *prhs[])
{
  
  //bool doDerivative = false;
  //if(nlhs>1)
  //    doDerivative = true;
  if(nrhs==0)
    mexPrintf("Spline interpolation takes 4 arguments ");
  if(nrhs<3)
    mexErrMsgTxt("Number of arguments must be 3");
  // mexPrintf("Spline interpolation takes 4 arguments ");
  double* pts = mxGetPr(prhs[0]);
  double* data = mxGetPr(prhs[1]);
  double* offset = mxGetPr(prhs[2]);
  double* scale=mxGetPr(prhs[3]);
  double *steps=mxGetPr(prhs[4]);
  double *iter=mxGetPr(prhs[5]);
  double* derivs = mxGetPr(prhs[6]);
  
  
  
 
  
  int ndim =(int)mxGetNumberOfDimensions(prhs[1]);
  int* dim_pts =(int*)mxGetDimensions(prhs[0]);
  //mexPrintf("%d",dim_pts[0]);
  int* dim_img=(int*)mxGetDimensions(prhs[1]);
  int* dim_offset=(int*)mxGetDimensions(prhs[2]);
  int* dim_scale=(int*)mxGetDimensions(prhs[3]);
  int N=dim_pts[0];
  //size_t N = mxGetNumberOfElements(prhs[0])/3;
  ////Allocate Tc
  mwSize dims[2];
  mwSize dims2[2];
  
  dims2[0] = 1;
  dims2[1] = N;
  
  mwSize dims3[3];
  
  dims3[0] = (int)steps[0];
  
  dims3[1] = 3;
  dims3[2] = N;
  dims[0] = N; dims[1] = 1;
  if(ndim>3){
    dims[1] = dim_img[3];
  }
  mwSize np[2];
  np[1]=1;
  np[0]=dim_img[0]*dim_img[1]*dim_img[2]*3;
  
  
  
  vector<double> ldata(np[0],0.0);
	for(int i=0;i<ldata.size();i++)ldata[i]=data[i];
  
	vector<int> ldims(2,1);
  for(int i=0;i<ldims.size();i++)ldims[i]=dims[i];
	
	vector<int> ldim_img(4,10);
  for(int i=0;i<ldim_img.size();i++)ldim_img[i]=dim_img[i];
	

  
	int lN=N;
	vector<double> lpts(3*lN,0.0);
	for(int i=0;i<lpts.size();i++)lpts[i]=pts[i];
  vector<double> lval(3*lN,0.0);
	vector<double> loffset(3,0.0);
	for(int i=0;i<loffset.size();i++)loffset[i]=offset[i];
  
  vector<double> lscale(3,20.0);
  for(int i=0;i<lscale.size();i++)lscale[i]=scale[i];
    int liter=(int)iter[0];
	int lsteps=(int)steps[0];
	vector<int> lncnt(lN,lsteps*8);
 
  

	vector<double> lderivs(3*lN,0);
	for(int i=0;i<lderivs.size();i++)lderivs[i]=derivs[i];
  vector<double> ldvdp(ldata.size(),0);
	
	SVF_TRAP(&ldata[0], 	&ldims[0],
			&ldim_img[0],
			&lpts[0],
			lN,
			&loffset[0],
			&lscale[0],
			lsteps,
			&lncnt[0],
			liter,
			&lderivs[0],
			&lval[0],
			&ldvdp[0]);
  
  
    plhs[0] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
    double* val = static_cast<double*>(mxGetData(plhs[0]));
    for(int i=0;i<lval.size();i++)val[i]=lval[i];
    plhs[1] = mxCreateNumericArray(2,np,mxDOUBLE_CLASS, mxREAL);
    double* dvdp = static_cast<double*>(mxGetData(plhs[1]));
    for(int i=0;i<ldvdp.size();i++)dvdp[i]=ldvdp[i];
    
};