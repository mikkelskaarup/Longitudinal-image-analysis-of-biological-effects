// SplineInterpolation.cpp : Defines the entry point for the console application.
//

#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <vector>
#include <algorithm>

using namespace std;



void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
        const mxArray *prhs[])
{
    
    //bool doDerivative = false;
    //if(nlhs>1)
    //    doDerivative = true;
    if(nrhs==0)
        mexPrintf("Spline interpolation takes 4 arguments ");
     // mexPrintf("Spline interpolation takes 4 arguments ");
    double* pts = static_cast<double*>(mxGetData(prhs[0]));
    double* data = static_cast<double*>(mxGetData(prhs[1]));
    double* offset = static_cast<double*>(mxGetData(prhs[2]));
    double* Idata = static_cast<double*>(mxGetData(prhs[3]));
    double scale[3]={1.0 ,1.0 ,1.0};
    //int* dx = static_cast<double*>(mxGetData(prhs[2]));
    
    int ndim =(int)mxGetNumberOfDimensions(prhs[1]);
    int* dim_pts =(int*)mxGetDimensions(prhs[0]);
    //mexPrintf("%d",dim_pts[0]);
    int* dim_img=(int*)mxGetDimensions(prhs[1]);
    int* dim_offset=(int*)mxGetDimensions(prhs[2]);
    
    int N=dim_pts[0];
    //size_t N = mxGetNumberOfElements(prhs[0])/3;
    ////Allocate Tc
    mwSize dims[2];
    mwSize dims2[2];
    
    dims2[0] = 1;
    dims2[1] = N;
    
    mwSize dims3[3];
    
    dims3[0] = 64;
    dims3[1] = 3;
    dims3[2] = N;
    dims[0] = 1; dims[1] = 1;
    if(ndim>3){
        dims[1] = dim_img[3];
    }
   
    
    std::vector<double> val(N,0.0);
//     
    plhs[0] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
    double* res = static_cast<double*>(mxGetData(plhs[0]));
    plhs[1] = mxCreateNumericArray(2,dims2,mxDOUBLE_CLASS, mxREAL);
    double* df = static_cast<double*>(mxGetData(plhs[1]));
//     plhs[2] = mxCreateNumericArray(2,dims2,mxINT32_CLASS, mxREAL);
//     int* idx = static_cast<int*>(mxGetData(plhs[2]));
//     
    
    res[0]=0;
    int s;
    s=64;
//    double dfdp[s];
//    int idx[s];
    double dfdp[64];
    int idx[64];
    
    int idx_idx=0;
    for(int i=0;i<N;i++){
        val[i]=0;
        
        double t=(pts[i]-offset[0])/scale[0]-floor((pts[i]-offset[0])/scale[0]);
        double t2=t*t;
        double t3=t2*t;
        
        /*double* x={-pow(t,3)+3*pow(t,2)-3*t+1, 3*pow(t,3)-6*pow(t,2)+4, -3*pow(t,3)+3*pow(t,2)+3*t+1,  pow(t,3)};
         * double* dx={-pow(t,3)+3*pow(t,2)-3*t+1, 3*pow(t,3)-6*pow(t,2)+4, -3*pow(t,3)+3*pow(t,2)+3*t+1,  pow(t,3)};
         */
        double x[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
        t=floor((pts[i]-offset[0])/scale[0]);
        int px[4]={(int)min<double>(max<double>(t-1,0),dim_img[0]-1),(int) max<double>(min<double>(t,dim_img[0]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[0]-1),(int) max<double>(min<double>(t+2,dim_img[0]-1),0)};
        
        t=(pts[i+N]-offset[1])/scale[1]-floor((pts[i+N]-offset[1])/scale[1]);
        t2=t*t;
        t3=t2*t;
        
        double y[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
        t=floor((pts[i+N]-offset[1])/scale[1]);
        int py[4]={(int)min<double>(max<double>(t-1,0),dim_img[1]-1),(int) max<double>(min<double>(t,dim_img[1]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[1]-1),(int) max<double>(min<double>(t+2,dim_img[1]-1),0)};
        
        t=(pts[i+2*N]-offset[2])/scale[2]-floor((pts[i+2*N]-offset[2])/scale[2]);
        t2=t*t;
        t3=t2*t;
        
        double z[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
        t=floor((pts[i+2*N]-offset[2])/scale[2]);
        int pz[4]={(int)min<double>(max<double>(t-1,0),dim_img[2]-1),(int) max<double>(min<double>(t,dim_img[2]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[2]-1),(int) max<double>(min<double>(t+2,dim_img[2]-1),0)};
        int index=0;
        int m=0;
        idx_idx=0;
        for(int j=0;j<4;j++){
            for(int k=0;k<4;k++){
                for(int l=0;l<4;l++){
                    
                    //			mexPrintf("%f %d %d %d \n",data[px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j]+dim_img[0]*dim_img[1]*dim_img[2]*m],px[l],py[k],pz[j]);
                    
                    idx[idx_idx]=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
                    dfdp[idx_idx]=x[l]*y[k]*z[j]/216;
                    idx_idx++;
                    
                    double dd=data[idx[idx_idx-1]];
                    
                    
                    val[i]+=dfdp[idx_idx-1]*dd;
                    
                    
                }
            }
        }
     
    }
        for(int i=0;i<N;i++){
        
        double t=(pts[i]-offset[0])/scale[0]-floor((pts[i]-offset[0])/scale[0]);
        double t2=t*t;
        double t3=t2*t;
        
        /*double* x={-pow(t,3)+3*pow(t,2)-3*t+1, 3*pow(t,3)-6*pow(t,2)+4, -3*pow(t,3)+3*pow(t,2)+3*t+1,  pow(t,3)};
         * double* dx={-pow(t,3)+3*pow(t,2)-3*t+1, 3*pow(t,3)-6*pow(t,2)+4, -3*pow(t,3)+3*pow(t,2)+3*t+1,  pow(t,3)};
         */
        double x[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
        t=floor((pts[i]-offset[0])/scale[0]);
        int px[4]={(int)min<double>(max<double>(t-1,0),dim_img[0]-1),(int) max<double>(min<double>(t,dim_img[0]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[0]-1),(int) max<double>(min<double>(t+2,dim_img[0]-1),0)};
        
        t=(pts[i+N]-offset[1])/scale[1]-floor((pts[i+N]-offset[1])/scale[1]);
        t2=t*t;
        t3=t2*t;
        
        double y[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
        t=floor((pts[i+N]-offset[1])/scale[1]);
        int py[4]={(int)min<double>(max<double>(t-1,0),dim_img[1]-1),(int) max<double>(min<double>(t,dim_img[1]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[1]-1),(int) max<double>(min<double>(t+2,dim_img[1]-1),0)};
        
        t=(pts[i+2*N]-offset[2])/scale[2]-floor((pts[i+2*N]-offset[2])/scale[2]);
        t2=t*t;
        t3=t2*t;
        
        double z[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
        t=floor((pts[i+2*N]-offset[2])/scale[2]);
        int pz[4]={(int)min<double>(max<double>(t-1,0),dim_img[2]-1),(int) max<double>(min<double>(t,dim_img[2]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[2]-1),(int) max<double>(min<double>(t+2,dim_img[2]-1),0)};
        int index=0;
        idx_idx=0;
        int m=0;
        for(int j=0;j<4;j++){
            for(int k=0;k<4;k++){
                for(int l=0;l<4;l++){
                    
                    //			mexPrintf("%f %d %d %d \n",data[px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j]+dim_img[0]*dim_img[1]*dim_img[2]*m],px[l],py[k],pz[j]);
                    
                    idx[idx_idx]=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
                    dfdp[idx_idx]=x[l]*y[k]*z[j]/216;
                    idx_idx++;
                    
                    
                    
                    
                }
            }
        }
        idx_idx=0;
        for(int j=0;j<s;j++)
        {
            
            
            
            df[idx[j]]+=dfdp[j]*(val[idx[j]]-Idata[idx[j]]);
            //mexPrintf("%f ",ldf[(int)idx[i*s+j]]);
            
            
        }
        res[0]+=(val[i]-Idata[i])*(val[i]-Idata[i]);
    }
    res[0]=res[0]*0.5;

 
  


};