// EigenDeriv.cpp : Defines the entry point for the console application.


#include <math.h>
#include <mex.h>
#include <matrix.h>
#include <vector>
#include <vnl/vnl_matrix.h>
#include <vnl/algo/vnl_determinant.h>
#include <vnl/algo/vnl_symmetric_eigensystem.h>
#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/spin_mutex.h"

using namespace std;


using namespace tbb;
typedef spin_mutex MyMutexType;
	MyMutexType MyMutex;
	MyMutexType MyMutex2;
class EigenDerivTBB
{
	
	

private:
	int* dim_p;
	int* dim_simp;
	int* dim_ad;
	double* p ;
	double* simp;
	double* Ad ;
	double* lambda;
	double* mu ;
	int p_space;
	int poly_space;
	int* dim_mu;
	mwSize dim,dim2;
	double* drdp;
	double* r;
	double* f;
    int N;


	




public:
	EigenDerivTBB(int* vdim_p,int* vdim_simp,int* vdim_ad,double* vp,double* vsimp,double* vAd,double* vlambda,double* vmu ,int vp_space,int vpoly_space,double* vdrdp,double* vr,	double* vf, int* vdim_mu, int vN) 
	{
		dim_mu=vdim_mu;
dim_p=vdim_p;
dim_simp=vdim_simp;
	dim_ad=vdim_ad;
	p=vp;
	simp=vsimp;
	Ad=vAd;
	lambda= vlambda;
	mu=vmu;
	p_space=vp_space;
	poly_space=	vpoly_space;
	drdp=vdrdp;
	r=vr;
	f=vf;
    N=vN;


	//this->MyMutex=new MyMutexType[dim_simp[0]];
	}

	void operator()(const blocked_range<int> & rr) const
	{

        double *ldrdp=new double[N];
        
		vnl_matrix<double> p_m(poly_space,p_space);
		vnl_matrix<double> Ad_m(poly_space,p_space);
		vnl_matrix<int> indices(poly_space,p_space);
		vnl_matrix<double> PIJ(p_space,poly_space,0);
		vnl_matrix<double> I_m(p_space,p_space);
		I_m.set_identity();
		vnl_matrix<double> E_m(p_space,p_space);
		vnl_matrix<double> nablaPhi_m(p_space,p_space);
		vnl_matrix<double> eigen_vectors(p_space,p_space);
		vnl_vector<double> eigenvalues(p_space);
		vnl_vector<double> log_eigenvalues(p_space);
		vnl_vector<double> inv_eigenvalues(p_space);
		vnl_vector<double> drepsilon(p_space);
		vnl_matrix<double> K_m(p_space,p_space);
			double m_,p_,q_,phi_,sq_p_,cos_phi,sin_phi_sqrt3;
		
			double sum_log_eigs;
	double sum_log_eigs_sq;
		double sum_eigs;
		double lr=0;
		int lam_mu=0;
//			double a,b,c,d,x,y,z,i_,j_,k_,l_,m_,n_,p_;
	double eig_val[3]={0,0,0};
         for (int j=0;j<N;j++)ldrdp[j]=0;
        
        for(int i=rr.begin();i!=rr.end();i++)
		{
				if(dim_mu[0]>1)
					lam_mu=i;
				vector<int> vertices;
				for (int j=0;j<poly_space;j++){
					vertices.push_back((int)simp[i+(j*dim_simp[0])]-1);
					int l_index=vertices[j];		
					for (int k=0;k<p_space;k++){
						l_index=vertices[j]+k*dim_p[0];
						p_m.put(j,k,p[l_index]);
						Ad_m.put(j,k,Ad[i*dim_ad[0]*dim_ad[1]+k*dim_ad[0]+j]);
					}
				}
				nablaPhi_m=I_m+p_m.transpose()*Ad_m;
				double det=nablaPhi_m.get(0,0)*nablaPhi_m.get(1,1)*nablaPhi_m.get(2,2)-nablaPhi_m.get(0,0)*nablaPhi_m.get(1,2)*nablaPhi_m.get(2,1)-
			nablaPhi_m.get(1,0)*nablaPhi_m.get(0,1)*nablaPhi_m.get(2,2)+nablaPhi_m.get(1,0)*nablaPhi_m.get(0,2)*nablaPhi_m.get(2,1)+
			nablaPhi_m.get(2,0)*nablaPhi_m.get(0,1)*nablaPhi_m.get(1,2)-nablaPhi_m.get(2,0)*nablaPhi_m.get(0,2)*nablaPhi_m.get(1,1);
//		mexPrintf("After Determinant/n");

		if(det<0){
			f[0]=mxGetInf();
			return;
		}
		sum_eigs=0;
		sum_log_eigs=0;
		sum_log_eigs_sq=0;
		E_m=nablaPhi_m*nablaPhi_m.transpose();
		m_ = (E_m.get(0,0)+E_m.get(1,1)+E_m.get(2,2))/3;
		K_m = E_m-m_*I_m;
		//mexPrintf("K_m\n");
		//printMatrixMatlab(K_m);
		//mexPrintf("\n");
		
		q_ = (K_m.get(0,0)*K_m.get(1,1)*K_m.get(2,2)-K_m.get(0,0)*K_m.get(1,2)*K_m.get(2,1)-
			K_m.get(1,0)*K_m.get(0,1)*K_m.get(2,2)+K_m.get(1,0)*K_m.get(0,2)*K_m.get(2,1)+
			K_m.get(2,0)*K_m.get(0,1)*K_m.get(1,2)-K_m.get(2,0)*K_m.get(0,2)*K_m.get(1,1))/2;
		
		p_ = 0;
		p_ += K_m.get(0,0)*K_m.get(0,0);
		p_ += K_m.get(0,1)*K_m.get(0,1);
		p_ += K_m.get(0,2)*K_m.get(0,2);
		p_ += K_m.get(1,0)*K_m.get(1,0);
		p_ += K_m.get(1,1)*K_m.get(1,1);
		p_ += K_m.get(1,2)*K_m.get(1,2);
		p_ += K_m.get(2,0)*K_m.get(2,0);
		p_ += K_m.get(2,1)*K_m.get(2,1);
		p_ += K_m.get(2,2)*K_m.get(2,2);
		
		p_ = p_/6;
 
//% NOTE: the follow formula assume accurate computation and therefor q/p^(3/2) should be in range of [1,-1], 
//% but in real code, because of numerical errors, it must be checked. Thus,
//% in case abs(q) > abs(p^(3/2)), set phi = 0;
		sq_p_=sqrt(p_);
		//mexPrintf("acos %f\n",acos((double)q_/(p_*sq_p_)));
		phi_ = acos((double)q_/(p_*sq_p_))/3;
		//mexPrintf("phi1: %f\n",phi_);
		if(abs(q_)>abs(p_*sq_p_)) phi_ = 0;
		
			//phi_ = 1/3*acos(q_/(p_*sq_p_));
		//mexPrintf("phi2: %f\n",phi_);
		if(phi_<0)
			phi_=phi_+ 3.14159265358979323846 /3;
		cos_phi=cos(phi_);
		sin_phi_sqrt3=sqrt((double)3)*sin(phi_);
		//mexPrintf("phi3: %f\n",phi_);
		eig_val[0] = m_ + 2*sq_p_*cos_phi;
		eig_val[1] = m_ - sq_p_*(cos_phi + sin_phi_sqrt3);
		eig_val[2] = m_ - sq_p_*(cos_phi - sin_phi_sqrt3);
		

		//vnl_symmetric_eigensystem<double> eig(E_m);		
		for (unsigned int j=0;j<p_space;j++){
		/*	if(eig.get_eigenvalue(j)<=0){
				f[0]=mxGetInf();			
				return;
			}*/
			sum_eigs+=eig_val[j];
			sum_log_eigs+=log(eig_val[j]);
			sum_log_eigs_sq+=pow(log(eig_val[j]),2);
			log_eigenvalues.put(j,log(eig_val[j]));
			inv_eigenvalues.put(j,1/(eig_val[j]));
		//	mexPrintf("%f\n",eig_val[j]);
			
			eigen_vectors.put(j,0,E_m.get(0,1)*E_m.get(1,2) - E_m.get(0,2)*(E_m.get(1,1)-eig_val[j]));
			eigen_vectors.put(j,1,E_m.get(0,1)*E_m.get(0,2) - E_m.get(1,2)*(E_m.get(0,0)-eig_val[j]));
			eigen_vectors.put(j,2,(E_m.get(0,0)-eig_val[j])*(E_m.get(1,1)-eig_val[j]) - E_m.get(0,1)*E_m.get(0,1));

			//eigen_vectors.set_row(j,eig.get_eigenvector(j));
			
		}
		eigen_vectors.normalize_rows();
	
				for (unsigned int j=0;j<p_space;j++){
					drepsilon.put(j,mu[lam_mu]/2*inv_eigenvalues.get(j)*log_eigenvalues.get(j)+lambda[lam_mu]/4*inv_eigenvalues.get(j)*sum_log_eigs);	
				}
				for (unsigned int j=0;j<poly_space;j++){
					for(unsigned int k=0;k<p_space;k++){
						indices.put(j,k,vertices[j]+k*dim_p[0]);
					}
				}

				vnl_matrix<double> tmp=Ad_m*nablaPhi_m.transpose()*eigen_vectors.transpose();
				vnl_matrix<int> it=indices.transpose();
				for (unsigned int j=0;j<poly_space;j++){
					for(unsigned int k=0;k<p_space;k++){
						for (unsigned int l=0;l<E_m.rows();l++){
							//MyMutexType::scoped_lock lock(MyMutex);
							
	/*						drdp[it(k,j)];
							2*eigen_vectors.get(l,k);
							tmp.get(j,l);
							drepsilon.get(l);*/



							ldrdp[it(k,j)]=ldrdp[it(k,j)]+2*eigen_vectors.get(l,k)*tmp.get(j,l)*drepsilon.get(l);
						}

					}
				}
				
				lr+=mu[lam_mu]/4*sum_log_eigs_sq+lambda[lam_mu]/8*pow(sum_log_eigs,2);
//				mexPrintf("%d \n",i);
		}
		{
		MyMutexType::scoped_lock lock(MyMutex2);
		r[0]+=lr;
		}
        {
        MyMutexType::scoped_lock lock(MyMutex);
        for (int j=0;j<N;j++)drdp[j]=drdp[j]+ldrdp[j];
        }
        delete ldrdp;
	}

	double b0(int j, double xi) const
	{
		return 0;
	}
	double db0(int j, double xi) const
	{
		return 0;
	}


};

void printMatrixMatlab(vnl_matrix<double> m){

	for(int i=0;i<m.rows();i++){
		for(int j=0;j<m.cols();j++){
			mexPrintf("%f ", m.get(i,j));
		}
		mexPrintf("\n");
	}

}
void printMatrixMatlab(vnl_matrix<int> m){

	for(int i=0;i<m.rows();i++){
		for(int j=0;j<m.cols();j++){
			mexPrintf("%d ", m.get(i,j));
		}
		mexPrintf("\n");
	}

}



void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
				 const mxArray *prhs[])
{
	int* dim_p =(int*)mxGetDimensions(prhs[0]);
	int* dim_simp=(int*)mxGetDimensions(prhs[1]);
	int* dim_ad=(int*)mxGetDimensions(prhs[2]);
	int* dim_mu=(int*)mxGetDimensions(prhs[4]);


	double* p = static_cast<double*>(mxGetData(prhs[0]));
	double* simp = static_cast<double*>(mxGetData(prhs[1]));
	double* Ad = static_cast<double*>(mxGetData(prhs[2]));
	double* lambda = static_cast<double*>(mxGetData(prhs[3]));
	double* mu = static_cast<double*>(mxGetData(prhs[4]));

	int p_space=dim_ad[1];
	int poly_space=dim_ad[0];
	double sum_eigs;
	double sum_log_eigs;
	double sum_log_eigs_sq;

	mwSize dim[1],dim2[1];
	dim[0]=dim_p[0]*dim_p[1];
	dim2[0]=1;

	//vnl_matrix<double> p_m(poly_space,p_space);
	//vnl_matrix<double> Ad_m(poly_space,p_space);
	//vnl_matrix<int> indices(poly_space,p_space);
	//vnl_matrix<double> PIJ(p_space,poly_space,0);
	//vnl_matrix<double> I_m(p_space,p_space);
	//I_m.set_identity();
	//vnl_matrix<double> E_m(p_space,p_space);
	//vnl_matrix<double> nablaPhi_m(p_space,p_space);
	//vnl_matrix<double> eigen_vectors(p_space,p_space);
	//vnl_vector<double> eigenvalues(p_space);
	//vnl_vector<double> log_eigenvalues(p_space);
	//vnl_vector<double> inv_eigenvalues(p_space);
	//vnl_vector<double> drepsilon(p_space);
	plhs[0] = mxCreateNumericArray(1,dim,mxDOUBLE_CLASS, mxREAL);
	double* drdp = static_cast<double*>(mxGetData(plhs[0]));
	plhs[1] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
	double* r = static_cast<double*>(mxGetData(plhs[1]));
	plhs[2] = mxCreateNumericArray(1,dim2,mxDOUBLE_CLASS, mxREAL);
	double* f = static_cast<double*>(mxGetData(plhs[2]));
	
	r[0]=0;
	f[0]=0;
	int N=dim_simp[0];
//	mexPrintf("Start \n");	
	parallel_for(blocked_range<int>(0,N),EigenDerivTBB(dim_p,dim_simp,dim_ad,p,simp,Ad,lambda,mu ,p_space,poly_space,drdp,r,f,dim_mu,dim[0]),auto_partitioner());
    return;

//EigenDerivTBB(int* vdim_p,int* vdim_simp,int* vdim_ad,double* vp,double* vsimp,double* vAd,double* vlambda,double* vmu ,int vp_space,int vpoly_space,mwSize vdim,mwSize vdim2,double* vdrdp,double* vr,	double* vf) 
}

