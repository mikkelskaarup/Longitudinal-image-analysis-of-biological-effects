
//

#include <math.h>
#include <matrix.h>
#include <mex.h>



#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/spin_mutex.h"
using namespace tbb;
typedef spin_mutex MyMutexType;
MyMutexType MyMutex;
class interp
{
private:
	//	mwSize* dims;
	double* d ;
	double* dfdp ;
	double*	dDdP;
    int* idx ;
	int N;
    int Np;
	
	

public:
	interp(double* vd,double* vdfdp,double* vdDdP,int* vidx, int vN, int vNp) {
			d=vd;
			dfdp=vdfdp;
			dDdP=vdDdP;
			idx=vidx;
			N=vN;
            Np=vNp;
		

	}

	void operator()(const blocked_range<int> & r) const
	{

        double* pdDdp=new double[(int)(3*Np)];
			
		int s=64;
		for(int k=0;k<3*Np;k++)pdDdp[k]=0;
		int j;
		//mexPrintf("initialized!!");
		for(int i=r.begin();i!=r.end();i++)
		{
            j=2;
            
            //mexPrintf("%d \n",i);
                pdDdp[idx[i]]+=dfdp[i]*d[j];
                pdDdp[idx[i]+Np]+=dfdp[i]*d[j+N];
                pdDdp[idx[i]+2*Np]+=dfdp[i]*d[j+2*N];
            
            

        }
//         {
//             MyMutexType::scoped_lock lock(MyMutex);
//             for(int j=0;j<3*Np;j++){
//        //         dDdP[j]=dDdP[j]+pdDdp[j];
//                 
// 
//             }
//         }
        delete pdDdp;
    }
};




	void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
		const mxArray *prhs[])
	{

		//bool doDerivative = false;
		//if(nlhs>1)
		//    doDerivative = true;
		//mexPrintf("Spline interpolation takes 4 arguments ");
		double* d = static_cast<double*>(mxGetData(prhs[0]));
		double* dfdp = static_cast<double*>(mxGetData(prhs[1]));
		int* idx = static_cast<int*>(mxGetData(prhs[2]));
		int* dim_p = static_cast<int*>(mxGetData(prhs[3]));
		
		int* dim_d =(int*)mxGetDimensions(prhs[0]);
		int N=dim_d[0];
        int Np=dim_p[0];
		////Allocate Tc
		mwSize dims[2];
		mexPrintf("%d %d %d",N,Np,dim_p[0]);
		dims[0] = dim_p[0]; dims[1] = 3;
		
		plhs[0] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		double* dDdP = static_cast<double*>(mxGetData(plhs[0]));
		for(int i=0;i<3*Np;i++)dDdP[i]=0;
		
		parallel_for(blocked_range<int>(0,N*64),interp(d,dfdp,dDdP,idx,N,Np),auto_partitioner());
		
		return;




	};