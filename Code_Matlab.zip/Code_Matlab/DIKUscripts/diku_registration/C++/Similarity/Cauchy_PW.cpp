// splineinterpolation2d.cpp : Defines the entry point for the console application.
//


#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <vector>
#include <omp.h>


#include "tbb/task_scheduler_init.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/spin_mutex.h"
using namespace std;
using namespace tbb;
typedef spin_mutex MyMutexType;
MyMutexType MyMutex;
MyMutexType MyMutex2;
MyMutexType MyMutex3;
MyMutexType MyMutex4;
class interp
{
private:
	//	mwSize* dims;
	double* pts ;
	double* dataI ;
	double* dataR ;
	double* offset ;
	double* range;
	double* scale;
	int ndim ;
	int* dim_pts ;
	int* dim_img;
	int* dim_offset;
	int* dim_scale;
	int N;
	double* no_bins;
	double* pI ;
	double* pR ;
	double* pRI;
    double* det;
    double* sumDet;
	double* dfdx;
	double* diff1 ;
	double* diff2 ;
	double* diff3 ;
    double* weight ;
	double p;
	double d;
	double* vall;
	

public:
	interp(double* vpts,double* vdataI,double* vdataR,double* voffset,double* vscale,int vndim,int* vdim_pts,int* vdim_img,int* vdim_offset,int* vdim_scale,
		int vN,mwSize* vdims,double* vrange, double* vno_bins,	double* vdiff1 ,double* vdiff2,	double* vdiff3,double* vval,double vp, double* vweight, double vd ) {
			pts=vpts;
			dataI=vdataI;
			dataR=vdataR;
			p=vp;
			vall=vval;
			no_bins=vno_bins;
			range=vrange;
			offset=voffset;
			scale=vscale;
			ndim=vndim;
			dim_pts=vdim_pts;
			dim_img=vdim_img;
			dim_offset=vdim_offset;
			dim_scale=vdim_scale;
			N=vN;
            weight=vweight;
            //sumDet=vsumDet;
		d=vd;	
		diff1=vdiff1;
			diff2=vdiff2;
			diff3=vdiff3;
	//		dfdx=vdfdx;
		

	}

	void operator()(const blocked_range<int> & r) const
	{

double sumdfdp=0;
			
		int s=64;
		int idx_idx=0;
		double lval=0;
		
		for(int i=r.begin();i!=r.end();i++)
		{
            //lsumDet+=1/det[i];
			double t=(pts[i]-offset[0])/scale[0]-floor((pts[i]-offset[0])/scale[0]);
			double t2=t*t;
			double t3=t2*t;

			double x[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double dx[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
			t=floor((pts[i]-offset[0])/scale[0])-1;
			int px[4]={(int)min<double>(max<double>(t-1,0),dim_img[0]-1),(int) max<double>(min<double>(t,dim_img[0]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[0]-1),(int) max<double>(min<double>(t+2,dim_img[0]-1),0)};

			t=(pts[i+N]-offset[1])/scale[1]-floor((pts[i+N]-offset[1])/scale[1]);
			t2=t*t;
			t3=t2*t;

			double y[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double dy[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
			t=floor((pts[i+N]-offset[1])/scale[1])-1;
			int py[4]={(int)min<double>(max<double>(t-1,0),dim_img[1]-1),(int) max<double>(min<double>(t,dim_img[1]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[1]-1),(int) max<double>(min<double>(t+2,dim_img[1]-1),0)};

			t=(pts[i+2*N]-offset[2])/scale[2]-floor((pts[i+2*N]-offset[2])/scale[2]);
			t2=t*t;
			t3=t2*t;

			double z[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double dz[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
			t=floor((pts[i+2*N]-offset[2])/scale[2])-1;

			int pz[4]={(int)min<double>(max<double>(t-1,0),dim_img[2]-1),(int) max<double>(min<double>(t,dim_img[2]-1),0),(int)min<double>(max<double>(t+1,0),dim_img[2]-1),(int) max<double>(min<double>(t+2,dim_img[2]-1),0)};

			idx_idx=i*64;
			int index=0;
			double valtjeck=0;
			int idxR=(int)floor((dataR[i]-range[2]));	
			t=(dataR[i])-floor(dataR[i]);
			t2=t*t;
			t3=t2*t;

			double tr_val[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double val=0;
			for(int j=0;j<4;j++){
				for(int k=0;k<4;k++){
					for(int l=0;l<4;l++){

						int idx=px[l]+dim_img[0]*py[k]+dim_img[0]*dim_img[1]*pz[j];
						double dfdp=x[l]*y[k]*z[j]/216;
						val+=dataI[idx]*dfdp;
						sumdfdp+=dfdp;
						diff1[i]+=dx[l]*y[k]*z[j]/216*dataI[idx];
						diff2[i]+=x[l]*dy[k]*z[j]/216*dataI[idx];
						diff3[i]+=x[l]*y[k]*dz[j]/216*dataI[idx];
						
				
					}
				}
			}
			
			t=val-floor(val);
			t2=t*t;
			t3=t2*t;
			int dd=(int)(floor(val)-range[0]);
			//			
			double t_val[4]={-t3+3*t2-3*t+1, 3*t3-6*t2+4, -3*t3+3*t2+3*t+1,  t3};
			double dt_val[4]={-3*t2+6*t-3, 9*t2-12*t, -9*t2+6*t+3,  3*t2};
			double tmp;
			double dNMIdW=0;			
			for(int m=0;m<4;m++)
						{
								for (int nn=0;nn<4;nn++){
										tmp=1/2*pow(d,2)*log(1-pow(abs((idxR+nn-1)-(dd+m-1))/d,2))/(N*36)*tr_val[nn]*weight[i];
									

											
                                    //tmp=pow(abs((idxR+nn-1)-(dd+m-1)),p)/(N*36)*tr_val[nn];
									lval+=t_val[m]*tmp;
									dNMIdW+=dt_val[m]*tmp;
								}
						}
			diff1[i]=dNMIdW*diff1[i];
			diff2[i]=dNMIdW*diff2[i];
			diff3[i]=dNMIdW*diff3[i];
		}
        	{
				MyMutexType::scoped_lock lock(MyMutex2);
				vall[0]=vall[0]+lval;
		}
	}
};


	void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
		const mxArray *prhs[])
	{

		if(nrhs==0)
			mexPrintf("PNORM takes 8 arguments,pts,ref_data, Image, range, nobins, offset, scale, p-norm ");
		if(nrhs<6)
			mexErrMsgTxt("Number of arguments must be 6");
		//mexPrintf("Spline interpolation takes 4 arguments ");
		double* pts = static_cast<double*>(mxGetData(prhs[0]));
		double* dataR = static_cast<double*>(mxGetData(prhs[1]));
		double* dataI = static_cast<double*>(mxGetData(prhs[2]));
		double* range = static_cast<double*>(mxGetData(prhs[3]));
		double* no_bins = static_cast<double*>(mxGetData(prhs[4]));
		double* offset = static_cast<double*>(mxGetData(prhs[5]));
		double* scale=new double[2];
		scale[0]=1;
		scale[1]=1;

		scale = static_cast<double*>(mxGetData(prhs[6]));
		double* p = static_cast<double*>(mxGetData(prhs[7]));

		double* weight = static_cast<double*>(mxGetData(prhs[8]));
		
		int ndim =(int)mxGetNumberOfDimensions(prhs[2]);
		int* dim_pts =(int*)mxGetDimensions(prhs[0]);
		int* dim_img=(int*)mxGetDimensions(prhs[2]);
		int* dim_offset=(int*)mxGetDimensions(prhs[5]);
		int* dim_scale=(int*)mxGetDimensions(prhs[6]);
		int N=dim_pts[0];
		////Allocate Tc
		mwSize dims[2];
		mwSize dims2[1];

		dims2[0] = 1; 
		

		
		dims[0] = N; dims[1] = 1;
		
		double* diff1 ;
		double* diff2 ;
		double* diff3 ;
		bool do_deriv=false;
		if(nlhs>3)do_deriv=true;
		plhs[0] = mxCreateNumericArray(1,dims2,mxDOUBLE_CLASS, mxREAL);
		double* val = static_cast<double*>(mxGetData(plhs[0]));
		plhs[1] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff1 = static_cast<double*>(mxGetData(plhs[1]));
		plhs[2] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff2 = static_cast<double*>(mxGetData(plhs[2]));
		
		plhs[3] = mxCreateNumericArray(2,dims,mxDOUBLE_CLASS, mxREAL);
		diff3 = static_cast<double*>(mxGetData(plhs[3]));
		//Initializing bins to 0
	
		//const int NN = N;
		/*task_scheduler_init init(4);
		parallel_for(blocked_range<int>(0,N,N/4),interp(pts,data,offset,scale,ndim,dim_pts,dim_img,dim_offset,dim_scale,N,diff1 ,diff2 ,dfdx,do_deriv,val,dfdp,idx,dims),simple_partitioner());
		*/
		//create histograms
		//task_scheduler_init init(8);

		parallel_for(blocked_range<int>(0,N),interp(pts,dataI,dataR,offset,scale,ndim,dim_pts,dim_img,dim_offset,dim_scale,N,dims,range,no_bins,diff1 ,diff2,diff3,val,p[0],weight,p[1]),auto_partitioner());
		return;




	};