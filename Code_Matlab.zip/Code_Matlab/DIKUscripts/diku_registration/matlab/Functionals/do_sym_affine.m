function [pts invpts]=cf_rigidNMI_3dpw(p, points,center)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);




%Rotation matrices
R=[p(1) p(2) p(3);p(4) p(5) p(6); p(7) p(8) p(9)];
[invR, dinvR]=inv3x3(R);
dR1=[1 0 0; 0 0 0 ;0 0 0];
dR2=[0 1 0; 0 0 0 ;0 0 0];
dR3=[0 0 1; 0 0 0 ;0 0 0];
dR4=[0 0 0; 1 0 0 ;0 0 0];
dR5=[0 0 0; 0 1 0 ;0 0 0];
dR6=[0 0 0; 0 0 1 ;0 0 0];
dR7=[0 0 0; 0 0 0 ;1 0 0];
dR8=[0 0 0; 0 0 0 ;0 1 0];
dR9=[0 0 0; 0 0 0 ;0 0 1];


t1=zeros(3,1);t1(1)=p(10);t1(2)=p(11);t1(3)=p(12);

%derived rotation matrices
size_points=size(points,1);
pts=(points-repmat(center,size_points,1))*R+repmat(t1',[size_points 1])+repmat(center,size_points,1);

invpts=(points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*invR+repmat(center,size_points,1);

%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


