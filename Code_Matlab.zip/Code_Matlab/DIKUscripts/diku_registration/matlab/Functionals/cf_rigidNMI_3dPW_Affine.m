function [f df pts]=cf_rigidNMI_3dPW_Affine(p, I, points,center, Rtrival,scale,det)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);


t11=p(10);t12=p(11);t13=p(12);

%Rotation matrices
S=[p(1) p(4) p(7);p(2) p(5) p(8);p(3) p(6) p(9)];

t1=zeros(3,1);t1(1)=t11;t1(2)=t12;t1(3)=t13;

%derived rotation matrices

size_points=size(points,1);
pts=(points-repmat(center,size_points,1))*S+repmat(t1',[size_points 1])+repmat(center,size_points,1);

%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


tic
[res d(:,1) d(:,2) d(:,3)]=NMI(pts,Rtrival+2,I+2,[0 0 0],scale,det);

toc
%d=-d;
d=d./repmat(scale,size(d,1),1);

df(10)=sum(d(:,1));
df(11)=sum(d(:,2));
df(12)=sum(d(:,3));
dS=zeros(3);
for i=1:9
    dS(i)=1;
df(i)=sum(sum((points-repmat(center,size_points,1))*dS.*d,2));
    dS(i)=0;
end
% df(8)=sum(sum((points-repmat(center,size_points,1))*dS2*R.*d,2));
% df(9)=sum(sum((points-repmat(center,size_points,1))*dS3*R.*d,2));
% df(1)=sum(sum((points-repmat(center,size_points,1))*S*dRx.*d,2));
% df(2)=sum(sum((points-repmat(center,size_points,1))*S*dRy.*d,2));
% df(3)=sum(sum((points-repmat(center,size_points,1))*S*dRz.*d,2));
% T=S*R;
disp([res p']);
f=6-res;