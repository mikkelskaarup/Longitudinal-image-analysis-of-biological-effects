function [f df T]=cf_rigidNMI_3dpw(p, I, points,center, Rtrival,scale,det)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);


rotx=p(1); roty=p(2);rotz=p(3);
t11=p(4);t12=p(5);t13=p(6);
s1=p(7);s2=p(8);s3=p(9);

%Rotation matrices
Rx=[1 0 0; 0 cos(rotx) -sin(rotx); 0 sin(rotx) cos(rotx)];
Ry=[cos(roty) 0 sin(roty); 0 1 0; -sin(roty) 0 cos(roty)];
Rz=[cos(rotz) -sin(rotz) 0; sin(rotz) cos(rotz) 0; 0 0 1];
R=Rz*Ry*Rx;
S=[(1+s1) 0 0; 0 (1+s2) 0;0 0 (1+s3)];

t1=zeros(3,1);t1(1)=t11;t1(2)=t12;t1(3)=t13;

%derived rotation matrices
dRx=Rz*Ry*[0 0 0; 0 -sin(rotx) -cos(rotx); 0 cos(rotx) -sin(rotx)];
dRy=Rz*[-sin(roty) 0 cos(roty); 0 0 0; -cos(roty) 0 -sin(roty)]*Rx;
dRz=[-sin(rotz) -cos(rotz) 0; cos(rotz) -sin(rotz) 0; 0 0 0]*Ry*Rx;
size_points=size(points,1);
pts=(points-repmat(center,size_points,1))*S*R+repmat(t1',[size_points 1])+repmat(center,size_points,1);
dS1=[(1) 0 0; 0 1 0;0 0 1];
dS2=[0 0 0; 0 1 0;0 0 0];
dS3=[0 0 0; 0 0 0;0 0 (1)];
%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


tic
[res d(:,1) d(:,2) d(:,3)]=NMI(pts,Rtrival+2,I+2,[0 0 0],scale,det);

toc
%d=-d;
d=d./repmat(scale,size(d,1),1);

df(4)=sum(d(:,1));
df(5)=sum(d(:,2));
df(6)=sum(d(:,3));
df(7)=sum(sum((points-repmat(center,size_points,1))*dS1*R.*d,2));
df(8)=sum(sum((points-repmat(center,size_points,1))*dS2*R.*d,2));
df(9)=sum(sum((points-repmat(center,size_points,1))*dS3*R.*d,2));
df(1)=sum(sum((points-repmat(center,size_points,1))*S*dRx.*d,2));
df(2)=sum(sum((points-repmat(center,size_points,1))*S*dRy.*d,2));
df(3)=sum(sum((points-repmat(center,size_points,1))*S*dRz.*d,2));
T=(S*R)';
%disp([res p']);
f=6-res;