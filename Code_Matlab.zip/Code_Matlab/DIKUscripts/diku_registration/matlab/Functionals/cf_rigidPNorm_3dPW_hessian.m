function [f df]=cf_rigidPNorm_3dPW(p, I, points,center, Rtrival,scale,det,norm)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);


rotx=p(1); roty=p(2);rotz=p(3);
t11=p(4);t12=p(5);t13=p(6);
s1=p(7);%s2=p(8);s3=p(9);

%Rotation matrices
Rx=[1 0 0; 0 cos(rotx) -sin(rotx); 0 sin(rotx) cos(rotx)];
Ry=[cos(roty) 0 sin(roty); 0 1 0; -sin(roty) 0 cos(roty)];
Rz=[cos(rotz) -sin(rotz) 0; sin(rotz) cos(rotz) 0; 0 0 1];
R=Rz*Ry*Rx;
S=[(1+s1)];

t1=zeros(3,1);t1(1)=t11;t1(2)=t12;t1(3)=t13;

%derived rotation matrices
dRx=Rz*Ry*[0 0 0; 0 -sin(rotx) -cos(rotx); 0 cos(rotx) -sin(rotx)];
dRy=Rz*[-sin(roty) 0 cos(roty); 0 0 0; -cos(roty) 0 -sin(roty)]*Rx;
dRz=[-sin(rotz) -cos(rotz) 0; cos(rotz) -sin(rotz) 0; 0 0 0]*Ry*Rx;
size_points=size(points,1);
pts=(points-repmat(center,size_points,1))*S*R+repmat(t1',[size_points 1])+repmat(center,size_points,1);


%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


tic
%[res d(:,1) d(:,2) d(:,3)]=NMI(pts,Rtrival+2,I+2,[0 0 0],scale,det);
[res1 d1(:,1) d1(:,2) d1(:,3)]=PNorm(pts,Rtrival(:,1)+2,I(:,:,:,1)+2,[0 0 0],scale,det,norm);
[res2 d2(:,1) d2(:,2) d2(:,3)]=PNorm(pts,Rtrival(:,2)+2,I(:,:,:,2)+2,[0 0 0],scale,det,norm);
[res3 d3(:,1) d3(:,2) d3(:,3)]=PNorm(pts,Rtrival(:,3)+2,I(:,:,:,3)+2,[0 0 0],scale,det,norm);
toc
%d=-d;
d=d1+d2+d3;
d=d./repmat(scale,size(d,1),1);
res=res1+res2+res3;
df(4)=sum(d(:,1));
df(5)=sum(d(:,2));
df(6)=sum(d(:,3));
df(7)=sum(sum((points-repmat(center,size_points,1))*R.*d,2))*0;
df(1)=sum(sum((points-repmat(center,size_points,1))*S*dRx.*d,2));
df(2)=sum(sum((points-repmat(center,size_points,1))*S*dRy.*d,2));
df(3)=sum(sum((points-repmat(center,size_points,1))*S*dRz.*d,2));

disp([res p']);
f=res;