function [f df]=cf_NMI_SVF_AFF(p,dim_warp, mu,pts,img,mask,Rtrival,warp_offset,im_offset,warp_scale,im_scale,pn,aff,center,aff_global,center_global,comp_vec)

%function [f df]=cost_fun_msh3d_mex(p, lambda, mu, Ad, grid,I, A, value,simp, offset, scale,p_space)
p=reshape(p,dim_warp);
dI=pts*0;fval=0;
[pts3_]=SS_Trap_1st(double(pts),double(p),double(warp_offset),double(warp_scale),double(40),double(5));
for k=1:size(comp_vec,1)
%getting indices
j=comp_vec(k,2);
i=comp_vec(k,1);
%[f1 df1]=cf_NMI_SVF_AFF2(p,dim_warp, mu,pointsI,HTJ(j).bimg+2,Itrival(:,i)+2,warp_offset,(offsetJ(:,j)'),warp_scale,scaleJ(j,:),pn,J_rig,J_center(j,:),aff_global,center_global);
%for image I(i)
%get image specific affine transformation
J_aff=aff(:,j); 
[pts3 invR_Global]=do_affine_inv(aff_global(:),pts3_,center_global);
[pts3 invR_Local]=do_affine_inv(J_aff(:),pts3,center(j,:));

[f d(:,1) d(:,2) d(:,3)]=NMI(pts3(mask==1,:),Rtrival(mask==1,i)+2,img(j).bimg+2,(im_offset(:,j)'),im_scale(j,:),double(ones(size(Rtrival(mask==1,i),1),1)));
if(k==1) disp([2-f]); end;
dI(mask==1,:)=dI(mask==1,:)+d*invR_Local'*invR_Global';
fval=fval+f;
end
[pts df]=SS_Trap_2nd(double(pts),double(p),double(warp_offset),double(warp_scale),double(40),double(5),dI);
r=(0.5*mu)*sum(p(:).^2);
df=df+mu*p(:);
disp([2*size(comp_vec,1)-fval r])
 f=(2*size(comp_vec,1)-fval)+r;

