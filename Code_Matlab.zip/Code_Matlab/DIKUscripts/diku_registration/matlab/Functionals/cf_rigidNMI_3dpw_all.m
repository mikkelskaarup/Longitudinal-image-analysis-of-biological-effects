function [f df]=cf_rigidNMI_3dpw_scale(p, I, points,center, Rtrival,scale,det)
for i=1:size(I,5)
  [f(i) df(:,i)]=cf_rigidNMI_3dpw(p, squeeze(I(:,:,:,:,i)), points,center,squeeze(Rtrival(:,:,i)),scale,det);
end