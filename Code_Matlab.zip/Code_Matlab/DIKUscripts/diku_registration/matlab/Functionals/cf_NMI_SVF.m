function [f df]=cf_NMI_SVF(p,dim_warp, mu,pts,img,Rtrival,warp_offset,im_offset,warp_scale,im_scale,pn)

%function [f df]=cost_fun_msh3d_mex(p, lambda, mu, Ad, grid,I, A, value,simp, offset, scale,p_space)
p=reshape(p,dim_warp);
[pts3]=SS_Trap_1st(double(pts),double(p),double(warp_offset),double(warp_scale),double(40),double(5));
[f d(:,1) d(:,2) d(:,3)]=NMI(pts3,Rtrival+2,img+2,[0 0 0],im_scale,double(ones(size(Rtrival))));
[pts df]=SS_Trap_2nd(double(pts),double(p),double(warp_offset),double(warp_scale),double(40),double(5),d);
r=(0.5*mu)*sum(p(:).^2);
df=df+mu*p(:);
 f=(2-f)+r;

