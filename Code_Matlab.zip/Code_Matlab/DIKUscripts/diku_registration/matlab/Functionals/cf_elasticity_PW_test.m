function [f df]=cf_elasticity_PW_test(p,lambda, mu,dfdx,pts, val,simp,offset,p_space)
p=reshape(p,numel(p)/3,3);
pt=reshape(p,size(val));
[phi , ~, ~, d1, d2, d3]=SplineInterpolation_tbb(pts,pt,offset,p_space);
clear pt ;
phi=pts+phi;
[drdp r f]=EigenDerivN_tbb(p/p_space(1),double(simp),double(dfdx),lambda,mu);
if (f==Inf)
    disp('Inf')
    return
end

f=(r);
disp(r);
df=(drdp(:));

