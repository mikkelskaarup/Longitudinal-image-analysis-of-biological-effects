function [f df]=cf_rigidNMI_3dpw(p,dim_warp, mu,warp_offset,warp_scale, HTI,Imask, HTJ,Jmask,pointsI, pointsJ, Itrival,Jtrival,scaleI,scaleJ,detI,detJ,I_aff,J_aff,I_center,J_center,offsetI,offsetJ,comp_vec,aff_global, center_global)



df=zeros(numel(p),1);

pn = 1;


%Affine matrices
R=[aff_global(1) aff_global(2) aff_global(3);aff_global(4) aff_global(5) aff_global(6); aff_global(7) aff_global(8) aff_global(9)];
%inverse of of affine matrices 
[invR_g, dinvR]=inv3x3(R);

%translation
t1=zeros(3,1);t1(1)=aff_global(10);t1(2)=aff_global(11);t1(3)=aff_global(12);

%application of global affine inverses to HTJ

size_pointsJ=size(pointsJ,1);
invpts=(pointsJ-repmat(center_global,size_pointsJ,1)-repmat(t1',[size_pointsJ 1]))*invR_g+repmat(center_global,size_pointsJ,1);

%allocating space for results and image-functional (NMI) derivatives
df=zeros(size(p(:)));
f=0;f1=0;
%looping over combinations of images

%for image I(i)
%get image specific affine transformation
J_rig=J_aff;    
%apply image specific affine transformation

%compute similarity corrected gradients for global and image specific affine transformation
[f1 df1]=cf_NMI_SVF_AFF2_FAST_wMask(p,dim_warp, mu,pointsI,HTJ,Imask,Itrival,warp_offset,offsetJ,warp_scale,scaleJ,pn,J_rig,J_center,aff_global,center_global,comp_vec);


%for image J(j)
%get image specific affine transformation
I_rig=I_aff;    
%apply image specific affine transformation
%[invpts_, invRI]=do_affine_inv(I_rig(:),invpts,I_center(i,:));  

%compute similarity corrected gradients for image specific affine transformation
[f2 df2]=cf_NMI_SVF_AFF_FAST_wMask(-p,dim_warp, mu,invpts,HTI,Jmask,Jtrival,warp_offset,offsetI,warp_scale,scaleI,pn,I_rig,I_center,comp_vec);

f=f+f1+f2;
df=df+df1+df2;

%

%sum similarity both ways
 
%compute symmetric derivatives for global affine



disp([f]);
