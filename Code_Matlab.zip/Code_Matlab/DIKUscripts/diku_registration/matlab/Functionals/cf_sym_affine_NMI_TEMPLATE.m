function [f df]=cf_rigidNMI_3dpw(p, I, J, points,center, Itrival,Jtrival,scaleI,scaleJ,det)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)
% tf=zeros(size(I,4));
% tdf=zeros(12,size(I,4));
parfor j=1:size(I,4) 
[f(j) ,df(:,j)]=cf_sym_affine_NMI_base(p((j-1)*12+1:j*12), I, J(j).img , points,center, Itrival,Jtrival(:,j),[1 1 1],double(J(j).hdr.dime.pixdim(2:4)),det)
end
f=sum(f);
df=df(:);