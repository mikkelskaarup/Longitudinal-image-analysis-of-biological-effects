function [f df]=cf_rigidNMI_3dpw(p, I, J, points,center, Itrival,Jtrival,scaleI,scaleJ,det, offsetI)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);




%Rotation matrices
R=[p(1) p(2) p(3);p(4) p(5) p(6); p(7) p(8) p(9)];
[invR, dinvR]=inv3x3(R);
dR1=[1 0 0; 0 0 0 ;0 0 0];
dR2=[0 1 0; 0 0 0 ;0 0 0];
dR3=[0 0 1; 0 0 0 ;0 0 0];
dR4=[0 0 0; 1 0 0 ;0 0 0];
dR5=[0 0 0; 0 1 0 ;0 0 0];
dR6=[0 0 0; 0 0 1 ;0 0 0];
dR7=[0 0 0; 0 0 0 ;1 0 0];
dR8=[0 0 0; 0 0 0 ;0 1 0];
dR9=[0 0 0; 0 0 0 ;0 0 1];


t1=zeros(3,1);t1(1)=p(10);t1(2)=p(11);t1(3)=p(12);

%derived rotation matrices
size_points=size(points,1);
pts=(points-repmat(center,size_points,1))*R+repmat(t1',[size_points 1])+repmat(center,size_points,1);

invpts=(points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*invR+repmat(center,size_points,1);

%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);
%det=ones(size(pts,1),1);


tic
[res d(:,1) d(:,2) d(:,3)]=NMI(pts,Jtrival+2,I+2,offsetI,scaleI,det);
[invres invd(:,1) invd(:,2) invd(:,3)]=NMI(invpts,Itrival+2,J+2,[0 0 0],scaleJ,det);
toc
%d=-d;

 
id=invd*invR;
 

df(10)=sum(d(:,1))-sum(id(:,1));
df(11)=sum(d(:,2))-sum(id(:,2));
df(12)=sum(d(:,3))-sum(id(:,3));
df(1)=sum(sum((points-repmat(center,size_points,1))*dR1.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(1,:,:)).*invd,2));
df(2)=sum(sum((points-repmat(center,size_points,1))*dR2.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(4,:,:)).*invd,2));
df(3)=sum(sum((points-repmat(center,size_points,1))*dR3.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(7,:,:)).*invd,2));

df(4)=sum(sum((points-repmat(center,size_points,1))*dR4.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(2,:,:)).*invd,2));
df(5)=sum(sum((points-repmat(center,size_points,1))*dR5.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(5,:,:)).*invd,2));
df(6)=sum(sum((points-repmat(center,size_points,1))*dR6.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(8,:,:)).*invd,2));

df(7)=sum(sum((points-repmat(center,size_points,1))*dR7.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(3,:,:)).*invd,2));
df(8)=sum(sum((points-repmat(center,size_points,1))*dR8.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(6,:,:)).*invd,2));
df(9)=sum(sum((points-repmat(center,size_points,1))*dR9.*d,2)+sum((points-repmat(center,size_points,1)-repmat(t1',[size_points 1]))*squeeze(dinvR(9,:,:)).*invd,2));



%disp([res invres p']);
f=4-(res+invres);