function [f df]=cf_pnorm_elasticity_PW(p,lambda, mu,dfdx,dfdp,pts,img, val,simp,Rtrival,offset,p_space,pn,weight)
N=numel(p)/3;
p=reshape(p,numel(p)/3,3);
df=zeros(numel(p),1);
pt=reshape(p,size(val));
[phi , ~, ~, d1, d2, d3]=SplineInterpolation_tbb(pts,pt,offset,p_space);
clear pt ;
phi=pts+phi;
[drdp r f]=EigenDerivN_tbb(p/p_space(1),double(simp),double(dfdx),lambda,mu);
if (f==Inf)
    disp('Inf')
    return
end
[f d(:,1) d(:,2) d(:,3)]=NMI(phi,Rtrival+2,img+2,[0 0 0],[1 1 1],weight);
f=6-f;
%[f d(:,1) d(:,2) d(:,3)]=PNorm(phi,Rtrival+2,img+2,[0 0 0],[1 1 1],weight,pn);
N
     dDdp=dDdPFunc(double(d),double(dfdp),double(simp'-1),double(N));
f=(f+r);
disp([f r]);
df=(drdp(:)+dDdp(:));

