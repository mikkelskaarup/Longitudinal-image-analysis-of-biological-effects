function [ f df ] = cf_SYM_NMI_SVF(p,dim_warp, mu,pts,img1,img2,trival1,trival2,warp_offset,im_offset1,im_offset2,warp_scale,im_scale1,im_scale2,pn )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
[f1 df1]=cf_NMI_SVF(p,dim_warp, mu,pts,img1,trival1,warp_offset,im_offset1,warp_scale,im_scale1,pn);
[f2 df2]=cf_NMI_SVF(-p,dim_warp, mu,pts,img2,trival2,warp_offset,im_offset2,warp_scale,im_scale2,pn);

df=df1-df2;
f=f1+f2;
end

