function [ f, df ] = cf_fitBspline(p,pts,img,offset,scale )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
p=reshape(p,size(img));

[f,df]=SplineInterpolation_fit(pts,p,offset,img(:));
% df2=zeros(size(val));
%f=0.5*sum((val-img(:)).^2);
%df=dfdp_mul(img(:),val,dfdp,idx);
% idx=idx+1;
%  for i=1:numel(val)
% df2(idx(:,i))=df2(idx(:,i))+(val(idx(:,i))-img(idx(:,i))).*dfdp(:,i);
%  end
df=df';
% disp(f)
end

