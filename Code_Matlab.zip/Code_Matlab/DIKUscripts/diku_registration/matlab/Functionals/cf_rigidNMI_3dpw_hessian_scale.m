function [f df]=cf_rigidNMI_3dpw_hessian_scale(p, I, points,center, Rtrival,scale,det)
weight=ones(size(I,5),1);
for i=1:size(I,5)
  [f_(i) df_(:,i)]=cf_rigidNMI_3dPW_hessian(p, squeeze(I(:,:,:,:,i)), points,center,squeeze(Rtrival(:,:,i)),scale,det);
end
j=size(I,5);
for i=1:size(I,5)
f_(i)=f_(i)*2^(-j-1);
df_(:,i)=df_(:,i)*2^(-j-1);
j=j-1;
end
f=sum(f_);
df=sum(df_,2)