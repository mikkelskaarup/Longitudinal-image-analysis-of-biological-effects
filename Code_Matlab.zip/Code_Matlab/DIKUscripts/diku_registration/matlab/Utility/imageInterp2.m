function [im,pts]=imageinterp(p, I, points,center,scale)
%function [f df]=cf_nmi_elasticity3d(p,lambda, mu,Ad,center,img, A,simp,Rtrival,offset, scale,p_space)


df=zeros(numel(p),1);

S1=1
rotx=p(1); roty=p(2);rotz=p(3);
t11=p(4);t12=p(5);t13=p(6);
if size(p,1)>6
    S1=1+p(7);
end
if size(p,1)>7
    S2=1+p(8);
    S3=1+p(9);
    S1=[S1 0 0 ; 0 S2 0; 0 0 S3];
end
%Rotation matrices
Rx=[1 0 0; 0 cos(rotx) -sin(rotx); 0 sin(rotx) cos(rotx)];
Ry=[cos(roty) 0 sin(roty); 0 1 0; -sin(roty) 0 cos(roty)];
Rz=[cos(rotz) -sin(rotz) 0; sin(rotz) cos(rotz) 0; 0 0 1];
R=Rz*Ry*Rx;


t1=zeros(3,1);t1(1)=t11;t1(2)=t12;t1(3)=t13;

%derived rotation matrices
size_points=size(points,1);
pts=(points-repmat(center,size_points,1))*S1*R+repmat(t1',[size_points 1])+repmat(center,size_points,1);

[im]=SplineInterpolation_lin(pts,I,[0 0 0],scale);

%[Iphi,grad{1},grad{2}]=interp2d_diff(phi,I,1);

