function [f df]=cf_levelset(Iphi,I,lambda1,lambda2,lambda3,sup,pnorm, pnorm2,mu1,mu2)
%Iphi is the levelset
%I is the Image
%lambda1 is the penalty on the length of the 0th levelset
%lambda2 is the penalty on the length of the negative levelsets
%lambda3 is the cut-off from the meanvalues where the derivative is set to zero (and the functionvale becomes constant)
%sup is a factor for division of the levelset. The slope determines the
%'width of the narrowband' and it is approximately 2*sup
%pnorm is norm of the cost function.....note: should always be convex i.e. pnorm>1.....
%mu1 and mu2 are the mean values of the respective areas.....




%  no1=find(Iphi>0);
%  no2=find(Iphi<=0);
%  mu1=mean(I(no1))
%  mu2=mean(I(no2))
%   mu1=median(I(no1))
%  mu2=median(I(no2))
% tic
 [res dfd]=PNorm_Levelset_cut3(Iphi(:),I(:),[pnorm pnorm2 lambda1 lambda2 lambda3 lambda3],[mu1 mu2]);
% toc
df=dfd;
f=res;

