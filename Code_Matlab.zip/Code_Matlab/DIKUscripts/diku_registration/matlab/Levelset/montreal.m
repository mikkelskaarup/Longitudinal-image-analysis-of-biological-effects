
for i=5:5
    try
    pw=100;
   gk=15;
%[fname path]=uigetfile('*.img');
%try
if (i<10)
    str=['0' num2str(i)];
else
    str=num2str(i);
end
    
cd(['/media/data/data/blind/new data/montreal_data_anon/patient_' str '/mri/orig']);
d1=dir(['*0' int2str(floor(i/100)) int2str(floor(mod(i,100)/10)) int2str(mod(i,10)) '*' '1'])
d2=dir(['*0' int2str(floor(i/100)) int2str(floor(mod(i,100)/10)) int2str(mod(i,10)) '*' '2'])

[data]=MRIread('001.mgz',0);
%img2=flipdim(awn.img,2);
clear img;
for j=1:size(data.vol,3)
img(:,:,j)=rot90(squeeze(data.vol(:,:,j)),3);
end
s=size(img);
[x y z]=ndgrid(1:s(1),1:s(2),1:s(3));
x=x-s(1)/2;
y=y-s(2)/2;
z=z-s(3)/2;
dist=sqrt(x.^2+y.^2+z.^2)-40;
imagesc(dist(:,:,40))
% A=ones(80,80,80);
% % find(dist<20);
% % no=find(dist<20);
% A(30:50,30:50,30:50)=-1;
% imagesc(A(:,:,40))
% A=A*10+30+rand(size(A))*0;
%__________ no1=find(Iphi>0);
for i=1:200
    no1=find(dist>0);
 no2=find(dist<=0);
 mu1=median(img(no1))
 mu2=median(img(no2))
   no=find(abs(dist)<=2);
p=minFunc(@cf_levelset_PNorm_cut,dist(no),options,img(no),10,10,40,1,1.2,mu1,mu2);
dist(no)=p;
dist2=dist;

no=find(dist2<0);
bw=zeros(size(dist2));
bw(no)=1;
tic
bw1=bwdist(bw,'euclidean');
bw1(no)=-bw1(no)+1;
bw2=bwdist(-bw+1,'euclidean');
dist=double(bw1-bw2);
toc
end

disp(f)


cd('/media/data/data/blind/results_mt/')
save(['seg_' num2str(i) '.mat' ],'dist','dist2','img')
    catch
    disp('err........')
end
end

% catch
% end

