function [f df]=cf_levelset(Iphi,I,lambda1,lambda2,sup,pnorm)
%Input
%Iphi is the levelset as a vector (use Iphi(:))
%I is the correspnding image as a vector (I(:)) I and Iphii must be same
%size nd of double value
%Lambda1 is the parameter of length of the 0th levelset
%Lambda2 is the parameter of area of the inside of the levelset
%sup is the narrowband width 
%pnorm is the order of the central moment
%output the functionvale f and the partial derivative df

 no1=find(Iphi>0);
 no2=find(Iphi<=0);
 mu1=mean(I(no1))
 mu2=mean(I(no2))
%   mu1=median(I(no1))
%  mu2=median(I(no2))
 tic
 [res dfd]=PNorm_Levelset(Iphi(:)/sup,I(:),[pnorm lambda1 lambda2],[mu1 mu2]);
 toc
df=dfd/sup;
f=res;

