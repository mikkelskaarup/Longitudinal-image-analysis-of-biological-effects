%dpath='H:\Windows\GBM\Recurrence\NiftiFiles\Patient0t\';
dpath = '/Volumes/MLJ HD/GBM/Recurrence/NiftiFiles/Patient0t/';

no_cores=4;

% try
% parpool(no_cores)
% catch
% end

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;
options4=options;
options4.MaxIter=100;

% CTfileName = dir([dpath '*CT*']);
% CTfileName = CTfileName.name;

MRIfilesT1 = dir([dpath '*t1*']);
noMRIfilesT1 = size(MRIfilesT1,1);

warning off all
% parfor i=1:noMRIfilesT1
i = 1;
% read images
% CT=load_untouch_nii(fullfile(dpath,CTfileName));
% img1=double(CT.img);

MRI1=load_untouch_nii(fullfile(dpath,MRIfilesT1(i+3).name));
MRI2=load_untouch_nii(fullfile(dpath,MRIfilesT1(i+4).name));
img1=double(MRI1.img);
img2=double(MRI2.img);

%get image resolution
dimt1=MRI1.hdr.dime.pixdim(2:4);
dimt2=MRI2.hdr.dime.pixdim(2:4);

% Image size [mm]
S1=round(size(img1).*dimt1);
S2=round(size(img2).*dimt2);


% rescale images to conform with 160 bins (good values are between 80 and 256)
img1=img1-min(img1(:));
img2=img2-min(img2(:));
img2=img2/max(img2(:))*160;
img1=img1/max(img1(:))*160;

% Load affine registration from REGISTER_RH_affine
p = load(['MR' num2str(i+3) '_to_MR' num2str(i+4) '_RH_patient0t_affine']);
p3 = p.p;

%define center of rotation (mm from corner of img1)
center=[floor(S1(1)/2) floor(S1(2)/2) floor(S1(3)/2)]

%resample img1 (1mm resolution) to prepare non-rigid registration
resolution=1;
[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
ptsresample=[X1(:) X2(:) X3(:)];
[pts3]=do_sym_affine(p3(:),ptsresample,center);
Rtrival=(SplineInterpolation_lin(pts3,img1,[0 0 0],dimt1));
img11=reshape(Rtrival,size(X1));

%setting up non-rigid registration
resolution=2;
[X1, X2, X3]=ndgrid(0:resolution:S1(1),0:resolution:S1(2),0:resolution:S1(3));
pts=[X1(:) X2(:) X3(:)];
%Itrival=(SplineInterpolation_tbb(pts,img11,[0 0 0],[1 1 1]));
Itrival=(SplineInterpolation_tbb(pts,img11,[0 0 0],dimt1));
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));

% extracting positions with information
no=find(Itrival+Jtrival>0);

% initializ to 0
pp4=zeros([30 30 30 3]);
ww=[40 40 40];

%no. of points in deformation grid
grid_size=45;

% set decreasing grid size of deformation field
pyramidLevels = [40 20 10 5];

for pl=1:length(pyramidLevels)
    if (pl==1 || pl==2)
        curr_options = options2;
    elseif pl == 3
        curr_options = options3;
    elseif pl == 4
        curr_options = options4;
    else
        error('Bummer!!')
    end
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    %resampling deformation field to new resolution
    %resampling deformation field to new resolution
    [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
    tpts=[XX1(:) XX2(:) XX3(:)]*pyramidLevels(pl);
    n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
    %setting scale and offset of img11
    scale=[1 1 1];
    offset=[1 1 1]*0;
    
    %setting size of deformation grid and parametrization
    val=ones([grid_size grid_size grid_size 3]);
    ww=[pyramidLevels(pl) pyramidLevels(pl) pyramidLevels(pl)];
    p4=reshape(n,size(val));
    offset2=-ww;

    % Estimate warp-field by nMutualInformation
    pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),curr_options,size(p4),(0.0005),pts(no,:),img11,img2,Jtrival(no),Itrival(no),offset2,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);
    pp4=reshape(pp4,size(p4));

end
saveparams(['MR' num2str(i+1) '_to_MR' num2str(i) '_RH_patient0t_nonLinearWarp'],pp4);
%%

[X11, X2, X3]=ndgrid(0:dimt1(1):S1(1),0:dimt1(2):S1(2),0:dimt1(3):S1(3));
org_pts=[X11(:) X2(:) X3(:)];
[X1, X2, X3]=ndgrid(0:dimt2(1):S2(1),0:dimt2(2):S2(2),0:dimt2(3):S2(3));
org_pts2=[X1(:) X2(:) X3(:)];

n1=NNInterpolation_lin(org_pts+repmat(0.5*dimt1,numel(X11),1),double(MRI1.img(:,:,:)),[0 0 0],dimt1);
n11=NNInterpolation_lin(org_pts2+repmat(0.5*dimt2,numel(X1),1),double(MRI2.img(:,:,:)),[0 0 0],dimt2);


%img2 matched to img1 by affine
[~, ipts3]=do_sym_affine(p3(:),org_pts,center);
tic;[inr_pts]=SS_Trap_1st(ipts3,-pp4,offset2,ww,double(40),double(5));toc
n3=NNInterpolation_lin(inr_pts+repmat(0.5*dimt2,numel(X11),1),double(MRI2.img(:,:,:)),[0 0 0],dimt2);

%img1 (from the run script) matched to img2 by first inv affine and then
%nr warp
tic;[nr_pts]=SS_Trap_1st(org_pts2,pp4,offset2,ww,double(40),double(5));toc
[pts3, ~]=do_sym_affine(p3(:),nr_pts,center);
n33=NNInterpolation_lin(pts3+repmat(0.5*dimt1,numel(X1),1),double(MRI1.img(:,:,:)),[0 0 0],dimt1);


img11 = reshape(n1,size(X11));
img21 = reshape(n11,size(X1));
img12 = reshape(n3,size(X11));
img22 = reshape(n33,size(X1));

%end

%% Visualize
MR2slice = 25;
figure(1),imagesc(img11(:,:,MR2slice)), axis image
figure(2),imagesc(img12(:,:,MR2slice)),axis image
figure(3),imagesc(imfuse(img11(:,:,MR2slice),img12(:,:,MR2slice))); axis image % requires MATLAB ImageProcessing Toolbox

%%
MR1slice = 25;
figure(4),imagesc(img21(:,:,MR1slice)), axis image
figure(5),imagesc(img22(:,:,MR1slice)), axis image
figure(6),imagesc(imfuse(img21(:,:,MR1slice),img22(:,:,MR1slice))); axis image % requires MATLAB ImageProcessing Toolbox
