
IBSR_labels 
a1=zeros(45,1);
a2=zeros(45,1);
a3=zeros(45,1);
a4=zeros(45,1);
b1=zeros(45,1);
b2=zeros(45,1);
b3=zeros(45,1);
b4=zeros(45,1);
cnt=1;
cnt=1;
for ii=[1:9]
for jj=ii+1:10
idx(cnt)=ii;
jdx(cnt)=jj;
cnt=cnt+1;
end
end

% options.LS_init=2;
% options.LS=3;
warning off all
for i=1:45
% b1(i)=mean(MO(no));
% a1(i)=mean(TO(no));
load(['c' num2str(idx(i)) 'MGH_160_dr_iter_04_c' num2str(jdx(i))  ]);
p=reshape(p,106,4);
TO=p(:,1);
MO=p(:,3);
a2(i)=mean(TO)
b2(i)=mean(MO);
TO=p(:,2);
MO=p(:,4);
a3(i)=mean(TO)
b3(i)=mean(MO);
% [TO,MO]=evalutationKlien(n33,n11,id);
% TO4(i,:)=TO;
% MO4(i,:)=MO;
% no=find(~isnan(TO));
% a4(i)=mean(TO(no));
% b4(i)=mean(MO(no));
end