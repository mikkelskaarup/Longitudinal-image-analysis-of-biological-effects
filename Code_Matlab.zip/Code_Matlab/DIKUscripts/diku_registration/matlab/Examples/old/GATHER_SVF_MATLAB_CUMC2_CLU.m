
load m_Labels_CUMC12.mat 

id=Labels(3:end);
a1=zeros(55,1);
a2=zeros(55,1);
a3=zeros(55,1);
a4=zeros(55,1);
b1=zeros(55,1);
b2=zeros(55,1);
b3=zeros(55,1);
b4=zeros(55,1);
cnt=1;
for ii=[1]
    
for jj=ii+2:12
idx(cnt)=ii;
jdx(cnt)=jj;
cnt=cnt+1;
end
end
for ii=[3:12]
for jj=ii+1:12
idx(cnt)=ii;
jdx(cnt)=jj;
cnt=cnt+1;
end
end

% options.LS_init=2;
% options.LS=3;
warning off all
for i=1:55
% b1(i)=mean(MO(no));
% a1(i)=mean(TO(no));
load(['m' num2str(idx(i)) 'CUMC_160_dr_m' num2str(jdx(i))  ]);
p=reshape(p,130,4);
no=find(~isnan(p(:,1)+p(:,2)))
TO=p(:,1);
MO=p(:,3);
a2(i)=mean(TO(no))
b2(i)=mean(MO(no));
TO=p(:,2);
MO=p(:,4);
a3(i)=mean(TO(no))
b3(i)=mean(MO(no));
% [TO,MO]=evalutationKlien(n33,n11,id);
% TO4(i,:)=TO;
% MO4(i,:)=MO;
% no=find(~isnan(TO));
% a4(i)=mean(TO(no));
% b4(i)=mean(MO(no));
end