
load m_Labels_CUMC12.mat 
a1=zeros(55,1);
a2=zeros(55,1);
a3=zeros(55,1);
a4=zeros(55,1);
b1=zeros(55,1);
b2=zeros(55,1);
b3=zeros(55,1);
b4=zeros(55,1);
cnt=1;
for ii=[1]
    
for jj=ii+2:12
idx(cnt)=ii;
jdx(cnt)=jj;
cnt=cnt+1;
end
end
for ii=[3:12]
for jj=ii+1:12
idx(cnt)=ii;
jdx(cnt)=jj;
cnt=cnt+1;
end
end
options.Method='lbfgs';
options.display = 'iter';
options.MaxIter=50;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';
%options.Damped=1;
% options.LS_init=2;
% options.LS=3;
warning off all
for i=1:45
mri=load_nii(['/home/cjr806/CUMC12/CUMC12/Atlases/m' num2str(jdx(i)) '.img']);
mri2=load_nii(['/home/cjr806/CUMC12/CUMC12/Atlases/m' num2str(idx(i)) '.img']);

ww=[5 5 5];
S=size(mri.img).*mri.hdr.dime.pixdim(2:4)-1;
dim=mri.hdr.dime.pixdim(2:4);
offset2=-ww;
load(['m' num2str(idx(i)) 'CUMC0_0005_dr_m' num2str(jdx(i)) '.mat' ]);
pp4=p;
[X1, X2, X3]=ndgrid(0:dim(1):S(1),0:dim(2):S(2),0:dim(3):S(3));
org_pts=[X1(:) X2(:) X3(:)];
cnt=1;
tic;[inr_pts]=SS_Trap_1st(org_pts,-pp4,offset2,ww,double(40),double(5));toc
tic;[nr_pts]=SS_Trap_1st(org_pts,pp4,offset2,ww,double(40),double(5));toc
%[invaf_pts af_pts]=do_sym_affine(p(:),nr_pts,center);
%af_pts=af_pts;
%p=reshape(a1(10:end),[a1(1) a1(1) a1(1) 3]);

%tic;[nr_pts]=SS_Trap_1st(af_pts,pp4,offset2,ww,double(40),double(5));toc
nr_pts=nr_pts;
mri=load_nii(['/home/cjr806/CUMC12/CUMC12/Atlases/m' num2str(jdx(i)) '.img']);
mri2=load_nii(['/home/cjr806/CUMC12/CUMC12/Atlases/m' num2str(idx(i)) '.img']);
n1=NNInterpolation_lin(org_pts+repmat(0.5*dim,numel(X1),1),double(mri.img),[0 0 0],dim);
n11=NNInterpolation_lin(org_pts+repmat(0.5*dim,numel(X1),1),double(mri2.img),[0 0 0],dim);
%n2=NNInterpolation_lin(nr_pts+1,double(mri2.img),[0 0 0],[1 1 1]);
n3=NNInterpolation_lin(nr_pts+repmat(0.5*dim,numel(X1),1),double(mri2.img),[0 0 0],dim);
n33=NNInterpolation_lin(inr_pts+repmat(0.5*dim,numel(X1),1),double(mri.img),[0 0 0],dim);


id=Labels(3:end);
% [TO,MO]=evalutationKlien(n2,n1,id(2:end));
% tto11(cnt,:)=TO;
% aa11(cnt)=mean(TO)

[TO,MO]=evalutationKlien(n3,n1,id(2:end));
a1(i)=mean(TO)
TO1(i,:)=TO;
MO1(i,:)=MO;
b1(i)=mean(MO);
[TO,MO]=evalutationKlien(n1,n3,id(2:end));
TO2(i,:)=TO;
MO2(i,:)=MO;
a2(i)=mean(TO);
b2(i)=mean(MO);
[TO,MO]=evalutationKlien(n11,n33,id(2:end));
TO3(i,:)=TO;
MO3(i,:)=MO;
a3(i)=mean(TO);
b3(i)=mean(MO);

[TO,MO]=evalutationKlien(n33,n11,id(2:end));
TO4(i,:)=TO;
MO4(i,:)=MO;

a4(i)=mean(TO)
b4(i)=mean(MO);
end