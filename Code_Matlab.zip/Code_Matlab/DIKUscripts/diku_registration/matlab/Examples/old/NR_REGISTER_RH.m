lpath='/Users/MLJ/Dropbox/Work/RH/Research/Matlab/toolboxes/DIKU_registration';
dpath='/Users/MLJ/Documents/MGH10';
no_cores=4;
addpath([lpath '/minFunc_2012/minFunc/']);
addpath([lpath '/minFunc_2012/minFunc/mex/']);
addpath([lpath '/minFunc_2012/minFunc/compiled/']);
%addpath([lpath '/NIFTI_20110921/']);
addpath([lpath '/Matlab/Functionals/']);
addpath([lpath '/Matlab/Examples/']);
addpath([lpath '/Matlab/Similarity/']);
addpath([lpath '/Matlab/Interpolations/']);
addpath([lpath '/Matlab/Levelset/']);
addpath([lpath '/C++/Leveset/']);
addpath([lpath '/C++/Interpolation/']);
% try
% parpool(no_cores)
% catch
% end
cnt=1;
for ii=1
for jj=ii+1:5
idx(cnt)=ii;
jdx(cnt)=jj;
cnt=cnt+1;
end
end

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';
options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;
options4=options;
options4.MaxIter=100;



warning off all
%parfor i=1:4
i = 1;
% read images
mri1=load_nii([dpath '/EHeads/g' num2str(idx(i)) '.nii']);
img1=double(mri1.img)*2;
S=size(img1)-1;
mri2=load_nii([dpath '/EHeads/g' num2str(jdx(i)) '.nii']);
img2=double(mri2.img)*2;

% mri1 = load_untouch_nii(['/Volumes/MLJ HD/GBM/Recurrence/NiftiFiles/Patient30/20120521_t1.nii.gz']);
% img1=double(mri1.img)*2;
% S=size(img1)-1;
% mri2 = load_untouch_nii(['/Volumes/MLJ HD/GBM/Recurrence/NiftiFiles/Patient30/20120718_t1.nii.gz']);
% img2=double(mri2.img)*2;

%get image resolution
dimt2=mri2.hdr.dime.pixdim(2:4);
dimt1=mri1.hdr.dime.pixdim(2:4);

% rescale images to conform with 160 bins (good values are between 80 and 256)
img2=img2/max(img2(:))*160;
img1=img1/max(img1(:))*160;
img22=img2;
%img11=img1;

%define center of rotation (mm from corner of img1)
center=[128 128 96]
%setting image-resolution for affine registration to 2mm
resolution=2;
[X1, X2, X3]=ndgrid(0:resolution:S(1),0:resolution:S(2),0:resolution:S(3));
pts=[X1(:) X2(:) X3(:)];

%vectorize images in 'resolution' resolution
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));
Itrival=(SplineInterpolation_tbb(pts,img1,[0 0 0],dimt1));


warning off MATLAB:nearlysingularmatrix
%initialize parameters to 0 for affine
p2=zeros(12,1);
%using 1-norm
%perform translation initialization
p2=minFunc(@cf_rigidPNorm_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
%include rotation
p2=minFunc(@cf_rigidPNorm_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);

%include scale
p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full affine 
%change parametrization from angles to.... matrix

[f df T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
p3=T(:);
p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);


p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full symmetric affine registration
p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1));

%resample img1 (1mm resolution) to prepare non-rigid registration
resolition=1;
[X1, X2, X3]=ndgrid(0:1:S(1),0:1:S(2),0:1:S(3));
ptsresample=[X1(:) X2(:) X3(:)];
[pts3]=do_sym_affine(p3(:),ptsresample,center);
Rtrival=(SplineInterpolation_lin(pts3,img1,[0 0 0],dimt1));
img11=reshape(Rtrival,size(X1));

%setting up non-rigid registration
resolution=2;
[X1, X2, X3]=ndgrid(0:resolution:S(1),0:resolution:S(2),0:resolution:S(3));
pts=[X1(:) X2(:) X3(:)];
Itrival=(SplineInterpolation_tbb(pts,img11,[0 0 0],[1 1 1]));
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));


% extracting positions with information
no=find(Itrival+Jtrival>0);

% initializ to 0
pp4=zeros([30 30 30 3]);
ww=[40 40 40];

%no. of points in deformation grid
grid_size=45;

for warp=[40 20]
%resampling deformation field to new resolution
  [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
  tpts=[XX1(:) XX2(:) XX3(:)]*warp;
  n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
%setting scale and offset of img11  
  scale=[1 1 1];
  offset=[1 1 1]*0;
  
%setting size of deformation grid and parametrization 
val=ones([grid_size grid_size grid_size 3]);
ww=[warp warp warp];
p4=reshape(n,size(val));
offset2=-ww;
pp4=p4;


pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),options2,size(p4),(0.0005),pts(no,:),img11,img2,Jtrival(no),Itrival(no),offset2,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);

pp4=reshape(pp4,size(p4));

saveparams(['c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_c' num2str(jdx(i))  ],pp4);
saveparams(['c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_p_c' num2str(jdx(i))  ],p3);
end
for warp=[10]

  [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
  tpts=[XX1(:) XX2(:) XX3(:)]*warp;
  n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
  
  scale=[1 1 1];
offset=[1 1 1]*0;
val=ones([grid_size grid_size grid_size 3]);
ww=[warp warp warp];
p4=reshape(n,size(val));

offset2=-ww;
pp4=p4;
pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),options3,size(p4),(0.0005),pts(no,:),img11,img2,Jtrival(no),Itrival(no),offset2,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);
pp4=reshape(pp4,size(p4));
saveparams(['c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_c' num2str(jdx(i))  ],pp4);
saveparams(['c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_p_c' num2str(jdx(i))  ],p3);
end
for warp=[5]

  [XX1, XX2, XX3]=ndgrid(1:grid_size,1:grid_size,1:grid_size);
  tpts=[XX1(:) XX2(:) XX3(:)]*warp;
  n=SplineInterpolation_lin(tpts,pp4,[0 0 0],ww);
  
  scale=[1 1 1];
offset=[1 1 1]*0;
val=ones([grid_size grid_size grid_size 3]);
ww=[warp warp warp];
p4=reshape(n,size(val));

offset2=-ww;
pp4=p4;
pp4=minFunc(@cf_SYM_NMI_SVF2,p4(:),options4,size(p4),(0.0005),pts(no,:),img11,img2,Jtrival(no),Itrival(no),offset2,[0 0 0],[0 0 0],ww,[1 1 1],dimt2,1);

pp4=reshape(pp4,size(p4));
saveparams(['c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_c' num2str(jdx(i))  ],pp4);
saveparams(['c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_p_c' num2str(jdx(i))  ],p3);
end

%end