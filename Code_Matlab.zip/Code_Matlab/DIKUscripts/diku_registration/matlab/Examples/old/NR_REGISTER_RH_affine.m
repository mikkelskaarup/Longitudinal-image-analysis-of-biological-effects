ipath = '/Volumes/MLJ HD/GBM/Recurrence/DicomFiles';
no_cores=4;
patients = {'Patient03'};


dpath=fullfile(ipath,patients{1});

% T1baseline = dir(fullfile(dpath,'Followup1','MR','*mpr*iso*'));
% baselineMR = T1baseline(1).name;
% T1=loadDicomFiles(fullfile(dpath,'Followup1','MR',baselineMR),'showwaitbar',0,'precision','single');

T2dir = dir(fullfile(dpath,'Baseline','MR','*t2*tra*'));
baselineT2 = T2dir(1).name;
T2baseline=loadDicomFiles(fullfile(dpath,'Baseline','MR',baselineT2),'showwaitbar',0,'precision','single');

T1dir = dir(fullfile(dpath,'Baseline','MR','*t1*tra*'));
baselineMR = T1dir(1).name;
T1baseline=loadDicomFiles(fullfile(dpath,'Baseline','MR',baselineMR),'showwaitbar',0,'precision','single');

T1baseline.info.PatientID = 'GBM';
T1baseline.info.PatientName = 'Patient03';
T1baseline.info.PatientBirthDate = '';
T2baseline.info.PatientBirthDate = '';
T2baseline.info.PatientName = 'Patient03';
T2baseline.info.PatientID = 'GBM';

T2dir = dir(fullfile(dpath,'Followup1','MR','*t2*tra*'));
baselineT2 = T2dir(1).name;
T2followup=loadDicomFiles(fullfile(dpath,'Followup1','MR',baselineT2),'showwaitbar',0,'precision','single');

T1dir = dir(fullfile(dpath,'Followup1','MR','*t1*tra*'));
baselineMR = T1dir(1).name;
T1followup=loadDicomFiles(fullfile(dpath,'Followup1','MR',baselineMR),'showwaitbar',0,'precision','single');

T1followup.info.PatientID = 'GBM';
T1followup.info.PatientName = 'Patient0l';
T1followup.info.PatientBirthDate = '';
T2followup.info.PatientBirthDate = '';
T2followup.info.PatientName = 'Patient0l';
T2followup.info.PatientID = 'GBM';

save(patients{1},'T1baseline','T2baseline','T1followup','T2followup')

% try
% parpool(no_cores)
% catch
% end

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

options2=options;
options2.MaxIter=100;
options3=options;
options3.MaxIter=100;
options4=options;
options4.MaxIter=100;


warning off all
%parfor i=1:noMRIfilesT1
i = 1;
% read images
%CT=load_nii(fullfile(dpath,CTfileName));

%get image resolution
dimt1=[T1.info.PixelSpacing' abs(T1.Z(1,1,1)-T1.Z(1,1,2))];
dimt2=[T2.info.PixelSpacing' abs(T2.Z(1,1,1)-T2.Z(1,1,2))];
 img1=double(T1.vol);
            img2=double(T2.vol);
% Image size [mm]
S1=round(size(img1).*dimt1);
S2=round(size(img2).*dimt2);
Smax=max(S1,S2);
% rescale images to conform with 160 bins (good values are between 80 and 256)
img1=img1-min(img1(:));
img2=img2-min(img2(:));
img2=img2/max(img2(:))*160;
img1=img1/max(img1(:))*160;

%define center of rotation (mm from corner of img1)
center=[floor(Smax(1)/2) floor(Smax(2)/2) floor(Smax(3)/2)]
%setting image-resolution for affine registration to 1mm
resolution=[1 1 1]*2;
%resolution = dimt1;

[X11, X21, X31]=ndgrid(0:resolution(2):Smax(1),0:resolution(1):Smax(2),0:resolution(3):Smax(3));
pts=[X11(:), X21(:), X31(:)];
%vectorize images in 'resolution' resolution
Jtrival=(SplineInterpolation_tbb(pts,img2,[0 0 0],dimt2));
Itrival=(SplineInterpolation_tbb(pts,img1,[0 0 0],dimt1));

%initialize parameters to 0 for affine
p2=zeros(12,1);
%using 1-norm
%perform translation initialization
p2=minFunc(@cf_rigidPNorm_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
%include rotation
p2=minFunc(@cf_rigidPNorm_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);

%include scale
p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full affine 
%change parametrization from angles to.... matrix

[f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
p3=T(:);
p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);


p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));

%full symmetric affine registration
p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1));

[X11, X2, X3]=ndgrid(0:dimt1(1):S1(1),0:dimt1(2):S1(2),0:dimt1(3):S1(3));
org_pts=[X11(:) X2(:) X3(:)];
[X1, X2, X3]=ndgrid(0:dimt2(1):S1(1),0:dimt2(2):S1(2),0:dimt2(3):S1(3));
org_pts2=[X1(:) X2(:) X3(:)];

n1=SplineInterpolation_lin(org_pts+repmat(0.5*dimt1,numel(X11),1),double(CT.img(:,:,:)),[0 0 0],dimt1);
n11=SplineInterpolation_lin(org_pts2+repmat(0.5*dimt2,numel(X1),1),double(MRI.img(:,:,:)),[0 0 0],dimt2);

I1 = reshape(n1,size(X11));
I11 = reshape(n11,size(X1));

%img2 matched to img1 by affine
[pts3, ipts3]=do_sym_affine(p3(:),org_pts,center);

n3=SplineInterpolation_lin(pts3+repmat(0.5*dimt2,numel(X11),1),double(MRI2.img(:,:,:)),[0 0 0],dimt2);
%img1 (from the run script) matched to img2 by first inv affine and then
%nr warp
[pts3, ipts3]=do_sym_affine(p3(:),org_pts2,center);
n33=SplineInterpolation_lin(ipts3+repmat(0.5*dimt1,numel(X1),1),double(MRI.img(:,:,:)),[0 0 0],dimt1);



%end