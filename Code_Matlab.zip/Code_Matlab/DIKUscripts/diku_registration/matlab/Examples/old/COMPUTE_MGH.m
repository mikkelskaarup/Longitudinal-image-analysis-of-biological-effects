dpath='/Users/MLJ/Documents/MGH10';

cnt=1;
for ii=1
    for jj=ii+1:5
        idx(cnt)=ii;
        jdx(cnt)=jj;
        cnt=cnt+1;
    end
end

warning off all

%parfor i=1:4
i = 1;

% Load scans
mri1=load_nii([dpath '/EHeads/g' num2str(idx(i)) '.nii']);
mri2=load_nii([dpath '/EHeads/g' num2str(jdx(i)) '.nii']);
% Set dimensions of scans
dim1=mri1.hdr.dime.pixdim(2:4);
dim2=mri2.hdr.dime.pixdim(2:4);

% Load affine
pt=load([dpath '/Warps/c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_p_c' num2str(jdx(i)) '.mat' ]);
S1=size(mri1.img).*dim1-1;
p3=pt.p;
% Load non-rigid
pt2=load([dpath '/Warps/c' num2str(idx(i)) 'MGH0_0004_160_dr_iter_c' num2str(jdx(i)) '.mat' ]);
S2=size(mri2.img).*dim2-1;
pp4=pt2.p;

% 
center=[128 128 96]
ww=[5 5 5];
offset2=-ww;

% Create grids
% Scan 1
[X11, X21, X31]=ndgrid(0:dim1(1):S1(1),0:dim1(2):S1(2),0:dim1(3):S1(3));
org_pts1 = [X11(:) X21(:) X31(:)];
% Scan 2
[X12, X22, X32]=ndgrid(0:dim2(1):S2(1),0:dim2(2):S2(2),0:dim2(3):S2(3));
org_pts2 = [X12(:) X22(:) X32(:)];

%%%%%% Forward transform img2 to space of img1
% first affine
[pts3]=do_sym_affine(p3(:),org_pts2,center);
% then non-rigid warp 
tic;[nr_pts]=SS_Trap_1st(pts3,pp4,offset2,ww,double(40),double(5));toc

% Resample using linear interpolation
% n3nn = NNInterpolation_lin(pts3+repmat(0.5*dim2,numel(X11),1),double(mri2.img(:,:,:)),[0 0 0],dim2);
n3 = SplineInterpolation_lin(nr_pts+repmat(0.5*dim2,numel(X12),1),double(mri1.img),[0 0 0],dim2);
mri2_warped = reshape(n3,size(mri2.img));


%%%%%% Backward transform img1 to space of img2
% first inv affine 
[~, ipts3]=do_sym_affine(p3(:),org_pts1,center);
% and then non-rigid warp
tic;[inr_pts]=SS_Trap_1st(ipts3,-pp4,offset2,ww,double(40),double(5));toc

% Resample using linear interpolation
% n33=NNInterpolation_lin(inr_pts+repmat(0.5*dim1,numel(X1),1),double(mri1.img(:,:,:)),[0 0 0],dim1);
n33 = SplineInterpolation_lin(inr_pts+repmat(0.5*dim1,numel(X11),1),double(mri1.img),[0 0 0],dim1);
mri_warped = reshape(n33,size(mri1.img));


%end

%%
slice1=90;
figure(1)
imagesc(squeeze(img1(:,:,slice1)))
figure(2),
imagesc(squeeze(img2(:,:,slice1)))
figure(3),
imagesc(squeeze(img11(:,:,slice1)))
% figure(4),
% imagesc(squeeze(mri_warped(:,:,slice1)))
