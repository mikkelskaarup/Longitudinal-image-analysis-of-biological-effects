%ipath = '/Volumes/Windows/GBM/Recurrence/DicomFiles';
ipath = '/Volumes/MLJ HD/GBM/Recurrence/Anonymized';
%ipath = '/Volumes/MLJ HD/GBM/IDEPREG/DicomFiles';

%ipath='/Users/MLJ/Documents/Dicom';
%ipath='H:\Windows\GBM\Recurrence\DicomFiles';
%opath='H:\Windows\DIKU_registration\RegOutput';
opath='/Volumes/MLJ HD/GBM/Recurrence/RegOutput';
%opath='/Volumes/MLJ HD/GBM/IDEPREG/RegOutput';


%%

CREATEMONTAGE = 1;

options.Method='lbfgs';
options.display = 'full';
options.MaxIter=200;
options.MaxFunEvals=500;
options.TolFun=10^(-8);
options.TolX=10^(-8);
options.numDiff=0;
options.DerivativeCheck='off';

BsplineOptions = options;
BsplineOptions.MaxIter = 30;
%
warning off all

%patients = {'Patient03','Patient09','Patient19','Patient22','Patient23','Patient30','Patient50','Patient0l','Patient0t','Patient0ad','Patient0o','Patient0r'};
patients = {'Patient0a'};


%for j = 1:length(patients)
j =1;
    dpath=fullfile(ipath,[patients{j} ' [GBM]']);
    outpath=fullfile(opath,patients{j});
    if ~exist(outpath,'file')
        mkdir(outpath)
    end
    
    study = 'Baseline';
    % get filenames
    T1dir = dir(fullfile(dpath,study,'MR','*t1*iso*'));
    T1dir = T1dir(1).name;
    T2dir = dir(fullfile(dpath,study,'MR','*t2*tse*tra*'));
    T2dir = T2dir(1).name;
    
    % read images
    MRI1=loadDicomFiles(fullfile(dpath,study,'MR',T1dir),'showwaitbar',0,'precision','double');
    MRI2=loadDicomFiles(fullfile(dpath,study,'MR',T2dir),'showwaitbar',0,'precision','double');
   %% 
    %img1=double(MRI1.vol);
    %img2=double(MRI2.vol);
    img1=MRI1.vol;
    img2=MRI2.vol;
    
    %img1 = img1(15:end-15,15:end-15,20:end-11);
    
    %get image resolution
    dimt1=[MRI1.info.PixelSpacing' abs(MRI1.Z(1,1,1)-MRI1.Z(1,1,2))];
    dimt2=[MRI2.info.PixelSpacing' abs(MRI2.Z(1,1,1)-MRI2.Z(1,1,2))];
    
    % Image size [mm]
    S1=round(size(img1).*dimt1);
    S2=round(size(img2).*dimt2);
    Smax=max(S1,S2);
    
    %define center of rotation (mm from corner of img1)
    center=[floor(Smax(1)/2) floor(Smax(2)/2) floor(Smax(3)/2)]
    %setting image-resolution for affine registration to 1mm
    resolution=[1 1 1]*2;
    %resolution = dimt1;
    %%
    %create Bspline images
    S=size(img1);
    S=S-1;
    [X1, X2, X3]=ndgrid(0:1:S(1),0:1:S(2),0:1:S(3));
    pts=[X1(:) X2(:) X3(:)];
    clear X1 X2 X3
    p=zeros(size(img1));
    p2=minFunc(@cf_fitBspline,p(:),BsplineOptions,pts,img1,[0 0 0]+1e-8,[1 1 1]);
    Bspline_img1=reshape(p2, size(img1));
    img1 = Bspline_img1;
      
    S=size(img2)
    S=S-1;
    [X1, X2, X3]=ndgrid(0:1:S(1),0:1:S(2),0:1:S(3));
    pts=[X1(:) X2(:) X3(:)];
    p=zeros(size(double(MRI2.vol)));
    p2=minFunc(@cf_fitBspline,p(:),BsplineOptions,pts,img2,[0 0 0]+1e-8,[1 1 1]);
    Bspline_img2=reshape(p2, size(double(MRI2.vol)));
    img2 = Bspline_img2;
    
    % rescale images to conform with 160 bins (good values are between 80 and 256)
    img1=img1-min(img1(:));
    img2=img2-min(img2(:));
    img2=img2/max(img2(:))*160;
    img1=img1/max(img1(:))*160;
    
    
    [X11, X21, X31]=ndgrid(0:resolution(2):Smax(1),0:resolution(1):Smax(2),0:resolution(3):Smax(3));
    pts=[X11(:), X21(:), X31(:)];

    %vectorize images in 'resolution' resolution
    Itrival=(SplineInterpolation(pts,img1,[0 0 0],dimt1));
    Jtrival=(SplineInterpolation(pts,img2,[0 0 0],dimt2));
    
    %initialize parameters to 0 for affine
    p2=zeros(12,1);
    
    % estimate centroid for both scans and initialize registration
    [id]=kmeans(img2(:),2);
    cls=reshape(id,size(img2));
    cls=2-cls;
    props2=regionprops(cls,'Centroid');
    [id]=kmeans(img1(:),2);
    cls=reshape(id,size(img1));
    cls=2-cls;
    props1=regionprops(cls,'Centroid');
    cDiff = props1.Centroid.*dimt1 - props2.Centroid.*dimt2;
    
    p2(4)=cDiff(2); p2(5)=cDiff(1); p2(6)=cDiff(3);
    
    %using 1-norm
    %perform translation initialization
    %p2=minFunc(@cf_rigidPNorm_3dPW_NR,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
    
    %include rotation
    %p2=minFunc(@cf_rigidPNorm_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1),1);
    p2=minFunc(@cf_rigidNMI_3dPW,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
    
    %include scale
    p2=minFunc(@cf_rigidNMI_3dPWS,p2(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
    
    %full affine
    %change parametrization from angles to.... matrix
    
    [f, df, T]=cf_rigidNMI_3dPWS(p2(:),img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
    p3=T(:);
    p3(10)=p2(4);p3(11)=p2(5);p3(12)=p2(6);
    
    p3=minFunc(@cf_affineNMI_3dPW,p3(:),options,img1,pts,center,Jtrival,dimt1,ones(size(pts,1),1));
    
    %full symmetric affine registration
    p3=minFunc(@cf_sym_affine_NMI,p3(:),options,img1,img2,pts,center,Itrival,Jtrival,dimt1,dimt2,ones(size(pts,1),1));
    
    
    saveparams(fullfile(outpath,[study 'T1T2_affine']),p3);
    
    % Reconstruct and save
    [X11, X21, X31]=ndgrid(0:dimt1(1):S1(1)-dimt1(1),0:dimt1(2):S1(2)-dimt1(2),0:dimt1(3):S1(3)-dimt1(3));
    org_pts1=[X11(:), X21(:), X31(:)];
    [X12, X22, X32]=ndgrid(0:dimt2(1):S2(1)-dimt2(1),0:dimt2(2):S2(2)-dimt2(2),0:dimt2(3):S2(3)-dimt2(3));
    org_pts2=[X12(:), X22(:), X32(:)];
    
    n1=SplineInterpolation_lin(org_pts1+repmat(0*dimt1,numel(X11),1),double(MRI1.vol),[0 0 0],dimt1);
    n11=SplineInterpolation_lin(org_pts2+repmat(0*dimt2,numel(X12),1),double(MRI2.vol),[0 0 0],dimt2);
    
    [~, ipts3]=do_sym_affine(p3(:),org_pts1,center);
    n2=SplineInterpolation_lin(ipts3+repmat(0*dimt2,numel(X11),1),double(MRI2.vol),[0 0 0],dimt2);
    
    pts3=do_sym_affine(p3(:),org_pts2,center);
    n33=SplineInterpolation_lin(pts3+repmat(0*dimt1,numel(X12),1),double(MRI1.vol),[0 0 0],dimt1);
    
    
    img1orig = reshape(n1,size(X11));
    img2orig = reshape(n11,size(X12));
    img2affine = reshape(n2,size(X11));
    img1affine = reshape(n33,size(X12));
    
    save([outpath filesep 'T1' study 'Original'],'img1orig')
    save([outpath filesep 'T2' study 'Original'],'img2orig')
    
    save([outpath filesep 'T2' study 'Affine'],'img2affine')
    save([outpath filesep 'T1' study 'Affine' ],'img1affine')
    
    
%end