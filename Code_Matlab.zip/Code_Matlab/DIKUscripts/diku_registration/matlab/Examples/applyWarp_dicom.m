set(0,'DefaultFigureWindowStyle','normal')
%dpath='H:\Windows\GBM\Recurrence\NiftiFiles\Patient0t\';
%dpath='/Users/MLJ/Documents/Nifti/Patient0t/';
%dpath = '/Volumes/Windows/GBM/Recurrence/DicomFiles/Patient0t';
opath='/Volumes/MLJ HD/GBM/Recurrence/RegOutput';
ipath = '/Volumes/MLJ HD/GBM/Recurrence/DicomFiles';
patient = 'Patient0l';
dpath=fullfile(ipath,patient);
outpath=fullfile(opath,patient);

% get number of MR scans in folder 
MRIbaseline = dir(fullfile(dpath,'Baseline','MR','*t1*tra*'));
baselineMR = MRIbaseline(1).name;
followupStudies = dir(fullfile(dpath,'*ollow*'));
noFollowup = length(followupStudies);

fDirs = cell(noFollowup+1,1);
fDirs{1} = fullfile(dpath,'Baseline','MR',baselineMR);
for i = 1:noFollowup
    currentFollowupStudy = followupStudies(i).name;
    t1FolderName = dir(fullfile(dpath,currentFollowupStudy,'MR','*t1*tra*'));
    fDirs{i+1} = fullfile(dpath,currentFollowupStudy,'MR',t1FolderName.name);
end

scan1 = 1;
scan2 = 3;

MRI1=loadDicomFiles(fDirs{scan1},'showwaitbar',0);
MRI2=loadDicomFiles(fDirs{scan2},'showwaitbar',0);
    
img1=double(MRI1.vol);
img2=double(MRI2.vol);

%get image resolution
dimt1=[MRI1.info.PixelSpacing' abs(MRI1.Z(1,1,1)-MRI1.Z(1,1,2))];
dimt2=[MRI2.info.PixelSpacing' abs(MRI2.Z(1,1,1)-MRI2.Z(1,1,2))];

% Image size [mm]
S1=round(size(img1).*dimt1);
S2=round(size(img2).*dimt2);
Smax=max(S1,S2);

% rescale images to conform with 160 bins (good values are between 80 and 256)
img1=img1-min(img1(:));
img2=img2-min(img2(:));
img2=img2/max(img2(:))*80;
img1=img1/max(img1(:))*80;

%define center of rotation (mm from corner of img1)
center=[floor(Smax(1)/2) floor(Smax(2)/2) floor(Smax(3)/2)]

% Load affine registration from REGISTER_RH_affine
p = load(fullfile(outpath,['MR' num2str(scan1) '_to_MR' num2str(scan2) '_RH_patient0t_affine']));
p = load(fullfile(outpath,['MR' num2str(scan1) '_to_MR' num2str(scan2) '_RH_patient0t_rigid']));
%p = load(fullfile(outpath,['MR' num2str(scan1) '_to_MR' num2str(scan2) '_RH_patient0t_trans']));
p3 = p.p;
% Load non-rigid registration
%p = load(fullfile(outpath,['MR' num2str(followup1) '_to_MR' num2str(followup2) '_RH_patient0t_NR']));
%pp4 = p.p;
%%
[X11, X21, X31]=ndgrid(0:dimt1(1):S1(1)-dimt1(1),0:dimt1(2):S1(2)-dimt1(2),0:dimt1(3):S1(3)-dimt1(3));
    org_pts1=[X11(:), X21(:), X31(:)];
[X12, X22, X32]=ndgrid(0:dimt2(1):S2(1)-dimt2(1),0:dimt2(2):S2(2)-dimt2(2),0:dimt2(3):S2(3)-dimt2(3));
    org_pts2=[X12(:), X22(:), X32(:)];

n1=SplineInterpolation_lin(org_pts1+repmat(0*dimt1,numel(X11),1),double(MRI1.vol),[0 0 0],dimt1);
n11=SplineInterpolation_lin(org_pts2+repmat(0*dimt2,numel(X12),1),double(MRI2.vol),[0 0 0],dimt2);

%%
% non-rigid parameters
pyramidLevels = [40 20 10];
ww = [pyramidLevels(end) pyramidLevels(end) pyramidLevels(end)];
offset2 = -ww;

%%
%img2 matched to img1 by inv affine
[pts3, ipts3]=do_sym_affine(p3(:),org_pts1,center);
n2=SplineInterpolation_lin(ipts3+repmat(0*dimt2,numel(X11),1),double(MRI2.vol),[0 0 0],dimt2);
% non-rigid
%tic;inr_pts = SS_Trap_1st(ipts3,-pp4,offset2,ww,40,5));toc
%n3=SplineInterpolation_lin(inr_pts+repmat(0*dimt2,numel(X11),1),double(MRI2.vol),[0 0 0],dimt2);


%nr warp
%tic;[nr_pts]=SS_Trap_1st(org_pts2,pp4,offset2,ww,40,5);toc
[pts3, ipts3]=do_sym_affine(p3(:),org_pts2,center);
n33=SplineInterpolation_lin(pts3+repmat(0*dimt1,numel(X12),1),double(MRI1.vol),[0 0 0],dimt1);


img11 = reshape(n1,size(X11));
img21 = reshape(n11,size(X12));

img12 = reshape(n2,size(X11));

%img123 = reshape(n3,size(X11));
img22 = reshape(n33,size(X12));
%%
save([outpath filesep 'MR' num2str(scan1) 'original'],'img11')
save([outpath filesep 'MR' num2str(scan2) 'original'],'img21')

save([outpath filesep 'MR' num2str(scan2) 'affine to MR' num2str(scan1)],'img12')
save([outpath filesep 'MR' num2str(scan1) 'affine to MR' num2str(scan2)],'img22')

%save([outpath filesep 'MR' num2str(scan2) 'affine+NR to MR' num2str(scan1)],'img123')

%end

%%
MRI1slice = 33;
figure(1),imagesc(squeeze(img11(:,:,MRI1slice))),title(['Original followup ' num2str(scan1)])
figure(2),imagesc(squeeze(img12(:,:,MRI1slice))),title(['Affine followup ' num2str(scan2)])
%figure(3),imagesc(squeeze(img123(:,:,MRI1slice))),title(['Affine+NR followup ' num2str(scan2)])

%%
MRI2slice = 29;
figure(4),imagesc(img21(:,:,MRI2slice)),title(['Original followup ' num2str(scan2)])
figure(5),imagesc(img22(:,:,MRI2slice)),title(['Affine+NR followup ' num2str(scan1)])
%figure(6),imagesc(imfuse(img21(:,:,MRI2slice),img22(:,:,MRI2slice)));axis image

%%
% MRI1SAGslice = 125;
% figure(1),imagesc(squeeze(img11(:,MRI1SAGslice,:))),
% figure(2),imagesc(squeeze(img12(:,MRI1SAGslice,:))),
% figure(3),imagesc(imfuse(squeeze(img11(:,MRI1SAGslice,:)),squeeze(img12(:,MRI1SAGslice,:))));
%%
% D = 25;
% P = ceil(size(img11,1)/D/2);
% Q = ceil(size(img11,2)/D/2);
% C = checkerboard(D,P,Q);
% C = (C > 0.5);
% C1 = abs(C-1);
% MRI1SAGslice = 301;
% img111 = squeeze(img11(:,MRI1SAGslice,:));
% img11c = img111.*(C(1:size(img111,1),1:size(img111,2)));
% img121 = squeeze(img12(:,MRI1SAGslice,:));
% img12c = img121.*(C1(1:size(img121,1),1:size(img121,2)));
% 
% I = img11c+img12c;
% figure(7)
% imagesc(rot90(I))
% 
% %%
% D = 25;
% P = ceil(size(img11,1)/D/2);
% Q = ceil(size(img11,2)/D/2);
% C = checkerboard(D,P,Q);
% C = (C > 0.5);
% C1 = abs(C-1);
% MRI1CORslice = 100;
% img111 = squeeze(img11(MRI1CORslice,:,:));
% img11c = img111.*(C(1:size(img111,1),1:size(img111,2)));
% img121 = squeeze(img12(MRI1CORslice,:,:));
% img12c = img121.*(C1(1:size(img121,1),1:size(img121,2)));
% 
% I = img11c+img12c;
% figure(7)
% imagesc(rot90(I))
% %%
% D = 10;
% P = ceil(size(img21,1)/D);
% Q = ceil(size(img21,2)/D);
% C = checkerboard(D,P,Q);
% C = (C > 0.5);
% C1 = abs(C-1);
% MRI1CORslice = 100;
% img211 = squeeze(img21(MRI1CORslice,:,:));
% img21c = img211.*(C(1:size(img211,1),1:size(img211,2)));
% img221 = squeeze(img22(MRI1CORslice,:,:));
% img22c = img221.*(C1(1:size(img221,1),1:size(img221,2)));
% 
% I = img21c+img22c;
% figure(8)
% imagesc(rot90(I))