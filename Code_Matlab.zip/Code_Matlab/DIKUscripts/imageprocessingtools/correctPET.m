%correctPET     Correct PET data
%   Correct PET-images to activity given in (0028,1054) - Rescale Type, 
%   (0054,1001) - Units or SUV (if flagged)
%
%   INPUTS
%   slice       -   Raw dicom slice with pixel data
%   info        -   Dicom info structure read by 'dicominfo' from
%                   Image Processing Toolbox
%   suvFlag     -   Flag for converting pixeldata to SUV
%
%
%   EXPLANATION                     -   DICOM-TAG
%   Total Dose Injected             -   (0018,1074)
%   Series Date                     -   (0008,0021)
%   Series Time                     -   (0008,0031)
%   Radiophamaceutical Start Time   -   (0018,1072)
%   Radiophamaceutical Half Life    -   (0018,1075)
%   Patient Weight                  -   (0010,1010)

function PETcorrected = correctPET(slice,info,suvFlag)

% Concentration of injected tracer Bq/mL
if size(slice,1) > 1
    C = double(slice) .* info.RescaleSlope + info.RescaleIntercept;
else
    C = double(slice);
end

if suvFlag % convert to SUV
    WEIGTH      = info.PatientWeight*1000;
    DTOTAL      = info.RadiopharmaceuticalInformationSequence.Item_1.RadionuclideTotalDose; % in Bq
    date        = info.AcquisitionDate; % yyyymmdd
    DATE        = [str2double(date(1:4)) str2double(date(5:6)) str2double(date(7:8))]; % [yyyy mm dd]
    ij          = info.RadiopharmaceuticalInformationSequence.Item_1.RadiopharmaceuticalStartTime; 
    if strcmp(ij(3),':') % hh:mm:ss
        INJECTION   = [DATE str2double(ij(1:2)) str2double(ij(4:5)) str2double(ij(7:end))]; % [yyyy mm dd hh mm ss]
    else % hhmmss.xxxx
        INJECTION   = [DATE str2double(ij(1:2)) str2double(ij(3:4)) str2double(ij(5:end))]; % [yyyy mm dd hh mm ss]
    end
    acq         = info.AcquisitionTime;
    if strcmp(acq(3),':') % hh:mm:ss
        ACQUISITION = [DATE str2double(acq(1:2)) str2double(acq(4:5)) str2double(acq(7:end))]; % [yyyy mm dd hh mm ss]
    else % hhmmss
        ACQUISITION = [DATE str2double(acq(1:2)) str2double(acq(3:4)) str2double(acq(5:end))]; % [yyyy mm dd hh mm ss]
    end
    
    HALFLIFE    = info.RadiopharmaceuticalInformationSequence.Item_1.RadionuclideHalfLife; % seconds
    LAMBDA      = log(2)/HALFLIFE;
    
    % Activity at acquisition time
    acqActivity = DTOTAL * exp(-LAMBDA * etime(ACQUISITION,INJECTION) );
    
    % Estimate SUV
    PETcorrected = C ./ (acqActivity/WEIGTH);
    %disp(max(PETcorrected(:)))
else
    PETcorrected = C;
end


