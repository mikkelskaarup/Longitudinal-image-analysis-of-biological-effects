function ci = calculateConcordanceIndex(logicmask1,logicmask2)

intersect = logicmask1 & logicmask2;
union = logicmask1 | logicmask2;

ci = sum(intersect(:))/(sum(union));