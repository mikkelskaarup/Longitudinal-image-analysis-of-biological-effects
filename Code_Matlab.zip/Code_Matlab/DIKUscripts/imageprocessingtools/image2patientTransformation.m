% Inspiration from http://cmic.cs.ucl.ac.uk/fileadmin/cmic/Documents/DavidAtkinson/DICOM_6up.pdf
% See DICOM standard PS 3.3-2009: Information Object Definitions p. 377

function [M,R] = image2patientTransformation(info)

% Translate to put top left pixel at ImagePositionPatient
Tipp = [1 0 0 info.ImagePositionPatient(1);
        0 1 0 info.ImagePositionPatient(2);
        0 0 1 info.ImagePositionPatient(3);
        0 0 0 1];
    
% Rotate image into Patient coordinate, using Direction Cosines from
% ImageOrientationPatient (two orthogonal unit vectors)
v1 = info.ImageOrientationPatient(1:3);
v2 = info.ImageOrientationPatient(4:6);
% Third orthogonal vector
v3 = cross(v1',v2');

R = [v1(1) v2(1) v3(1) 0;
     v1(2) v2(2) v3(2) 0;
     v1(3) v2(3) v3(3) 0;
     0 0 0 1];
 
if ~isempty(info.SliceThickness)
    dz = info.SliceThickness;
elseif isfield(info,'GridFrameOffsetVector')
    dz = info.GridFrameOffsetVector(2)-info.GridFrameOffsetVector(1);
else 
    error('Slice thickness not found!');
end
% Scale using PixelSpacing and SliceThickness
S = [info.PixelSpacing(1) 0 0 0;
     0 info.PixelSpacing(2) 0 0;
     0 0 dz  0;
     0 0 0 1];
 
% Shift to make top left voxel center at (0,0,0)
% N.B. Only necessary if imageCoordinate vector if [1:nRows x 1:nCols]
T0 = [0 0 0 info.PixelSpacing(1);
        0 0 0 info.PixelSpacing(2);
        0 0 0 dz;
        0 0 0 0];

M = Tipp*R*S-T0;
