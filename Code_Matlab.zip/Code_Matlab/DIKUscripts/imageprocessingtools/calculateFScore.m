function [F,P,R] = calculateFScore(tv,tfv,beta)
% Calculates the Precision, P, and Recall, R, as well as their harmonic
% mean, denoted the F-score

if nargin < 3
    beta = 1;
end
% True positive
TP = tv & tfv;
TP = sum(TP(:));

% Precision, noTruePositive / noPredictedPositive
P = TP/sum(tv(:));

% Recall, noTruePositive / noActualPositive
R = TP/sum(tfv(:));

% F-score
F = (1+beta^2)*P*R/((beta^2*P)+R);