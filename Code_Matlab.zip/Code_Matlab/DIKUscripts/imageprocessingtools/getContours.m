function [x,y,z] = getContours(S,contour)

if ~isfield(S,contour)
    error('Contour not found!');
end

C = S.(contour);
slices = fieldnames(C);
noSlices = length(slices);

x = zeros(S.contour.TotalNumberOfContourPoints);
y = x;
z = x;

i = 0;

for slice = 1:noSlices % Loop over slices
    noContours = length(fieldnames(S.(contour).(['Slice_' num2str(slice)])));
    for c = 1:noContours % Loop over contours within slice
        xc = S.(contour).(['Slice_' num2str(slice)]).(['Contour' num2str(c)]).x;
        yc = S.(contour).(['Slice_' num2str(slice)]).(['Contour' num2str(c)]).y;
        zc = S.(contour).(['Slice_' num2str(slice)]).(['Contour' num2str(c)]).z;
        
        x( i+1:length(xc)+i ) = xc;
        y( i+1:length(xc)+i ) = yc;
        z( i+1:length(xc)+i ) = zc;
        
        i = i+length(xc);
    end
end


