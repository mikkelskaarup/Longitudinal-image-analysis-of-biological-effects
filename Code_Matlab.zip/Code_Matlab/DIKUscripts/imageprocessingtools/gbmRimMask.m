function rim = gbmRimMask(mask,border)

kernel = [1 1 1; 1 1 1; 1 1 1];

switch border
    case 'inner'
        reducedMask = convn(mask,kernel,'same');
        reducedMask2 = (reducedMask==max(reducedMask(:)));
        rim = mask-reducedMask2;
    case 'outer'
        expandedMask = convn(~mask,kernel,'same');
        expandedMask2 = (expandedMask==max(expandedMask(:)));
        expandedMask3 = (mask-expandedMask2) == 0;
        expandedMask3([1:3,end-3:end],:,:) = 0;
        expandedMask3(:,[1:3,end-3:end],:) = 0;
        expandedMask3(:,:,[1:3,end-3:end]) = 0;
        rim = expandedMask3;
    otherwise
        error('Specify border! Must be "inner" or "outer".');
end

rim = rim==1;
