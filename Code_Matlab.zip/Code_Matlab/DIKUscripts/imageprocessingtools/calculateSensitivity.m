function S = calculateSensitivity(tv,tfv)

% True positive
TP = tv & tfv;
TP = sum(TP(:));
% False negative
FN = tfv & ~tv;
FN = sum(FN(:));

S = TP / (TP+FN);