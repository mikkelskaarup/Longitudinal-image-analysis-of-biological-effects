function [maxDist,distances] = contourDistance(mask1,mask2,aspect)

distmap1 = bwdistsc(mask1,aspect);
distmap2 = bwdistsc(mask2,aspect);

reducedMask = shrinkMask(mask2);

maskCompl = (~mask1 & (mask1 | (mask2)));
maskCompl2 = maskCompl&~reducedMask;

diffmap = (distmap1-distmap2).*maskCompl2;

distances = diffmap(diffmap~=0);

if isempty(distances)
    maxDist = 0;
else
    maxDist=max(distances);
end
