function R = getRobject(V,worldCoordinates)

if nargin < 2
    worldCoordinates = 'world';
end

if ~isfield(V,'vol')
    error('Wrong input volume');
end

m = size(V.X);
dim = ndims(V.vol);

if ~(dim==2 || dim==3 || dim==4)
    error('Number of dimensions must be 2, 3 or 4!')
end

% Transform coordinates, if FoV is oblique
points = [V.X(:),V.Y(:),V.Z(:),ones(size(V.X(:)))];
pointsW = (points*V.R);
clear points

tmp.X = reshape(pointsW(:,1),m);
tmp.Y = reshape(pointsW(:,2),m);
tmp.Z = reshape(pointsW(:,3),m);

%Make 3D image reference to world coordinates
dx = tmp.X(1,2,1) - tmp.X(1,1,1);
dy = tmp.Y(2,1,1) - tmp.Y(1,1,1);
dz = tmp.Z(1,1,2) - tmp.Z(1,1,1);

xWorldLimits = [tmp.X(1,1,1)-dx/2,tmp.X(1,m(2),1)+dx/2];
yWorldLimits = [tmp.Y(1,1,1)-dy/2,tmp.Y(m(1),1,1)+dy/2];

if dz > 0
    zWorldLimits = [tmp.Z(1,1,1)-dz/2,tmp.Z(1,1,m(3))+dz/2];
else
    dz = abs(dz);
    zWorldLimits = [tmp.Z(1,1,m(3))-dz/2,tmp.Z(1,1,1)+dz/2];
end

% fprintf('resolution x: %0.1f, y: %0.1f, z: %0.1f\n',dx,dy,dz);

voxelSize = [dx dy dz]';

if strcmpi(worldCoordinates,'world')
    if dim == 3 || 4
        R = imref3d(m,xWorldLimits,yWorldLimits,zWorldLimits);
    else
        R = imref2d(m,xWorldLimits,yWorldLimits);
    end
else
    if dim == 3 || 4
        R = imref3d(m,voxelSize(1),voxelSize(2),voxelSize(3));
    else
        R = imref2d(m,voxelSize(1),voxelSize(2));
    end
end
