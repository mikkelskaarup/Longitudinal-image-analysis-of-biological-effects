% load data:
clear all
file_dir = '/Volumes/ASTRID/DCE_perfusion/Kierkegaard__Sylvia/Petmr_Hjerne_Fet - 37107294/Head_DCE_vibe_14deg_18';
%Data = DICOM2MatLab(file_dir);

dicomfile=fullfile(file_dir,'IM-0001-0001.dcm');
dicomheader=dicominfo(dicomfile);
%data=zeros(dicomheader.Width,dicomheader.Height,dicomheader.NumberOfSlices);

%D = dir([file_dir, '*.dcm']);
%NumberOfSlices = length(D(not([D.isdir])));
NumberOfSlices = 120;

[data_temp,map]=dicomread(dicomfile);
data=zeros(size(data_temp,1),size(data_temp,2),NumberOfSlices,'uint16');


for ss=1:NumberOfSlices%dicomheader.NumberOfSlices
    filename=['IM-0001-' num2str(ss,'%04d')];
    dicomfile=fullfile(file_dir,filename);
    [data(:,:,ss),map] = dicomread(dicomfile);
end

figure(1)
figure, imagesc(data(:,:,30))

average = zeros(size(data_temp,1),size(data_temp,2),30,'uint16');

average(:,:,1:30) = (data(:,:,1:30) + data(:,:,(1:30)+30) + data(:,:,(1:30)+2*30) + data(:,:,(1:30)+3*30))/4;


new_dicom = zeros(size(data_temp,1),size(data_temp,2),120,'uint16');

for j=1:4
    new_dicom(:,:,(1:30)+30*(j-1)) = average(:,:,1:30);
end

% Convert new_dicom from mat to dicom.

SeriesUID = dicomuid;

% Write new DICOM files
file_dir_new=[file_dir 'modified'];
mkdir(file_dir_new);
for ss=1:NumberOfSlices
    filename=['IM-0001-' num2str(ss,'%04d') '.dcm'];
    dicom_ref=fullfile(file_dir,filename);
    DCMinfo=dicominfo(dicom_ref);
    DCMinfo.SeriesNumber = 200;
    DCMinfo.SeriesInstanceUID = SeriesUID;
    %DCMinfo.SeriesDescription = [DCMinfo.SeriesDescription, '_fugue'];
    DCMinfo.SeriesDescription = 'gennemsnit';
    %DCMinfo.PrivateInformationCreatorUID='';
    X=squeeze(new_dicom(:,:,ss));
    dicom_new=fullfile(file_dir_new,filename);
    dicomwrite(X, dicom_new, DCMinfo);
end
