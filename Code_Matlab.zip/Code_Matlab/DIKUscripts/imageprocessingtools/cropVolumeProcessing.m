
workingDir = '/Volumes/VIRK-RH/Radioterapi Forskning/Hjerne/GBM/FETPET/Recurrence';
dicomDir = '/Volumes/Windows/GBM/Recurrence/DicomFiles';
fid = fopen(fullfile(workingDir,'scanData.csv'));
S = textscan(fid,'%s%s%s%s%s%s%s%f%f%f%f%f%f%f%s%d','delimiter',',','HeaderLines',1);
fclose(fid);

keys = S{1};
noPatients = length(keys);
%%
for i =57:noPatients
    
    if isempty(S{2}{i})
        continue
    end
    if length(keys{i}) < 2 || isnan(str2double(keys{i}))
        subject = ['Patient0' keys{i}];
    else
        subject = ['Patient' keys{i}];
    end
    disp([subject ' - Number ' num2str(i) ' of ' num2str(noPatients) '...'])
    
    study = dir(fullfile(dicomDir,subject,'Baseline*'));
    study = study.name;
    
    series = dir(fullfile(dicomDir,subject,study,'PETCT*'));
    series = series.name;
    
    CTscan = dir(fullfile(dicomDir,subject,study,series,'CT*'));
    CTscan = CTscan.name;
    CT = loadDicomFiles(fullfile(dicomDir,subject,study,series,CTscan),1,0,1);
    
    PETscan = dir(fullfile(dicomDir,subject,study,series,'FET*'));
    try
        PETscan = PETscan.name;
        PET = loadDicomFiles(fullfile(dicomDir,subject,study,series,PETscan),1,0,1);
    catch ME
        disp(['***' ME.message])
        continue
    end
    
    try
        RSfile = dir(fullfile(dicomDir,subject,study,'RT','RS*.dcm'));
        RS = loadRTStructures(fullfile(dicomDir,subject,study,'RT',RSfile.name));
    catch ME
        disp(['***' ME.message])
        continue
    end
    
    RDfile = dir(fullfile(dicomDir,subject,study,'RT','RD*.dcm'));
    RD = loadRTDose(fullfile(dicomDir,subject,study,'RT',RDfile.name),'RS',RS);
    
    offset = 3; % mm
    try
        %disp('* Cropping')
        CT = cropVolume(CT,RS,{'Hjerne','BrainNOC719','hjerne','Brain_NO__C71_9','brain','Brain','Hjerne_'},offset);
        PET = cropVolume(PET,RS,{'Hjerne','BrainNOC719','hjerne','Brain_NO__C71_9','brain','Brain','Hjerne_'},offset);
        %disp('** Saving')
        save(fullfile(workingDir,'patientFiles',subject),'CT','PET','RS','RD');
    catch ME
        disp(['***' ME.message])
        continue
    end
end