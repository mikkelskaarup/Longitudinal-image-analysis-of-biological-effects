function par = decomposeTransformationMatrix(M)

% fix notation
M = M';

if numel(M) ~=16 
    error('Number of elements in rotation matrix must equal 16!')
end

if size(M,2) ~= 4 % Case M is not a 4x4 matrix3
    M = reshape(M,4,4);
    R = M(1:3,1:3);
    M = permute(M,[2 1]);
    M(1:3,1:3) = R;
end


% Check of cos(theta) ~= 1 
if M(3,1) ~= 1  % - two possible solutions
    % Rotation about y
    Ry1 = asin(M(3,1));
    Ry2 = pi - Ry1;
    % Rotation about x
    Rx1 = -atan2( M(3,2)/cos(Ry1) , M(3,3)/cos(Ry1) );
    Rx2 = -atan2( M(3,2)/cos(Ry2) , M(3,3)/cos(Ry2) );
    % Rotation about z
    Rz1 = -atan2( M(2,1)/cos(Ry1) , M(1,1)/cos(Ry1) );
    Rz2 = -atan2( M(2,1)/cos(Ry2) , M(1,1)/cos(Ry2) );
else            % - one solution
    Rz1 = 0; % Can be set to anything - choosing zero as default
    if M(3,1) == 1
        Ry1 = pi/2;
        Rx1 = Rz1 - atan2( M(1,2) , M(1,3) );
    else
        Ry1 = -pi/2;
        Rx1 = -Rz1 - atan2( -M(1,2) , -M(1,3) );
    end
end

%disp(sprintf('Translation (mm):\nx: %f\ny: %f\nz: %f\n',M(1,4),M(2,4),M(3,4)));
%disp(sprintf('Rotation (radians):\nx: %f\ny: %f\nz: %f\n',Rx1,Ry1,Rz1));
%disp(sprintf('Rotation (degrees):\nx: %f\ny: %f\nz: %f\n',radtodeg(Rx1),radtodeg(Ry1),radtodeg(Rz1)));

par = [M(1,4),M(2,4),M(3,4),radtodeg(Rx1),radtodeg(Ry1),radtodeg(Rz1)];

function d=radtodeg(r)
d = r*180/pi;
end
end