function S = getRayStatistics(Sin,mapSize,varargin)
%
%
%
%
% Default input

k = 1;
while k <= length(varargin)
    switch varargin{k}
        case 'exclude_mask'
            k = k + 1;
            ex_mask = varargin{k};
        otherwise
            error('Illegal option %s', varargin{k});
    end
    k = k + 1;
end


% Pre-allocate
mapping = NaN(length(Sin.V),2);
dist_map = zeros(mapSize)';
map_counts = zeros(mapSize)';

% Compute length of each ray
len = sqrt(sum(Sin.V.^2,2));

% Loop over each ray
for i = 1:length(len)
    % Calculate inferior-superior angle - will be 0-180 
    theta = asind(Sin.Unit_V(i,3)) + 90;
    % Find closest point in map
    map_y = round((mapSize(2)-1)*theta/180)+1;

    % Calculate posterior-right-anterior-left angle - will be 0-360 
    azim = azimuth(Sin.Unit_V(i,2),Sin.Unit_V(i,1), 0 , 0);
    % 0 is posterior, 90 is right, 180 anterior (at the nose), 270 is left
    phi = mod(azim+180,360); 
    % Find closest point in map
    map_x = round((mapSize(1) - 1) * phi / 360) + 1;
    
    % Save mapping
    mapping(i,1) = map_x; mapping(i,2) = map_y;
    % Count number of visits in each pixel (for normalization)
    map_counts(map_y,map_x) = map_counts(map_y,map_x) + 1;
    % Save ray length
    dist_map(map_y,map_x) = dist_map(map_y,map_x) + len(i);
    
end
d = dist_map./map_counts;

% Save output
S = struct('Mapping',mapping,'MapCounts',map_counts,'Distance',d);
