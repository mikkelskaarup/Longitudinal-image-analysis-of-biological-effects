function [minDose,maxDose,avgDose]=DVHDoseExtrema(DVH)

if ~isstruct(DVH)
    error('Input must be a structure.')
end

dose = cumsum(DVH.Dose);
volume = DVH.Volume;

if numel(dose) < 30 % not a reliable DVH
    [minDose,maxDose,avgDose] = deal(NaN);
else
    tol = 1e-2;
    maxDose = dose(find(volume<tol,1,'first')-1);
    minDose = dose(find(diff(volume)<-tol,1,'first'));
    avgDose = sum(DVH.Dose.*volume) / volume(1);
end
