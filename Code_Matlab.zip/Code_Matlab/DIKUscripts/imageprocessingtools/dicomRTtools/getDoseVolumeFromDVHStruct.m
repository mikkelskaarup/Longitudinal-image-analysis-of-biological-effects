clear all; clc
fDir = '/Users/mlj/Documents/MATLAB';
mergedStructureFile = fullfile(fDir,'Merged DVH 01-Feb-2014.mat');

Patients = load(mergedStructureFile);
PatientNames = fieldnames(Patients);

noPatients = length(PatientNames);
NOPLANS = 3;
NOMEASURES = 6;

PRESCRIBEDDOSE = 30.6; % Gy

result = cell(NOPLANS*noPatients+1,NOMEASURES+2);
result(1,:) = {'PatientID','Plan','PTV volume cm3','CTV volume cm3','PTV V90','PTV D40','CTV V90','CTV D40'};
index = 2;
for i = 1:noPatients
    patient = Patients.(PatientNames{i});
    plans = fieldnames(Patients.(PatientNames{i}).Plans);
    
    for j = 1:length(plans)
        result{index,1} = patient.PatientID;
        result{index,2} = plans{j};
        % Volume
        result{index,3} = patient.Plans.(plans{j}).DVH.PTV.Volume(1);
        if isfield(patient.Plans.(plans{j}).DVH,'CTV');
            result{index,4} = patient.Plans.(plans{j}).DVH.CTV.Volume(1);
        end
        
        % V90
        result{index,5} = volumeAtDoseFraction(patient.Plans.(plans{j}).DVH.PTV,0.9,PRESCRIBEDDOSE);
        if isfield(patient.Plans.(plans{j}).DVH,'CTV');
            result{index,7} = volumeAtDoseFraction(patient.Plans.(plans{j}).DVH.CTV,0.9,PRESCRIBEDDOSE);
        end
        
        % D40
        result{index,6} = doseAtVolumeFraction(patient.Plans.(plans{j}).DVH.PTV,0.9);
        if isfield(patient.Plans.(plans{j}).DVH,'CTV');
            result{index,8} = doseAtVolumeFraction(patient.Plans.(plans{j}).DVH.PTV,0.9);
        end
        index = index+1;
    end
end

v = version('-release');

if ~ispc && str2double(v(1:4)) > 2012
    % save excel
    cNames = strrep(result(1,:),' ','');
    t_array = cell2table(result(2:end,:));
    t_array.Properties.VariableNames = cNames;
    writetable(t_array,fullfile(fDir,'VolumeMeasures.csv'),'delimiter',';')

elseif ispc
    xlswrite(fullfile(fDir,'VolumeMeasures'),result);
else 
    errordlg('Cannot save to spreadsheet!');
end
