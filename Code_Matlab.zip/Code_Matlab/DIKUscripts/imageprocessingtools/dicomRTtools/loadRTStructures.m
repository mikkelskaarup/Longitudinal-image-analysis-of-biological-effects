function S = loadRTStructures(in)

if nargin == 0
    dialog_title = 'Select DICOM RT Structure to load.';
    [fName,dName] = uigetfile('*.dcm',dialog_title);
    if ~fName % user pressed cancel
        return
    end
    in = fullfile(dName,fName);
end

info = verifyRTinput(in);

S.info = info;

noVOI = size(fieldnames(info.StructureSetROISequence),1);
noVOIContours = size(fieldnames(info.ROIContourSequence),1);
S.ReferencedFrameOfReferenceUID = info.ReferencedFrameOfReferenceSequence.Item_1.FrameOfReferenceUID;
S.StructureInstanceUID = info.SOPInstanceUID;
if isfield(info,'StructureSetLabel')
    S.Label = info.StructureSetLabel;
end

% Loop over all structures in StructureSetROISequence
for i = 1:noVOI
    totalNumberOfContourPoints = 0;
    structName = matlab.lang.makeValidName(strrep(info.StructureSetROISequence.(['Item_' num2str(i)]).ROIName,' ',''));
    structNumber = info.StructureSetROISequence.(['Item_' num2str(i)]).ROINumber;
    % disp(structName)
    RefSOPprev = [];
    
    % Loop once to find totalNumberOfContourPoints. This is necessary to pre-allocate and save memory
    for j = 1:noVOIContours
        if isfield(info.ROIContourSequence.(['Item_' num2str(j)]),'ReferencedROINumber') && info.ROIContourSequence.(['Item_' num2str(j)]).ReferencedROINumber == structNumber && isfield(info.ROIContourSequence.(['Item_' num2str(j)]),'ContourSequence')
            contours = info.ROIContourSequence.(['Item_' num2str(j)]).ContourSequence;
            for k = 1:size(fieldnames(contours),1)
                totalNumberOfContourPoints = totalNumberOfContourPoints + size(contours.Item_1.ContourData,1)/3;
            end
        end
    end
    
    if totalNumberOfContourPoints == 0
        disp(['Contour: ' structName ' not present - skipping!'])
        continue
    end
    % Pre-allocate
    x = NaN(totalNumberOfContourPoints,1);
    y = x;
    z = x;
    c = x;
    id = 0;
    
    % Loop over all structures in ROIContourSequence to find referenced StructureSetROISequence
    for j = 1:noVOIContours
        % Check if ReferencedROINumber match StructureSetROINumber AND Check if ContourSequence is present in ROIContourSequence
        if isfield(info.ROIContourSequence.(['Item_' num2str(j)]),'ReferencedROINumber') && info.ROIContourSequence.(['Item_' num2str(j)]).ReferencedROINumber == structNumber && isfield(info.ROIContourSequence.(['Item_' num2str(j)]),'ContourSequence');
            
            % Save Display Color
            S.(structName).DisplayColor = info.ROIContourSequence.(['Item_' num2str(j)]).ROIDisplayColor/255;
            % Save each saved contour (one slice may contain more than one contour)
            contours = info.ROIContourSequence.(['Item_' num2str(j)]).ContourSequence;
            % Loop over all contours in ROIContourSequence
            for k = 1:size(fieldnames(contours),1)
                % Check if the current contour is on the same slice as previous contour
                if isfield(info.ROIContourSequence.(['Item_' num2str(j)]).ContourSequence.(['Item_' num2str(k)]),'ContourImageSequence')
                    RefSOPcurrent = info.ROIContourSequence.(['Item_' num2str(j)]).ContourSequence.(['Item_' num2str(k)]).ContourImageSequence.Item_1.ReferencedSOPInstanceUID;
                    if strcmp(RefSOPprev,RefSOPcurrent) % same image/slice increase contour counter
                        contourNo = contourNo + 1;
                    else
                        contourNo = 1;
                    end
                else
                    warning(['Can''t find Contour Image Sequence in ROI Contour Sequence in ' structName '. Skipping...']);
                    continue
                end
                
                coordinates = getContourPoints(contours,k);
                
                x( id+1:size(coordinates.x,1)+id ) = coordinates.x;
                y( id+1:size(coordinates.x,1)+id ) = coordinates.y;
                z( id+1:size(coordinates.x,1)+id ) = coordinates.z;
                c( id+1:size(coordinates.x,1)+id ) = ones(length(coordinates.x),1) * contourNo;
                
                id = id+size(coordinates.x,1);
                RefSOPprev = RefSOPcurrent;
            end % contour-loop
        end  
    end % ReferencedROINumber-loop
    nanIdx = isnan(x);
    S.(structName).x = x(~nanIdx);
    S.(structName).y = y(~nanIdx);
    S.(structName).z = z(~nanIdx);
    S.(structName).c = c(~nanIdx);
    S.(structName).ROIno = info.ROIContourSequence.(['Item_' num2str(i)]).ReferencedROINumber;
    
end



if nargout == 0
    Vars = evalin('base','who(''RS*'');');
    assignin('base', genvarname('RS',Vars), S);
end

if exist('fh','var')
    close(fh)
end