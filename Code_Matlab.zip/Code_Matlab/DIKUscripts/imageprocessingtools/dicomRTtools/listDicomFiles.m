function fArray = listDicomFiles(dName)

% List dicom files in folder
list = dir([dName filesep '*dcm']);
fArray = {list(:).name}';
if isempty(fArray)
    list = dir([dName filesep '*DCM']);
    fArray = {list(:).name}';
end
% If no DICOM files - look for Siemens IMA
if isempty(fArray)
    list = dir([dName filesep '*IMA']);
    fArray = {list(:).name}';
end

% If no DICOM files - look for files without extension
% if isempty(fArray)
%     list = dir(dName);
%     fArray = {list(3:end).name}';
% end