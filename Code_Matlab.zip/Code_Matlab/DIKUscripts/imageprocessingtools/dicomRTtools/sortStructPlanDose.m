function PLAN = sortStructPlanDose(dName,copyRS,sortStudyDate)
if nargin < 3
    sortStudyData = 0;
end

if nargin < 2
    copyRS = 0;
end

if copyRS
    mvORcp = 'copy';
else 
    mvORcp = 'move';
end
%% Read CT Files
CTArray = dir([dName filesep 'CT*.dcm']);
CTArray = {CTArray(:).name};
if isempty(CTArray)
     warning('No CT files to sort!!');
else
    for i = 1:length(CTArray)
        info = dicominfo([dName filesep CTArray{i}]);
        
        if sortStudyDate
            studyDate = [info.StudyDate filesep];
        else
            studyDate = '';
        end
        
        noCTscans = length(dir([dName filesep 'CT']));
        if isfield(info,'SeriesDescription')
            CTfolder = [dName filesep studyDate info.SeriesDescription];
        elseif isfield(info,'StudyDescription')
            CTfolder = [dName filesep studyDate info.StudyDescription];
        else
            CTfolder = [dName filesep studyDate 'CT' num2str(noCTscans+1)];
        end
        
        if ~exist(CTfolder,'dir');
            mkdir(CTfolder);
            movefile([dName filesep CTArray{i}],CTfolder);
        else
            movefile([dName filesep CTArray{i}],CTfolder);
        end

        CTNames.(['UID' strrep(info.FrameOfReferenceUID,'.','')]) = CTfolder;
        
    end
end
%% Read RT Structures
RSArray = dir([dName filesep 'RS*.dcm']);
RSArray = {RSArray(:).name};
if isempty(RSArray)
    warning('No RS files to sort!!');
else
    for i = 1:length(RSArray)
        info = dicominfo([dName filesep RSArray{i}]);
        STRUCT.(['UID' strrep(info.SOPInstanceUID,'.','')]).FileName = [dName filesep RSArray{i}];
        STRUCT.(['UID' strrep(info.SOPInstanceUID,'.','')]).Label = info.StructureSetLabel;
        STRUCTRefFoR.(['UID' strrep(info.SOPInstanceUID,'.','')]).ReferencedCTUID = ['UID' strrep(info.ReferencedFrameOfReferenceSequence.Item_1.FrameOfReferenceUID,'.','')];
    end
    RSUIDs = fieldnames(STRUCT);
end
%% Sort RTPLANS
RPArray = dir([dName filesep 'RP*.dcm']);
RPArray = {RPArray(:).name};

if isempty(RPArray)
    if exist('CTNames','var')
        CTs = fieldnames(CTNames);
        warning('No RP files to sort!!');
        %%%%% Sort RS File(s) %%%%%
        for i = 1:length(STRUCT)
            sNames = fieldnames(STRUCT);
            ind = ismember(CTs,STRUCTRefFoR.(sNames{i}).ReferencedCTUID);
            CTfolder = CTNames.(CTs{ind});
            system([mvORcp ' "' STRUCT.(sNames{i}).FileName '" "' CTfolder '"']);
        end
    end
else
    for i = 1:length(RPArray)
        info = dicominfo([dName filesep RPArray{i}]);
        if exist('PLAN','var') && isfield(PLAN,['UID' strrep(info.SOPInstanceUID,'.','')])
            disp([dName filesep RPArray{i} ' already exist - skipping!']);
        else
            if isfield(info,'RTPlanLabel')
                disp(['Label: ' info.RTPlanLabel]);
                disp('************');
                RTPlanLabel = cleanPlanNameToFolder(info.RTPlanLabel);
                RPfolder = [dName,filesep,RTPlanLabel];
                RPfileName = ['RP_' RTPlanLabel];
                
                if ~exist(RPfolder,'dir');
                    system(['mkdir "' RPfolder '"']);
                end
                
                if ~exist([RPfolder filesep RPfileName '.dcm'],'file')
                    system(['move "' dName filesep RPArray{i} '" "' RPfolder filesep RPfileName '.dcm"']);
                else
                    plans = ls([RPfolder filesep RPfileName '*']);
                    uniquePlans = size(plans,1);
                    system(['move "' dName filesep RPArray{i} '" "' RPfolder filesep RPfileName...
                        '_' num2str(uniquePlans) '.dcm"']);
                    if ~exist([RPfolder filesep 'ReadMe.txt'],'file')
                        fid = fopen([RPfolder filesep 'ReadMePlan.txt'],'w');
                        fprintf(fid,'Multiple Plans with same name encountered.');
                        fclose(fid);
                    end
                end
                
                SOPInstanceUID = strrep(info.SOPInstanceUID,'.','');
                PLAN.(['UID' SOPInstanceUID]) = RTPlanLabel;
                if isfield(info,'ReferencedStructureSetSequence');
                    structureIndex = find(ismember(RSUIDs,['UID' strrep(info.ReferencedStructureSetSequence.Item_1.ReferencedSOPInstanceUID,'.','')]));
                    if length(structureIndex)==1
                        %%%%% Sort RS File(s) %%%%%
                        RSfileName = strrep(['RS_' STRUCT.(RSUIDs{structureIndex}).Label],' ','_');
                        if ~exist([RPfolder filesep RSfileName '.dcm'],'file')
                            system([mvORcp ' "' STRUCT.(RSUIDs{structureIndex}).FileName '" "' RPfolder filesep RSfileName '.dcm"']);
                        else
                            struct = ls([RPfolder filesep RSfileName '*']);
                            uniqueStructs = size(struct,1);
                            system([mvORcp ' "' STRUCT.(RSUIDs{structureIndex}).FileName '" "' RPfolder filesep RSfileName...
                                '_' num2str(uniqueStructs) '.dcm"']);
                            if ~exist([RPfolder filesep 'ReadMe.txt'],'file')
                                fid = fopen([RPfolder filesep 'ReadMeStructs.txt'],'w');
                                fprintf(fid,'Multiple Structuresets with same name encountered.');
                                fclose(fid);
                            end
                        end
                        %%%%% Sort CT Files %%%%%
                        CTFolderName = CTNames.(STRUCTRefFoR.(RSUIDs{structureIndex}).ReferencedCTUID);
                        system([mvORcp ' "' CTFolderName filesep '*.dcm" "' RPfolder filesep '"']);
                    else
                        warning('No Referenced Structure in RP-file!!');
                    end
                    
                    
                else
                    warning('No Referenced Structure in RP-file!!');
                end
            else
                disp([RPArray{i} ' - No Plan Label - cannot rename']);
            end
        end
    end
end


%% Sort RTDOSES
RDArray = dir([dName filesep 'RD*.dcm']);
RDArray = {RDArray(:).name}';

if isempty(RDArray)
    warning('No RD files to sort!!');
else
    RPUIDs = fieldnames(PLAN);
    for i = 1:length(RDArray)
        info = dicominfo([dName filesep RDArray{i}]);
        RDreferencedRPUID = ['UID' strrep(info.ReferencedRTPlanSequence.Item_1.ReferencedSOPInstanceUID,'.','')];
        RDfileName = ['RD_' info.DoseSummationType];
        
        planIndex = find(ismember(RPUIDs,RDreferencedRPUID));
        if ~isempty(planIndex)
            for j = 1:length(planIndex)
                RPfolder = [dName filesep PLAN.(RPUIDs{planIndex(j)})];
                if ~exist([RPfolder filesep RDfileName '.dcm'],'file')
                    system(['move "' dName filesep RDArray{i} '" "' RPfolder filesep RDfileName '.dcm"']);
                else
                    doses = ls([RPfolder filesep RDfileName '*']);
                    uniqueDoses = size(doses,1);
                    system(['move "' dName filesep RDArray{i} '" "' RPfolder filesep RDfileName...
                        '_' num2str(uniqueDoses) '.dcm"']);
                    if ~exist([RPfolder filesep 'ReadMe.txt'],'file')
                        fid = fopen([RPfolder filesep 'ReadMeDose.txt'],'w');
                        fprintf(fid,'Multiple Doses with same name encountered.');
                        fclose(fid);
                    end
                end
            end
        else
            warning(sprintf('No Plan match this dose-file: %s\nLeaving in Patient root folder!', RDArray{i}));
        end
        
    end
end