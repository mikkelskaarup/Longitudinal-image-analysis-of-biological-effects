function status = verifyDICOMRTtriplet(RS,RP,RD)
%VERIFYDICOMRTTRIPLET  Compare RT Structure Set, RT Plan File and RT Dose file.
%   status = verifyDICOMRTtriplet(RS,RP,RD) reads dicominfo structures or
%   filenames of DICOM-files
%
%   OUTPUT: The following status codes represent:
%           0: All files match
%           1: RT Structure Set does not match RT Plan
%           2: RT Structure Set does not match RT Dose
%           3: RT Dose does not match RT Plan
%           4: RT Structure Set does not match RT Plan & RT Dose does not match RT Plan
%           5: RT Structure Set does not match RT Dose & RT Dose does not match RT Plan
%           6: Neither files match

RS = verifyRTinput(RS);
RP = verifyRTinput(RP);
RD = verifyRTinput(RD);

status = 0;

% Structure
RSSOP = RS.SOPInstanceUID;
% Plan
RPSOP = RP.SOPInstanceUID;
% Referenced Strucutre
RPreferencedRSSOP = RP.ReferencedStructureSetSequence.Item_1.ReferencedSOPInstanceUID;
if isfield(RD,'ReferencedStructureSetSequence')
    RDreferencedRSSOP = RD.ReferencedStructureSetSequence.Item_1.ReferencedSOPInstanceUID;
else
    RDFRAME = RD.FrameOfReferenceUID;
    RSFRAME = RS.ReferencedFrameOfReferenceSequence.Item_1.FrameOfReferenceUID;
end
% Referenced Plan
RDreferencedRPSOP = RD.ReferencedRTPlanSequence.Item_1.ReferencedSOPInstanceUID;

% Compare structureset and plan-file
if ~strcmp(RSSOP,RPreferencedRSSOP)
    warning(['RT Plan file does not match RT Structure file for patient ' RP.PatientID]);
    status = 1;
end
% Compare structureset and dose-file   
if (exist('RDreferencedRSSOP','var') && ~strcmp(RSSOP,RDreferencedRSSOP)) || (exist('RDFRAME','var') && ~strcmp(RDFRAME,RSFRAME))
    warning(['RT Dose file does not match RT Structure file for patient ' RP.PatientID]);
    status = status + 2;
end
% Compare plan and dose-file   
if ~strcmp(RPSOP,RDreferencedRPSOP)
    warning(['RT Plan file does not match RT Dose file for patient ' RP.PatientID]);
    status = status + 3;
end

