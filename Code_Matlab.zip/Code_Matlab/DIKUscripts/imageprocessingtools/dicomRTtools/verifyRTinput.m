function info = verifyRTinput(in)
%VERIFYRTINPUT  Checks if input is a structure loaded by dicominfo(). If not, the file is loaded.
%   info = verifyRTinput(in)

if isstruct(in)
    info = in;
elseif ischar(in)
    if exist(in,'file')
        if strcmpi(in(end-2:end),'dcm')
            info = dicominfo(in);
        else
            fArray = dir(fullfile(in,'*.dcm'));
            if isempty(fArray)
                error('No RT file found')
            elseif size(fArray,1) > 1
                sprintf('%s\n',fArray(:).name);
                error('More than one RT file found - specify the correct one')
            else
                info = dicominfo(fullfile(in,fArray.name));
            end
        end
    end
    
else
    error('Input not recognized!');
end





