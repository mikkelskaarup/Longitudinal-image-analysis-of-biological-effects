function [M,info] = loadDicomRegistration(str,ref)

matchFound = 1;

if exist(str,'dir') == 7 % 'str' is a folder
    fArray = dir([str filesep 'RE*.dcm']);
    if isempty(fArray)
        fArray = dir([str filesep '*.dcm']);
    end
    fArray = {fArray(:).name};
    for i = 1:size(fArray,2)
        REGinfo = dicominfo([str filesep fArray{i}]);
        if strcmp(REGinfo.FrameOfReferenceUID,ref.info.FrameOfReferenceUID)
            matchFound = 1;
        end
    end        
elseif exist(str,'file')
    REGinfo = dicominfo(str);
    if ~strcmp(REGinfo.FrameOfReferenceUID,ref.info.FrameOfReferenceUID)
        error('Registration file does not match referenced volume!');
    else
        matchFound = 1;
    end
else
    error('No DICOM registration file found!');
end

if ~matchFound
    error('No registration matches referenced volume!')
end
    


if ~exist('fArray','var')
    f = fieldnames(REGinfo.RegistrationSequence);
    [REGVEC,tempFoR] = returnAffine(REGinfo,f,ref);
else
    for i = 1:size(fArray,2)
        REGinfo = dicominfo([str filesep fArray{i}]);
        f = fieldnames(REGinfo.RegistrationSequence);
        [REGVEC,tempFoR] = returnAffine(REGinfo,f,ref);
    end
end

M = reshape(REGVEC,4,4);
info.ReferenceFrameOfReferenceUID = ref.info.FrameOfReferenceUID;
info.TemplateFrameOfReferenceUID = tempFoR;

function [REGVEC,FoR] = returnAffine(REGinfo,f,ref)

I = [1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1]';
for i = 1:length(f)
    REGVEC = REGinfo.RegistrationSequence.(f{i}).MatrixRegistrationSequence.Item_1.MatrixSequence.Item_1.FrameOfReferenceTransformationMatrix;
    if ~isequal(I,REGVEC)
        FoR = REGinfo.RegistrationSequence.(f{i}).FrameOfReferenceUID;
        return
    end
end
        
% for i = 1:length(f)
%     if ~strcmp(REGinfo.RegistrationSequence.(f{i}).FrameOfReferenceUID,ref.info.FrameOfReferenceUID)
%         REGVEC = REGinfo.RegistrationSequence.(f{i}).MatrixRegistrationSequence.Item_1.MatrixSequence.Item_1.FrameOfReferenceTransformationMatrix;
%         FoR = REGinfo.RegistrationSequence.(f{i}).FrameOfReferenceUID;
%         return
%     end
%     if ~exist('REGVEC','var')
%         REGVEC = [];
%         FoR = [];
%     end        
% end



