%% 
function sortedInfos = readDICOMinfos(dName)

if ispc
    fArray = ls([dName filesep '*.dcm']);
    if isempty(fArray)
        fArray = ls(dName);
        fArray = fArray(3:end,:);
    end
        
else
    list = ls(dName);
    r = regexp(list,'\s','split'); %split character string 
    fArray = char(r); %convert cell to array
    fArray = fArray(1:end-1,:); %remove last blank line
end

% PREALLOCATE
nFrames = double(size(fArray,1));
ZSlice = zeros(nFrames,1);
infos = cell(nFrames,1);

% Read images
h = waitbar(0,'Reading images.....');
for i = 1:nFrames
    tmpInfo = dicominfo([dName '/' fArray(i,:)]);
    infos{i} = tmpInfo;
    % Through slice direction cross(u1,u2)
    n = cross(tmpInfo.ImageOrientationPatient(1:3),tmpInfo.ImageOrientationPatient(4:6));
    % Determine ImagePatientPosition along n
    ZSlice(i)= dot(n,tmpInfo.ImagePositionPatient);
    waitbar(i / nFrames)
end

if exist('h','var')
    close(h)
end

[~, zOrder]   = sort(ZSlice,'ascend'); % sort each slice in descending order

sortedInfos = infos(zOrder);
