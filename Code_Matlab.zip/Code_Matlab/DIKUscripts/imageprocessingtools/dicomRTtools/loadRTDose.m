function [struct] = loadRTDose(in,varargin)

info = verifyRTinput(in);

% Default options
calc_dvh = 0;

k = 1;
while k <= length(varargin)
    switch varargin{k}
        case 'RS'
            k = k + 1;
            RS = varargin{k};
        case 'calc_dvh'
            k = k + 1;
            calc_dvh = varargin{k};
        otherwise
            error('Illegal option %s', varargin{k});
    end
    k = k + 1;
end

struct.VolumeType = 'Dose';
struct.vol = double(squeeze(dicomread(info))).*info.DoseGridScaling;
struct.infos = info;
struct.FrameOfReferenceUID = info.FrameOfReferenceUID;
struct.DoseInstanceUID = info.SOPInstanceUID;
struct.ReferencedPlanUID = info.ReferencedRTPlanSequence.Item_1.ReferencedSOPInstanceUID;

%%%% DVH DATA %%%%
% Check if DVH data is within DOSE-file
if isfield(info,'DVHSequence')
    struct.ReferencedStructUID = info.ReferencedRTPlanSequence.Item_1.ReferencedSOPInstanceUID;
    % Check if SOP instances match
    if exist('RS','var') && strcmp(info.ReferencedStructureSetSequence.Item_1.ReferencedSOPInstanceUID,RS.StructureInstanceUID)
        struct.DVH = readRTDVH(info.DVHSequence,RS);
    else
        struct.DVH = readRTDVH(info.DVHSequence);
    end
    % Save calculation data
    struct.DVHCalculation = [info.Manufacturer ', ' info.ManufacturerModelName]; 
elseif calc_dvh
    struct.DVH = [] %%% IMPLEMENT OWN CALCULATION, SEE "CalculateDVH.m"
    struct.DVHCalculation = 'MATLAB'; 
else
    struct.DVH = [];
end
%%%% DVH DATA %%%%

struct.VoxelDimension = [info.PixelSpacing' abs(info.GridFrameOffsetVector(2)-info.GridFrameOffsetVector(1))];
struct.Unit = info.DoseUnits;
struct.Type = info.DoseType;
struct.SummationType = info.DoseSummationType;

nFrames = length(info.GridFrameOffsetVector);
nRows = double(info.Rows);
nCols = double(info.Columns);

struct.M = image2patientTransformation(info);

n = nCols * nRows * nFrames;
imageCoordinateMatrix = [1:n; 1:n; 1:n; ones(1,n)];

patientCoordinateMatrix = struct.M*imageCoordinateMatrix;

x = patientCoordinateMatrix(1,1:nCols);
y = patientCoordinateMatrix(2,1:nRows);
% Round z to two decimales
z = round(patientCoordinateMatrix(3,1:nFrames)*100)/100;

[struct.X,struct.Y,struct.Z] = meshgrid(x,y,z);
struct.R = eye(4);
struct.ReferenceObject = getRobject(struct,'world');

% Average Window-Center and -Width
WindowCenter = ones(nFrames,1)*max(struct.vol(:))/2;
WindowWidth = ones(nFrames,1)*max(struct.vol(:))/2;

struct.WindowCenter = WindowCenter;
struct.WindowWidth = WindowWidth;

