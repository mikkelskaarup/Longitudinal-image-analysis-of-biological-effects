fDir = 'H:\Windows\DicomFiles';
patients = listSubfolders(fDir);
h = waitbar(0,'Sorting DICOM files');
for i = 14:length(patients)
    disp(['Sorting Patient ' num2str(i) ' of ' num2str(length(patients)) '...'])
    sortStructPlanDose(fullfile(fDir,patients{i}),0,1);
    waitbar(i/length(patients));
end
close(h)