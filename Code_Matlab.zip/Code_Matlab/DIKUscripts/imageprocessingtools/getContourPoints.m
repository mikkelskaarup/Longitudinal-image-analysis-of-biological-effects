function coordinates = getContourPoints(contours,j)
% Get points of contour 'i'.
% Contours are the structure within:
% dcminfo.ROIContourSequence.Item_i.ContourSequence;

NumberOfContourPoints = contours.(['Item_' num2str(j)]).NumberOfContourPoints;

x = contours.(['Item_' num2str(j)]).ContourData(1:3:3*NumberOfContourPoints);
y = contours.(['Item_' num2str(j)]).ContourData(2:3:3*NumberOfContourPoints);
z = contours.(['Item_' num2str(j)]).ContourData(3:3:3*NumberOfContourPoints);

coordinates = struct('x',x,'y',y,'z',z);