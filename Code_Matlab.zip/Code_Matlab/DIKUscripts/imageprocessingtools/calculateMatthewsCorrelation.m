function M = calculateMatthewsCorrelation(brain,tv,tfv)

% True positive
TP = tv & tfv;
TP = sum(TP(:));
% True negative
TN = brain & ~(tv|tfv);
TN = sum(TN(:));
% False positive
FP = tv & ~tfv;
FP = sum(FP(:));
% False negative
FN = tfv & ~tv;
FN = sum(FN(:));

M = (TP*TN - FP*FN) / sqrt( (TP+FP)*(TP+FN)*(TN+FP)*(TN+FN) );