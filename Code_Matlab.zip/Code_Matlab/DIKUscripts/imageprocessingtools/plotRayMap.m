function plotRayMap(map,varargin)

k = 1;
while k <= length(varargin)
    switch varargin{k}
        case 'fh'
            k = k + 1;
            fh = varargin{k};
        otherwise
            error('Illegal option %s', varargin{k});
    end
    k = k + 1;
end

xticklabel = {'Posterior','Left','Anterior','Right','Posterior'};
yticklabel = {'Inferior','Center','Superior'};

if exist('fh','var')
    figure(fh)
else
    figure
end
map_size = size(map);
fd = imagesc(map);
fd.Parent.YDir = 'normal';
fd.Parent.XTick = linspace(1,map_size(2),length(xticklabel));
fd.Parent.YTick = linspace(1,map_size(1),length(yticklabel));
fd.Parent.XTickLabel = xticklabel;
fd.Parent.XTickLabelRotation = 45;
fd.Parent.YTickLabel = yticklabel;

