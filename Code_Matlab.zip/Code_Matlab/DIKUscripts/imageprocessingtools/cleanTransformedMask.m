function cMask = CleanTransformedMask(mask,thr,p)
% Mask
% Thr: Threshold - usually 0.5
% P: remove cluster of voxel less than p

mask(mask<thr) = 0;
mask(mask~=0) = 1;

cMask = mask;

for z = 1:size(mask,3)
    cMask(:,:,z) = bwareaopen(mask(:,:,z),p);
    cMask(:,:,z) = imfill(mask(:,:,z),'holes');
end