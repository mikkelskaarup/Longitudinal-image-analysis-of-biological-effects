function oi = calculateOverlapIndex(logicmask1,logicmask2)

intersect = logicmask1 & logicmask2;
oi = sum(intersect(:))/sum(logicmask2(:));