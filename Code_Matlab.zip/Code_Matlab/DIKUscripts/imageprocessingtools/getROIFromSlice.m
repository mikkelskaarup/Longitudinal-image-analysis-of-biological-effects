function  [x,y] = getROIFromSlice(S,slice)

% Round to two decimals
slice = str2double(sprintf('%.2f',round(slice*100)/100));

ind = S.z == slice;

noROIwithinSlice = max(S.c(ind));

x = NaN*ones(sum(ind),noROIwithinSlice);
y = x;

for i = 1:noROIwithinSlice
    roiInd = (S.c == i & S.z == slice);
    xtmp = S.x(roiInd);
    ytmp = S.y(roiInd);
    x(1:length(xtmp),i) = xtmp;
    y(1:length(ytmp),i) = ytmp;
    x(length(xtmp)+1,i) = xtmp(1);
    y(length(ytmp)+1,i) = ytmp(1);
end