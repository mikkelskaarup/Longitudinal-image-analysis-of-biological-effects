function [S,FP] = calculateSpecificity(brain,tv,tfv)

% True negative
TN = brain & ~(tv|tfv);
TN = sum(TN(:));
% False positive
FP = tv & ~tfv;
FP = sum(FP(:));

S = TN / (TN+FP);
