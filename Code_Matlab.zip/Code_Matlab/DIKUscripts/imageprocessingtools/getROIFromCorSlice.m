function  [x,z] = getROIFromCorSlice(S,slice)

% Round to nearest integer
slice = round(slice);

ind = round(S.y) == slice;

noROIwithinSlice = max(S.c(ind));

x = NaN*ones(sum(ind),noROIwithinSlice);
z = x;

for i = 1:noROIwithinSlice
    roiInd = (S.c == i & round(S.y) == slice);
    xtmp = S.x(roiInd);
    ztmp = S.z(roiInd);
    P = patch(xtmp,ztmp,'r');
    [~, I] = sort([angle(complex(xtmp-mean(xtmp),ztmp-mean(ztmp)))]);
    x(:,i) = xtmp(I);
    z(:,i) = ztmp(I);
    %[x(:,i), z(:,i)] = poly2cw(xtmp,ztmp);
end