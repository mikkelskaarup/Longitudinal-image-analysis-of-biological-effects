function K=returnK(x1_a,x2_a,x1_b,x2_b)

% Constructing K-matrix using given hint
c_a = x1_a(:) + 1i*x2_a(:);
c_b = x1_b(:) + 1i*x2_b(:);

a = repmat(c_a,1,length(c_b));
b = repmat(c_b.',length(c_a),1);

d = a-b;

R = d.*conj(d);

ndx = find(R>0);

K = zeros(size(a));
K(ndx) = log(R(ndx)).*R(ndx);