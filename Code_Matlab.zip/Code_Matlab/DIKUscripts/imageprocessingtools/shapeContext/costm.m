function A = costm(c,d)

Nc = size(c,1);
Nd = size(d,1);

a = repmat(c,1,Nd);
b = repmat(d.',Nc,1);

e = a-b;

A = e.*conj(e);