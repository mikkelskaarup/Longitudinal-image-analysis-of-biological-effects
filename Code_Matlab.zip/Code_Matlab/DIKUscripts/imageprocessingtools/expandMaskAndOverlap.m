function [] = calculateDistanceAndOverlap(mask1,mask2,vargin)
%
% mask1 GTV
% mask2 Recurrence
% dspect: VoxelDimension (optional)
% distanceVector (optional)

if nargin < 2
    error('Not enough input arguments given.');
end

aspect = [1 1 1];
distanceVector = [];

k = 1;
while k <= length(varargin)
    switch varargin{k}
        case 'aspect'
            k = k + 1;
            aspect = varargin{k};
        case 'DistanceVector'
            k = k + 1;
            distanceVector = varargin{k};
        otherwise
            error('Illegal option %s', varargin{k});
    end
    k = k + 1;    
end



distMap = bwdistsc(mask1,aspect);

maximumDistance = max(max(max(distMap.*mask2)));

overlap = sum(sum(sum(mask1 | mask2))) / 

