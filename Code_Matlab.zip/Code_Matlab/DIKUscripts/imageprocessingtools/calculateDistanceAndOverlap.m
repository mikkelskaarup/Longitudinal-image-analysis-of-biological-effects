function [maximumDistance,overlap,distanceVector,spec,volume] = calculateDistanceAndOverlap(mask1,mask2,varargin)
%
% mask1 GTV
% mask2 Recurrence
% aspect: VoxelDimension (optional) 
% distanceVector (optional) in same units as aspect - can have the value of 1 in which 
% mask3 Optional mask to always include 
% case distance is increased until overlap is 1 

if nargin < 2
    error('Not enough input arguments given.');
end

aspect = [1 1 1];
distanceVector = [];
mask3 = zeros(size(mask1));

k = 1;
while k <= length(varargin)
    switch varargin{k}
        case 'aspect'
            k = k + 1;
            aspect = varargin{k};
        case 'distanceVector'
            k = k + 1;
            distanceVector = varargin{k};
        case 'mask3'
            k = k + 1;
            mask3 = varargin{k};
        otherwise
            error('Illegal option %s', varargin{k});
    end
    k = k + 1;    
end



distMap = bwdistsc(mask1,aspect);
temp = distMap.*mask2;
maximumDistance = max(temp(:));

[~,temp_spec,temp_overlap] = calculateFScore(mask1|mask3,mask2);

if isempty(distanceVector)
    overlap = temp_overlap;
    spec = temp_spec;
    volume = temp_spec;
    return
elseif isscalar(distanceVector) && distanceVector== 1
    overlap = NaN(100,1);
    spec = overlap;
    volume = overlap;
    distanceVector = 0:0.5:100;
else
    overlap = NaN(length(distanceVector,1));
    spec = overlap;
    volume = overlap;
end

i = 1;
while i <= length(distanceVector)
    expandedMask = distMap<=distanceVector(i);
    volume(i) = sum(expandedMask(:))*prod(aspect/10); % cm3
    [~,temp_spec,temp_overlap] = calculateFScore(expandedMask|mask3,mask2);
    overlap(i) = temp_overlap;
    spec(i) = temp_spec;
    i = i+1;
end

